export const GET_LOGISTIC_DISPATCH_REQUEST = 'logisticDispatch/GET_LOGISTIC_DISPATCH_REQUEST';
export const GET_LOGISTIC_DISPATCH_SUCCESS = 'logisticDispatch/GET_LOGISTIC_DISPATCH_SUCCESS';
export const GET_LOGISTIC_DISPATCH_END = 'logisticDispatch/GET_LOGISTIC_DISPATCH_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const listLogisticDispatch = (params={}) => async(dispatch, getState) => {
    let logisticDispatch = getState()["logisticDispatch"];
    dispatch({
        type : GET_LOGISTIC_DISPATCH_REQUEST,
    });
    let ret = await fetchGet('v1/logisticdispatch/'+params.logistic,params).then(res=>{
        let payload = logisticDispatch.logisticDispatch;
        payload[params.logistic] = res.data.body;
        dispatch({
            type : GET_LOGISTIC_DISPATCH_SUCCESS,
            payload,
        });
    }).finally(()=>{
        dispatch({
            type : GET_LOGISTIC_DISPATCH_END
        });
    });
    return ret;
}
