export const GET_Product_REQUEST = 'product/GET_Product_REQUEST';
export const GET_Product_SUCCESS = 'product/GET_Product_SUCCESS';
export const GET_Product_END = 'product/GET_Product_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const addProduct = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Product_REQUEST,
    });
    let ret = await fetchPut('v1/product',params).finally(()=>{
        dispatch({
            type : GET_Product_END
        });
    });
    return ret;
}

export const listProducts = (params={}) => async(dispatch, getState) => {
    let productData = getState()["product"];
    dispatch({
        type : GET_Product_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = productData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = productData.pageNum
    }
    let ret = await fetchGet('v1/product',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                productData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : GET_Product_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Product_END
        });
    });
    return ret;
}

export const actionProduct = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Product_REQUEST,
    });
    let ret = await fetchPatch('v1/product/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_Product_END
        });
    });
    return ret;
}

export const deleteProduct = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Product_REQUEST,
    });
    let ret = await fetchDelete('v1/product/'+params.id, null, params).finally(()=>{
        dispatch({
            type : GET_Product_END
        });
    });
    return ret;
}