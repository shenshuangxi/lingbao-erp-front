export const EDIS_SERVICE_REQUEST = 'EDIS/EDIS_SERVICE_REQUEST';
export const EDIS_SERVICE_SUCCESS = 'EDIS/EDIS_SERVICE_SUCCESS';
export const EDIS_SERVICE_DIRECTION_SUCCESS = 'EDIS/EDIS_SERVICE_DIRECTION_SUCCESS';
export const EDIS_SERVICE_END = 'EDIS/EDIS_SERVICE_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getServiceList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_SERVICE_REQUEST,
    });
    let ret = await fetchGet('v1/edisservice', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_SERVICE_SUCCESS,
                payload: res.data.body,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_SERVICE_END
        });
    });
    return ret;
}

export const getDirections = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_SERVICE_REQUEST,
    });
    let ret = await fetchGet('v1/edisservice/'+params.edisServiceId+'/directions', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_SERVICE_DIRECTION_SUCCESS,
                payload: res.data.body,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_SERVICE_END
        });
    });
    return ret;
}

export const syncService = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_SERVICE_REQUEST,
    });
    let ret = await fetchPost('v1/edisservice', params).finally(()=>{
        dispatch({
            type : EDIS_SERVICE_END
        });
    });
    return ret;
}