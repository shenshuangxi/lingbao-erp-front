export const LOGISTIC_ORDER_REQUEST = 'logisticOrder/LOGISTIC_ORDER_REQUEST';
export const LOGISTIC_ORDER_SUCCESS = 'logisticOrder/LOGISTIC_ORDER_SUCCESS';
export const LOGISTIC_ORDER_END = 'logisticOrder/LOGISTIC_ORDER_END';

import {fetchGet, fetchPost, fetchDelete, fetchPatch, fetchPut} from '../../a_util/fetch';

export const listLogistcOrder = (params={}) => async(dispatch, getState) => {
    let logisticOrderData = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = logisticOrderData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = logisticOrderData.pageNum
    }
    let ret = await fetchGet('v1/logisticorder', params).then(res=>{
        if (res.status === 200) {
            let payload = {
                logisticOrders: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : LOGISTIC_ORDER_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}

export const addLogistcOrder = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchPut('v1/logisticorder', params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}

export const syncLogistcOrder = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchPost('v1/logisticorder/sync', params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}



export const deleteLogisticOrder = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchDelete('v1/logisticorder/'+params.id, null, params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}

export const actionLogistcOrder = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchPatch('v1/logisticorder/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}

export const getLogistcOrderDetail = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchGet('v1/logisticorder/'+params.id+'/detail', params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}

export const printLogisticPackageLable = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticOrder"];
    dispatch({
        type : LOGISTIC_ORDER_REQUEST,
    });
    let ret = await fetchPost('v1/logisticorder', params).finally(()=>{
        dispatch({
            type : LOGISTIC_ORDER_END
        });
    });
    return ret;
}


