export const GET_Country_REQUEST = 'country/GET_Country_REQUEST';
export const GET_Country_SUCCESS = 'country/GET_Country_SUCCESS';
export const GET_Country_END = 'country/GET_Country_END';

import {fetchGet} from '../../a_util/fetch';


export const getCountryList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Country_REQUEST,
    });
    let ret = await fetchGet('/v1/enums/country',params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : GET_Country_SUCCESS,
                payload: res.data.body
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Country_END
        });
    });
    return ret;
}