export const GET_RetailPlatformAccount_REQUEST = 'retailPlatformAccount/GET_RetailPlatformAccount_REQUEST';
export const GET_RetailPlatformAccount_SUCCESS = 'retailPlatformAccount/GET_RetailPlatformAccount_SUCCESS';
export const GET_RetailPlatformAccount_END = 'retailPlatformAccount/GET_RetailPlatformAccount_END';
export const SET_RetailPlatformAccount_SEARCH_PARAMS = 'retailPlatformAccount/SET_RetailPlatformAccount_SEARCH_PARAMS';

import {fetchGet, fetchPut, fetchDelete, fetchPost, fetchPatch} from '../../a_util/fetch';


export const getRetailPlatformAccountList = (params={}) => async(dispatch, getState) => {
    // let data = getState()["retailPlatformAccount"];
    dispatch({
        type : GET_RetailPlatformAccount_REQUEST,
    });
    let ret = await fetchGet('v1/ebayseller',params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : GET_RetailPlatformAccount_SUCCESS,
                payload : res.data.body
            });
            return res.data.isSuccess;
        }
    }).finally(()=>{
        dispatch({
            type : GET_RetailPlatformAccount_END
        });
    });
    return ret;
}

export const refreshToken = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_RetailPlatformAccount_REQUEST,
    });
    let ret = await fetchGet('v1/ebayseller/'+params.id+"/refreshToken", params).then(res=>{
        if (res.status === 200) {
            return res.data.body;
        }
    }).finally(()=>{
        dispatch({
            type : GET_RetailPlatformAccount_END
        });
    });
    return ret;
}


export const addAccount = (params={}) => async(dispatch, getState) => {
    let data = getState()["retailPlatformAccount"];
    dispatch({
        type : GET_RetailPlatformAccount_REQUEST,
    });
    let ret = await fetchPut('v1/ebayseller', params).finally(()=>{
        dispatch({
            type : GET_RetailPlatformAccount_END
        });
    });
    return ret;
}

export const actionAccount = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_RetailPlatformAccount_REQUEST,
    });
    let ret = await fetchPatch('v1/ebayseller/'+params.id, params).finally(()=>{
        dispatch({
            type : GET_RetailPlatformAccount_END
        });
    });
    return ret;
}
