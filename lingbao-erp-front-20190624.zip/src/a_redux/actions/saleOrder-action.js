export const GET_SaleOrder_REQUEST = 'saleOrder/GET_SaleOrder_REQUEST';
export const GET_SaleOrder_END = 'saleOrder/GET_SaleOrder_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const getSaleOrderList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_SaleOrder_REQUEST,
    });
    let ret = await fetchGet('v1/order',params).finally(()=>{
        dispatch({
            type : GET_SaleOrder_END
        });
    });
    return ret;
}


export const getSaleOrderDetail = (params={}) => async(dispatch, getState) => {
    let data = getState()["saleOrder"];
    dispatch({
        type : GET_SaleOrder_REQUEST,
    });
    let ret = await fetchGet('v1/order/'+params.id+"/detail", params).finally(()=>{
        dispatch({
            type : GET_SaleOrder_END
        });
    });
    return ret;
}

export const syncSaleOrder = (params={}) => async(dispatch, getState) => {
    let data = getState()["saleOrder"];
    dispatch({
        type : GET_SaleOrder_REQUEST,
    });
    let ret = await fetchPost('v1/order/sync', params).finally(()=>{
        dispatch({
            type : GET_SaleOrder_END
        });
    });
    return ret;
}