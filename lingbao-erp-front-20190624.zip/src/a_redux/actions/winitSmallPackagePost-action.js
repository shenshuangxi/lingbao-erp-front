export const GET_WinitSmallPackagePost_REQUEST = 'winitSmallPackagePost/GET_WinitSmallPackagePost_REQUEST';
export const GET_WinitSmallPackagePost_SUCCESS = 'winitSmallPackagePost/GET_WinitSmallPackagePost_SUCCESS';
export const GET_WinitSmallPackagePost_END = 'winitSmallPackagePost/GET_WinitSmallPackagePost_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const listWinitSmallPackagePost = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_WinitSmallPackagePost_REQUEST,
    });
    let ret = await fetchGet('v1/winitsmallpackagepost',params).then(res=>{
        let payload = res.data.body;
        dispatch({
            type : GET_WinitSmallPackagePost_SUCCESS,
            payload,
        });
    }).finally(()=>{
        dispatch({
            type : GET_WinitSmallPackagePost_END
        });
    });
    return ret;
}

export const syncWinitSmallPackagePost = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_WinitSmallPackagePost_REQUEST,
    });
    let ret = await fetchPost('v1/winitsmallpackagepost/sync', params).finally(()=>{
        dispatch({
            type : GET_WinitSmallPackagePost_END
        });
    });
    return ret;
}