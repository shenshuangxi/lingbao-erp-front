export const GET_Stock_Statistcs_REQUEST = 'Stock_Statistcs/GET_Stock_Statistcs_REQUEST';
export const GET_Stock_Statistcs_SUCCESS = 'Stock_Statistcs/GET_Stock_Statistcs_SUCCESS';
export const GET_Stock_Statistcs_END = 'Stock_Statistcs/GET_Stock_Statistcs_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const listStockStatistics = (params={}) => async(dispatch, getState) => {
    let stockData = getState()["stockStatistics"];
    dispatch({
        type : GET_Stock_Statistcs_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = stockData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = stockData.pageNum
    }
    let ret = await fetchGet('v1/stockstatices',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                stockStatisticsData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            console.log(payload)
            dispatch({
                type : GET_Stock_Statistcs_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Stock_Statistcs_END
        });
    });
    return ret;
}