export const YANWEN_CHANNEL_REQUEST = 'YANWEN/YANWEN_CHANNEL_REQUEST';
export const YANWEN_CHANNEL_SUCCESS = 'YANWEN/YANWEN_CHANNEL_SUCCESS';
export const YANWEN_CHANNEL_END = 'YANWEN/YANWEN_CHANNEL_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getChannelList = (params={}) => async(dispatch, getState) => {
    let yanwenchannel = getState()["yanwenchannel"];
    dispatch({
        type : YANWEN_CHANNEL_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = yanwenchannel.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = yanwenchannel.pageNum
    }
    let ret = await fetchGet('v1/yanwenchannel', params).then(res=>{
        if (res.status === 200) {
            let payload = {
                yanwenChannels: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : YANWEN_CHANNEL_SUCCESS,
                payload: payload,
            })
        }
    }).finally(()=>{
        dispatch({
            type : YANWEN_CHANNEL_END
        });
    });
    return ret;
}

export const syncChannel = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : YANWEN_CHANNEL_REQUEST,
    });
    let ret = await fetchPost('v1/yanwenchannel', params).finally(()=>{
        dispatch({
            type : YANWEN_CHANNEL_END
        });
    });
    return ret;
}