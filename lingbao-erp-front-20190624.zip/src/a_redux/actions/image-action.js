export const Image_REQUEST = 'image/Image_REQUEST';
export const Image_END = 'image/Image_END';

import {fetchGet, fetchPost, fetchDelete, fetchPatch} from '../../a_util/fetch';


export const listImage = (params={}) => async(dispatch, getState) => {
    let data = getState()["image"];
    dispatch({
        type : Image_REQUEST,
    });
    let ret = await fetchGet('v1/image', params).finally(()=>{
        dispatch({
            type : Image_END
        });
    });
    return ret;
}

export const deleteImage = (params) => async(dispatch, getState) => {
    let data = getState()["image"];
    dispatch({
        type : Image_REQUEST,
    });
    let ret = await fetchDelete('v1/image/'+params.id, null, params).finally(()=>{
        dispatch({
            type : Image_END
        });
    });
    return ret;
}

export const actionImage = (params) => async(dispatch, getState) => {
    let data = getState()["image"];
    dispatch({
        type : Image_REQUEST,
    });
    let ret = await fetchPatch('v1/image/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : Image_END
        });
    });
    return ret;
}