export const EDIS_ADDRESS_REQUEST = 'EDIS/EDIS_ADDRESS_REQUEST';
export const EDIS_ADDRESS_SUCCESS = 'EDIS/EDIS_ADDRESS_SUCCESS';
export const EDIS_ADDRESS_END = 'EDIS/EDIS_ADDRESS_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getEdisAddressList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_ADDRESS_REQUEST,
    });
    let ret = await fetchGet('v1/edisaddress', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_ADDRESS_SUCCESS,
                payload: res.data.body.rows,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_ADDRESS_END
        });
    });
    return ret;
}


export const addEdisAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edisaddress"];
    dispatch({
        type : EDIS_ADDRESS_REQUEST,
    });
    let ret = await fetchPut('v1/edisaddress', params).finally(()=>{
        dispatch({
            type : EDIS_ADDRESS_END
        });
    });
    return ret;
}

export const actionEdisAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edisaddress"];
    dispatch({
        type : EDIS_ADDRESS_REQUEST,
    });
    let ret = await fetchPatch('v1/edisaddress/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : EDIS_ADDRESS_END
        });
    });
    return ret;
}

export const deleteEdisAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edisaddress"];
    dispatch({
        type : EDIS_ADDRESS_REQUEST,
    });
    let ret = await fetchDelete('v1/edisaddress/'+params.id, null, params).finally(()=>{
        dispatch({
            type : EDIS_ADDRESS_END
        });
    });
    return ret;
}