export const EDIS_ADDRESS_CODE_REQUEST = 'EDIS/EDIS_ADDRESS_CODE_REQUEST';
export const EDIS_ADDRESS_CODE_SUCCESS = 'EDIS/EDIS_ADDRESS_CODE_SUCCESS';
export const EDIS_ADDRESS_CODE_END = 'EDIS/EDIS_ADDRESS_CODE_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getEdisAddressCodeList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_ADDRESS_CODE_REQUEST,
    });
    let ret = await fetchGet('v1/edisaddresscode', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_ADDRESS_CODE_SUCCESS,
                payload: res.data.body.rows,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_ADDRESS_CODE_END
        });
    });
    return ret;
}