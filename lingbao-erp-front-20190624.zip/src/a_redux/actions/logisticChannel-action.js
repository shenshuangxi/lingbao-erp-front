export const GET_LogisticChannel_REQUEST = 'logisticChannel/GET_LogisticChannel_REQUEST';
export const GET_LogisticChannel_SUCCESS = 'logisticChannel/GET_LogisticChannel_SUCCESS';
export const GET_LogisticChannel_END = 'logisticChannel/GET_LogisticChannel_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const listLogisticChannel = (params={}) => async(dispatch, getState) => {
    let logisticChannel = getState()["logisticChannel"];
    dispatch({
        type : GET_LogisticChannel_REQUEST,
    });
    let ret = await fetchGet('v1/logisticchannel/'+params.logistic,params).then(res=>{
        let payload = logisticChannel.logisticChannel;
        payload[params.logistic] = res.data.body;
        dispatch({
            type : GET_LogisticChannel_SUCCESS,
            payload,
        });
    }).finally(()=>{
        dispatch({
            type : GET_LogisticChannel_END
        });
    });
    return ret;
}
