export const EDIS_SEND_ADDRESS_REQUEST = 'EDIS/EDIS_SEND_ADDRESS_REQUEST';
export const EDIS_SEND_ADDRESS_SUCCESS = 'EDIS/EDIS_SEND_ADDRESS_SUCCESS';
export const EDIS_SEND_ADDRESS_END = 'EDIS/EDIS_SEND_ADDRESS_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getEdisSendAddressList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_SEND_ADDRESS_REQUEST,
    });
    let ret = await fetchGet('v1/edissendaddress', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_SEND_ADDRESS_SUCCESS,
                payload: res.data.body.rows,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_SEND_ADDRESS_END
        });
    });
    return ret;
}

export const syncEdisSendAddressList = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissendaddress"];
    dispatch({
        type : EDIS_SEND_ADDRESS_REQUEST,
    });
    let ret = await fetchPost('v1/edissendaddress', params).finally(()=>{
        dispatch({
            type : EDIS_SEND_ADDRESS_END
        });
    });
    return ret;
}

export const addEdisSendAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissendaddress"];
    dispatch({
        type : EDIS_SEND_ADDRESS_REQUEST,
    });
    let ret = await fetchPut('v1/edissendaddress', params).finally(()=>{
        dispatch({
            type : EDIS_SEND_ADDRESS_END
        });
    });
    return ret;
}

export const actionEdisSendAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissendaddress"];
    dispatch({
        type : EDIS_SEND_ADDRESS_REQUEST,
    });
    let ret = await fetchPatch('v1/edissendaddress/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : EDIS_SEND_ADDRESS_END
        });
    });
    return ret;
}

export const deleteEdisSendAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissendaddress"];
    dispatch({
        type : EDIS_SEND_ADDRESS_REQUEST,
    });
    let ret = await fetchDelete('v1/edissendaddress/'+params.id, null, params).finally(()=>{
        dispatch({
            type : EDIS_SEND_ADDRESS_END
        });
    });
    return ret;
}