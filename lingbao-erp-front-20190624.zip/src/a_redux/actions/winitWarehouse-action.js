export const GET_WinitWarehouse_REQUEST = 'winitWarehouse/GET_WinitWarehouse_REQUEST';
export const GET_WinitWarehouse_SUCCESS = 'winitWarehouse/GET_WinitWarehouse_SUCCESS';
export const GET_WinitWarehouse_END = 'winitWarehouse/GET_WinitWarehouse_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const listWinitWarehouse = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_WinitWarehouse_REQUEST,
    });
    let ret = await fetchGet('v1/winitwarehouse',params).then(res=>{
        let payload = res.data.body;
        dispatch({
            type : GET_WinitWarehouse_SUCCESS,
            payload,
        });
    }).finally(()=>{
        dispatch({
            type : GET_WinitWarehouse_END
        });
    });
    return ret;
}

export const syncWinitWarehouse = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_WinitWarehouse_REQUEST,
    });
    let ret = await fetchPost('v1/winitwarehouse/sync', params).finally(()=>{
        dispatch({
            type : GET_WinitWarehouse_END
        });
    });
    return ret;
}