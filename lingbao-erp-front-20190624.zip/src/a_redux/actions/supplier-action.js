export const GET_Supplier_REQUEST = 'supplier/GET_Supplier_REQUEST';
export const GET_Supplier_SUCCESS = 'supplier/GET_Supplier_SUCCESS';
export const GET_Supplier_END = 'supplier/GET_Supplier_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const addSupplier = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Supplier_REQUEST,
    });
    let ret = await fetchPut('v1/supplier',params).finally(()=>{
        dispatch({
            type : GET_Supplier_END
        });
    });
    return ret;
}

export const listSuppliers = (params={}) => async(dispatch, getState) => {
    let supplierData = getState()["supplier"];
    dispatch({
        type : GET_Supplier_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = supplierData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = supplierData.pageNum
    }
    let ret = await fetchGet('v1/supplier',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                supplierData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : GET_Supplier_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Supplier_END
        });
    });
    return ret;
}

export const actionSupplier = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Supplier_REQUEST,
    });
    let ret = await fetchPatch('v1/supplier/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_Supplier_END
        });
    });
    return ret;
}

export const deleteSupplier = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Supplier_REQUEST,
    });
    let ret = await fetchDelete('v1/Supplier/'+params.id, params).finally(()=>{
        dispatch({
            type : GET_Supplier_END
        });
    });
    return ret;
}