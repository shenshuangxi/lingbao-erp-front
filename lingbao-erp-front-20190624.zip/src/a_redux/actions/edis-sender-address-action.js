export const EDIS_SENDER_ADDRESS_REQUEST = 'EDIS/EDIS_SENDER_ADDRESS_REQUEST';
export const EDIS_SENDER_ADDRESS_SUCCESS = 'EDIS/EDIS_SENDER_ADDRESS_SUCCESS';
export const EDIS_SENDER_ADDRESS_END = 'EDIS/EDIS_SENDER_ADDRESS_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getEdisSenderAddressList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_SENDER_ADDRESS_REQUEST,
    });
    let ret = await fetchGet('v1/edissenderaddress', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_SENDER_ADDRESS_SUCCESS,
                payload: res.data.body.rows,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_SENDER_ADDRESS_END
        });
    });
    return ret;
}


export const syncEdisSenderAddressList = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissenderaddress"];
    dispatch({
        type : EDIS_SENDER_ADDRESS_REQUEST,
    });
    let ret = await fetchPost('v1/edissenderaddress', params).finally(()=>{
        dispatch({
            type : EDIS_SENDER_ADDRESS_END
        });
    });
    return ret;
}

export const addEdisSenderAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissenderaddress"];
    dispatch({
        type : EDIS_SENDER_ADDRESS_REQUEST,
    });
    let ret = await fetchPut('v1/edissenderaddress', params).finally(()=>{
        dispatch({
            type : EDIS_SENDER_ADDRESS_END
        });
    });
    return ret;
}

export const actionEdisSenderAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissenderaddress"];
    dispatch({
        type : EDIS_SENDER_ADDRESS_REQUEST,
    });
    let ret = await fetchPatch('v1/edissenderaddress/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : EDIS_SENDER_ADDRESS_END
        });
    });
    return ret;
}

export const deleteEdisSenderAddress = (params={}) => async(dispatch, getState) => {
    let data = getState()["edissenderaddress"];
    dispatch({
        type : EDIS_SENDER_ADDRESS_REQUEST,
    });
    let ret = await fetchDelete('v1/edissenderaddress/'+params.id, null, params).finally(()=>{
        dispatch({
            type : EDIS_SENDER_ADDRESS_END
        });
    });
    return ret;
}