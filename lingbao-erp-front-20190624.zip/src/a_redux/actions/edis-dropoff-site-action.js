export const EDIS_DROPOFF_SITE_REQUEST = 'EDIS/EDIS_DROPOFF_SITE_REQUEST';
export const EDIS_DROPOFF_SITE_SUCCESS = 'EDIS/EDIS_DROPOFF_SITE_SUCCESS';
export const EDIS_DROPOFF_SITE_END = 'EDIS/EDIS_DROPOFF_SITE_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const getEdisDropoffSiteList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_DROPOFF_SITE_REQUEST,
    });
    let ret = await fetchGet('v1/edisdropoffsite', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : EDIS_DROPOFF_SITE_SUCCESS,
                payload: res.data.body,
            })
        }
    }).finally(()=>{
        dispatch({
            type : EDIS_DROPOFF_SITE_END
        });
    });
    return ret;
}

export const syncEdisDropoffSite = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : EDIS_DROPOFF_SITE_REQUEST,
    });
    let ret = await fetchPost('v1/edisdropoffsite', params).finally(()=>{
        dispatch({
            type : EDIS_DROPOFF_SITE_END
        });
    });
    return ret;
}