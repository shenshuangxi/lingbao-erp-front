export const GET_Platform_REQUEST = 'platform/GET_Platform_REQUEST';
export const GET_Platform_SUCCESS = 'platform/GET_Platform_SUCCESS';
export const GET_Platform_END = 'platform/GET_Platform_END';

import {fetchGet} from '../../a_util/fetch';


export const getPlatformList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Platform_REQUEST,
    });
    let ret = await fetchGet('/v1/enums/platform',params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : GET_Platform_SUCCESS,
                payload: res.data.body
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Platform_END
        });
    });
    return ret;
}