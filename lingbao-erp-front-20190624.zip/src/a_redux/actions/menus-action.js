export const GET_MENU_INFO_REQUEST = 'menu/GET_MENU_INFO_REQUEST';
export const GET_MENU_INFO_SUCCESS = 'menu/GET_MENU_INFO_SUCCESS';
export const GET_MENU_INFO_FAIL = 'menu/GET_MENU_INFO_FAIL';

import menuJson from '../../config/menu.json';


export const getMenuInfo = (params={}) => async(dispatch, getState) => {
    let data = getState()["menuInfo"];
    dispatch({
        type : GET_MENU_INFO_REQUEST,
        payload : params
    });
    dispatch({
        type : GET_MENU_INFO_SUCCESS,
        payload : menuJson
    });
}