export const Directory_REQUEST = 'directory/Directory_REQUEST';
export const Directory_SUCCESS = 'directory/Directory_SUCCESS';
export const Directory_END = 'directory/Directory_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


function makeTreeData(directoryData) {
    let ret = [];
    let treeNode = {};
    let isChildren = new Set();
    directoryData.forEach(item => {
        treeNode[item.id] = item;
        if (treeNode[item.pid]) {
            if (treeNode[item.pid].children) {
                treeNode[item.pid].children = [...treeNode[item.pid].children, item];
                treeNode[item.pid].children.sort((a, b) => {
                    return a.sort - b.sort;
                })
            } else {
                treeNode[item.pid].children = [item];
            }
            isChildren.add(String(item.id));
        }
    });
    Object.keys(treeNode).forEach(itemId => {
        if (treeNode[treeNode[itemId].pid] && !isChildren.has(itemId)) {
            if (treeNode[treeNode[itemId].pid].children) {
                treeNode[treeNode[itemId].pid].children = [...treeNode[treeNode[itemId].pid].children, treeNode[itemId]];
                treeNode[treeNode[itemId].pid].children.sort((a, b) => {
                    return a.sort - b.sort;
                });
            } else {
                treeNode[treeNode[itemId].pid].children = [treeNode[itemId]];
            }
            isChildren.add(itemId);
        }
    })
    Object.keys(treeNode).forEach(itemId => {
        if (isChildren.has(itemId)) {

        } else {
            ret = [...ret, treeNode[itemId]];
        }
    })
    ret.sort((a, b) => {
        return a.sort - b.sort;
    })
    return ret;
}

export const getDirectoryList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : Directory_REQUEST,
    });
    let ret = await fetchGet('v1/directory',params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : Directory_SUCCESS,
                payload: makeTreeData(res.data.body),
            })
        }
    }).finally(()=>{
        dispatch({
            type : Directory_END
        });
    });
    return ret;
}


export const addDirectory = (params={}) => async(dispatch, getState) => {
    let data = getState()["directory"];
    dispatch({
        type : Directory_REQUEST,
    });
    let ret = await fetchPut('v1/directory', params).finally(()=>{
        dispatch({
            type : Directory_END
        });
    });
    return ret;
}

export const actionDirectory = (params={}) => async(dispatch, getState) => {
    let data = getState()["directory"];
    dispatch({
        type : Directory_REQUEST,
    });
    let ret = await fetchPatch('v1/directory/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : Directory_END
        });
    });
    return ret;
}

export const deleteDirectory = (params={}) => async(dispatch, getState) => {
    let data = getState()["directory"];
    dispatch({
        type : Directory_REQUEST,
    });
    let ret = await fetchDelete('v1/directory/'+params.id, null, params).finally(()=>{
        dispatch({
            type : Directory_END
        });
    });
    return ret;
}