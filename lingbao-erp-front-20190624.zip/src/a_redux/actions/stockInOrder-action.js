export const GET_Stock_In_Order_REQUEST = 'Stock_In_Order/GET_Stock_In_Order_REQUEST';
export const GET_Stock_In_Order_SUCCESS = 'Stock_In_Order/GET_Stock_In_Order_SUCCESS';
export const GET_Stock_In_Order_END = 'Stock_In_Order/GET_Stock_In_Order_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const listStockInOrders = (params={}) => async(dispatch, getState) => {
    let stockData = getState()["stockInOrder"];
    dispatch({
        type : GET_Stock_In_Order_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = stockData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = stockData.pageNum
    }
    let ret = await fetchGet('v1/stockinorder',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                stockInOrderData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            console.log(payload)
            dispatch({
                type : GET_Stock_In_Order_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Stock_In_Order_END
        });
    });
    return ret;
}

export const addStockInOrder = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_In_Order_REQUEST,
    });
    let ret = await fetchPut('v1/stockinorder',params).finally(()=>{
        dispatch({
            type : GET_Stock_In_Order_END
        });
    });
    return ret;
}

export const actionStockInOrder = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_In_Order_REQUEST,
    });
    let ret = await fetchPatch('v1/stockinorder/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_Stock_In_Order_END
        });
    });
    return ret;
}

export const deleteStockInOrder = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_In_Order_REQUEST,
    });
    let ret = await fetchDelete('v1/stockinorder/'+params.id, null, params).finally(()=>{
        dispatch({
            type : GET_Stock_In_Order_END
        });
    });
    return ret;
}