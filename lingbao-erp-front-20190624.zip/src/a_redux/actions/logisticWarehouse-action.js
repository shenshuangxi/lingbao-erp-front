export const GET_LogisticWarehouse_REQUEST = 'logisticWarehouse/GET_LogisticWarehouse_REQUEST';
export const GET_LogisticWarehouse_SUCCESS = 'logisticWarehouse/GET_LogisticWarehouse_SUCCESS';
export const GET_LogisticWarehouse_END = 'logisticWarehouse/GET_LogisticWarehouse_END';

import {fetchGet, fetchPost} from '../../a_util/fetch';


export const listLogisticWarehouse = (params={}) => async(dispatch, getState) => {
    let logisticWarehouse = getState()["logisticWarehouse"];
    dispatch({
        type : GET_LogisticWarehouse_REQUEST,
    });
    let ret = await fetchGet('v1/logisticwarehouse/'+params.logistic+'/'+params.service,params).then(res=>{
        let payload = logisticWarehouse.logisticWarehouse;
        payload[params.logistic] = res.data.body;
        dispatch({
            type : GET_LogisticWarehouse_SUCCESS,
            payload,
        });
    }).finally(()=>{
        dispatch({
            type : GET_LogisticWarehouse_END
        });
    });
    return ret;
}
