export const GET_Stock_Action_REQUEST = 'stockaction/GET_Stock_Action_REQUEST';
export const GET_Stock_Action_SUCCESS = 'stockaction/GET_Stock_Action_SUCCESS';
export const GET_Stock_Action_END = 'stockaction/GET_Stock_Action_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const listStockActions = (params={}) => async(dispatch, getState) => {
    let stockData = getState()["stockaction"];
    dispatch({
        type : GET_Stock_Action_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = stockData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = stockData.pageNum
    }
    let ret = await fetchGet('v1/stockaction',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                stockActionData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : GET_Stock_Action_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Stock_Action_END
        });
    });
    return ret;
}