export const LOGISTIC_RULE_REQUEST = 'logisticRule/LOGISTIC_RULE_REQUEST';
export const LOGISTIC_RULE_SUCCESS = 'logisticRule/LOGISTIC_RULE_SUCCESS';
export const LOGISTIC_RULE_END = 'logisticRule/LOGISTIC_RULE_END';

import {fetchGet, fetchPost, fetchDelete, fetchPatch, fetchPut} from '../../a_util/fetch';

export const listLogistcRule = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticRule"];
    dispatch({
        type : LOGISTIC_RULE_REQUEST,
    });
    let ret = await fetchGet('v1/logisticrule', params).then(res=>{
        if (res.status === 200) {
            dispatch({
                type : LOGISTIC_RULE_SUCCESS,
                payload: res.data.body
            })
        }
    }).finally(()=>{
        dispatch({
            type : LOGISTIC_RULE_END
        });
    });
    return ret;
}

export const addLogistcRule = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticRule"];
    dispatch({
        type : LOGISTIC_RULE_REQUEST,
    });
    let ret = await fetchPut('v1/logisticrule', params).finally(()=>{
        dispatch({
            type : LOGISTIC_RULE_END
        });
    });
    return ret;
}



export const deleteLogisticRule = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticRule"];
    dispatch({
        type : LOGISTIC_RULE_REQUEST,
    });
    let ret = await fetchDelete('v1/logisticrule/'+params.id, null, params).finally(()=>{
        dispatch({
            type : LOGISTIC_RULE_END
        });
    });
    return ret;
}

export const actionLogistcRule = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticRule"];
    dispatch({
        type : LOGISTIC_RULE_REQUEST,
    });
    let ret = await fetchPatch('v1/logisticrule/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : LOGISTIC_RULE_END
        });
    });
    return ret;
}

export const getLogistcRuleDetail = (params={}) => async(dispatch, getState) => {
    let data = getState()["logisticRule"];
    dispatch({
        type : LOGISTIC_RULE_REQUEST,
    });
    let ret = await fetchGet('v1/logisticrule/'+params.id+'/detail', params).finally(()=>{
        dispatch({
            type : LOGISTIC_RULE_END
        });
    });
    return ret;
}


