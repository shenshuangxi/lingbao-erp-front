export const GET_Stock_REQUEST = 'stock/GET_Stock_REQUEST';
export const GET_Stock_SUCCESS = 'stock/GET_Stock_SUCCESS';
export const GET_Stock_END = 'stock/GET_Stock_END';

import {fetchGet, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';


export const addStock = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_REQUEST,
    });
    let ret = await fetchPut('v1/stock',params).finally(()=>{
        dispatch({
            type : GET_Stock_END
        });
    });
    return ret;
}

export const listStocks = (params={}) => async(dispatch, getState) => {
    let stockData = getState()["stock"];
    dispatch({
        type : GET_Stock_REQUEST,
    });
    if (params.pageSize===undefined) {
        params.pageSize = stockData.pageSize
    }
    if (params.pageNum===undefined) {
        params.pageNum = stockData.pageNum
    }
    let ret = await fetchGet('v1/stock',params).then(res=>{
        if (res.status === 200) {
            let payload = {
                stockData: res.data.body.rows,
                pageSize: params.pageSize,
                pageNum: params.pageNum,
                pageTotal: res.data.body.total,
            }
            dispatch({
                type : GET_Stock_SUCCESS,
                payload
            })
        }
    }).finally(()=>{
        dispatch({
            type : GET_Stock_END
        });
    });
    return ret;
}

export const actionStock = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_REQUEST,
    });
    let ret = await fetchPatch('v1/stock/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_Stock_END
        });
    });
    return ret;
}

export const deleteStock = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_Stock_REQUEST,
    });
    let ret = await fetchDelete('v1/stock/'+params.id, null, params).finally(()=>{
        dispatch({
            type : GET_Stock_END
        });
    });
    return ret;
}