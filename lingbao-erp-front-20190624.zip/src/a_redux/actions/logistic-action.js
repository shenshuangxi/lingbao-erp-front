export const LOGISTIC_REQUEST = 'logistic/LOGISTIC_REQUEST';
export const LOGISTIC_SUCCESS = 'logistic/LOGISTIC_REQUEST';
export const LOGISTIC_END = 'logistic/LOGISTIC_END';

import {fetchGet, fetchPost, fetchDelete, fetchPatch} from '../../a_util/fetch';

export const listLogistc = (params={}) => async(dispatch, getState) => {
    let logistic = getState()["logistic"];
    dispatch({
        type : LOGISTIC_REQUEST,
    });
    let ret = await fetchGet('v1/logistic/'+params.platform, params).then(res=>{
        if (res.status === 200) {
            let payload = logistic.logistics;
            payload[params.platform] = res.data.body;
            dispatch({
                type : LOGISTIC_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : LOGISTIC_END
        });
    });
    return ret;
}

export const syncLogistc = (params={}) => async(dispatch, getState) => {
    let logistic = getState()["logistic"];
    dispatch({
        type : LOGISTIC_REQUEST,
    });
    let ret = await fetchPost('v1/logistic/sync/'+params.platform, params).then(res=>{
        if (res.status === 200) {
            let payload = logistic.logistics;
            dispatch({
                type : LOGISTIC_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : LOGISTIC_END
        });
    });
    return ret;
}



