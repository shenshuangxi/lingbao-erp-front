export const GET_ConsumerInfo_REQUEST = 'consumerInfo/GET_ConsumerInfo_REQUEST';
export const GET_ConsumerInfo_END = 'consumerInfo/GET_ConsumerInfo_END';

import {fetchGet, fetchPut, fetchPatch} from '../../a_util/fetch';


export const getConsumerInfoList = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_ConsumerInfo_REQUEST,
    });
    let ret = await fetchGet('v1/customer',params).finally(()=>{
        dispatch({
            type : GET_ConsumerInfo_END
        });
    });
    return ret;
}

export const actionCustomerInfo = (params={}) => async(dispatch, getState) => {
    dispatch({
        type : GET_ConsumerInfo_REQUEST,
    });
    let ret = await fetchPatch('v1/customer/'+params.id+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_ConsumerInfo_END
        });
    });
    return ret;
}


export const getConsumerInfoDetail = (params={}) => async(dispatch, getState) => {
    let data = getState()["ConsumerInfo"];
    dispatch({
        type : GET_ConsumerInfo_REQUEST,
    });
    let ret = await fetchGet('v1/customer/'+params.id+"/contactInfos", params).finally(()=>{
        dispatch({
            type : GET_ConsumerInfo_END
        });
    });
    return ret;
}

export const actionConsumerContactInfo = (params={}) => async(dispatch, getState) => {
    let data = getState()["ConsumerInfo"];
    dispatch({
        type : GET_ConsumerInfo_REQUEST,
    });
    let ret = await fetchPatch('v1/customer/'+params.customerId+"/contactInfo/"+params.contactInfoId+'/'+params.action, params).finally(()=>{
        dispatch({
            type : GET_ConsumerInfo_END
        });
    });
    return ret;
}
