export const ENUMS_REQUEST = 'enums/ENUMS_REQUEST';
export const ENUMS_SUCCESS = 'enums/ENUMS_SUCCESS';
export const ENUMS_END = 'enums/ENUMS_END';

import {fetchGet, fetchPost, fetchPut, fetchPatch, fetchDelete} from '../../a_util/fetch';

export const enumsCountry = (params={}) => async (dispatch, getState) => {
    let enums = getState()["enums"];
    dispatch({
        type : ENUMS_REQUEST,
    });
    let ret = await fetchGet('v1/enums/country',params).then(res=>{
        if (res.status === 200) {
            let payload = enums.enums;
            payload['country'] = res.data.body;
            dispatch({
                type : ENUMS_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : ENUMS_END
        });
    });
    return ret;
}

export const enumsPlatform = (params={}) => async (dispatch, getState) => {
    let enums = getState()["enums"];
    dispatch({
        type : ENUMS_REQUEST,
    });
    let ret = await fetchGet('v1/enums/platform',params).then(res=>{
        if (res.status === 200) {
            let payload = enums.enums;
            payload['platform'] = res.data.body;
            dispatch({
                type : ENUMS_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : ENUMS_END
        });
    });
    return ret;
}

export const enumsLogistic = (params={}) => async (dispatch, getState) => {
    let enums = getState()["enums"];
    dispatch({
        type : ENUMS_REQUEST,
    });
    let ret = await fetchGet('v1/enums/logistic',params).then(res=>{
        if (res.status === 200) {
            let payload = enums.enums;
            payload['logistic'] = res.data.body;
            dispatch({
                type : ENUMS_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : ENUMS_END
        });
    });
    return ret;
}

export const enumsDispatchType = (params={}) => async (dispatch, getState) => {
    let enums = getState()["enums"];
    dispatch({
        type : ENUMS_REQUEST,
    });
    let ret = await fetchGet('v1/enums/dispatchtype',params).then(res=>{
        if (res.status === 200) {
            let payload = enums.enums;
            payload['dispatchtype'] = res.data.body;
            dispatch({
                type : ENUMS_SUCCESS,
                payload,
            });
        }
    }).finally(()=>{
        dispatch({
            type : ENUMS_END
        });
    });
    return ret;
}