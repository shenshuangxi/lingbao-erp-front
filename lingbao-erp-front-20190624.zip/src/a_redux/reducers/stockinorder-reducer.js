import { GET_Stock_In_Order_REQUEST, GET_Stock_In_Order_SUCCESS, GET_Stock_In_Order_END, } from '../actions/stockInOrder-action';


const stockInOrder = (state={
    loading: false,
    stockInOrderData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Stock_In_Order_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Stock_In_Order_SUCCESS:
        console.log(action)
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Stock_In_Order_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default stockInOrder;