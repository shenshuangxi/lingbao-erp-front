import { EDIS_ADDRESS_CODE_REQUEST, EDIS_ADDRESS_CODE_SUCCESS, EDIS_ADDRESS_CODE_END, } from '../actions/edis-address-code-action';


const edisaddresscode = (state={
    loading: false,
    errMsg:'',
    edisAddressCodes:[],
}, action) => {
    switch (action.type) {
        case EDIS_ADDRESS_CODE_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_ADDRESS_CODE_SUCCESS:
            return {
                ...state,
                edisAddressCodes: action.payload,
                loading: false,
            }
        case EDIS_ADDRESS_CODE_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edisaddresscode;