import { LOGISTIC_REQUEST, LOGISTIC_SUCCESS, LOGISTIC_END} from '../actions/logistic-action';


const logistic = (state={
    loading: false,
    errMsg:'',
    logistics:{},
}, action) => {
    switch (action.type) {
        case LOGISTIC_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case LOGISTIC_SUCCESS:
            return {
                ...state,
                logistics: action.payload,
                loading: true,
            }
        case LOGISTIC_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logistic;