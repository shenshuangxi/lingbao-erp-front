import { GET_Stock_Statistcs_REQUEST, GET_Stock_Statistcs_SUCCESS, GET_Stock_Statistcs_END, } from '../actions/stockstatistics-action';


const stockStatistics = (state={
    loading: false,
    stockStatisticsData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Stock_Statistcs_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Stock_Statistcs_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Stock_Statistcs_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default stockStatistics;