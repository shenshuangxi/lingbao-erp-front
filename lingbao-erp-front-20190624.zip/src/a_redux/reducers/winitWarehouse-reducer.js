import { GET_WinitWarehouse_REQUEST, GET_WinitWarehouse_SUCCESS, GET_WinitWarehouse_END} from '../actions/winitWarehouse-action';


const winitWarehouse = (state={
    loading: false,
    winitWarehouseData:[],
}, action) => {
    switch (action.type) {
        case GET_WinitWarehouse_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case  GET_WinitWarehouse_SUCCESS:
            return {
                ...state,
                winitWarehouseData: action.payload,
                loading: false,
            }
        case GET_WinitWarehouse_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default winitWarehouse;