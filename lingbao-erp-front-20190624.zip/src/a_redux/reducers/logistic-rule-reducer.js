import { LOGISTIC_RULE_REQUEST, LOGISTIC_RULE_SUCCESS, LOGISTIC_RULE_END} from '../actions/logistic-rule-action';


const logisticRule = (state={
    loading: false,
    logisticRules: [],
    errMsg:'',
}, action) => {
    switch (action.type) {
        case LOGISTIC_RULE_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case LOGISTIC_RULE_SUCCESS:
            return {
                ...state,
                logisticRules: action.payload,
                loading: true,
            }
        case LOGISTIC_RULE_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logisticRule;