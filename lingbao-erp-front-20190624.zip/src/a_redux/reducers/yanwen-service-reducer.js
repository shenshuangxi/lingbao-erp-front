import { YANWEN_CHANNEL_REQUEST, YANWEN_CHANNEL_SUCCESS, YANWEN_CHANNEL_END, } from '../actions/yanwen-service-action';


const yanwenchannel = (state={
    loading: false,
    errMsg:'',
    yanwenChannels: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal:0,
}, action) => {
    switch (action.type) {
        case YANWEN_CHANNEL_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case YANWEN_CHANNEL_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case YANWEN_CHANNEL_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default yanwenchannel;