import { EDIS_SERVICE_REQUEST, EDIS_SERVICE_SUCCESS, EDIS_SERVICE_DIRECTION_SUCCESS, EDIS_SERVICE_END, } from '../actions/edis-service-action';


const edisservice = (state={
    loading: false,
    errMsg:'',
    edisServices:[],
    edisDirections: [],
    total:0,
}, action) => {
    switch (action.type) {
        case EDIS_SERVICE_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_SERVICE_SUCCESS:
            return {
                ...state,
                edisServices: action.payload.rows,
                total: action.payload.total,
                loading: false,
            }
        case EDIS_SERVICE_DIRECTION_SUCCESS:
            return {
                ...state,
                edisDirections: action.payload,
                loading: false,
            }
        case EDIS_SERVICE_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edisservice;