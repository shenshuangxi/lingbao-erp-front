import { GET_MENU_INFO_REQUEST, GET_MENU_INFO_SUCCESS,  GET_MENU_INFO_FAIL} from '../actions/menus-action';


const menuInfo = (state={
    loading: false,
    menus: [],
    errMsg:'',
}, action) => {
    switch (action.type) {
        case GET_MENU_INFO_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_MENU_INFO_SUCCESS:
            return {
                ...state,
                loading: false,
                menus: action.payload,
            }
        case GET_MENU_INFO_FAIL:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default menuInfo;