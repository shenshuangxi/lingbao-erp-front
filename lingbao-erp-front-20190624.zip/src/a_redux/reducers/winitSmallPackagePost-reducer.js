import { GET_WinitSmallPackagePost_REQUEST, GET_WinitSmallPackagePost_SUCCESS, GET_WinitSmallPackagePost_END, } from '../actions/winitSmallPackagePost-action';


const winitSmallPackagePost = (state={
    loading: false,
    winitSmallPackagePostData:[],
}, action) => {
    switch (action.type) {
        case GET_WinitSmallPackagePost_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case  GET_WinitSmallPackagePost_SUCCESS:
            return {
                ...state,
                winitSmallPackagePostData: action.payload,
                loading: false,
            }
        case GET_WinitSmallPackagePost_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default winitSmallPackagePost;