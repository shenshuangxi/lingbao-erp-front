import { GET_SaleOrder_REQUEST, 
    GET_SaleOrder_END, } from '../actions/saleOrder-action';


const saleOrder = (state={
    loading: false,
}, action) => {
    switch (action.type) {
        case GET_SaleOrder_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_SaleOrder_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default saleOrder;