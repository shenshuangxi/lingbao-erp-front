import { EDIS_SENDER_ADDRESS_REQUEST, EDIS_SENDER_ADDRESS_SUCCESS, EDIS_SENDER_ADDRESS_END, } from '../actions/edis-sender-address-action';


const edissenderaddress = (state={
    loading: false,
    errMsg:'',
    edisSenderAddresses:[],
}, action) => {
    switch (action.type) {
        case EDIS_SENDER_ADDRESS_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_SENDER_ADDRESS_SUCCESS:
            return {
                ...state,
                edisSenderAddresses: action.payload,
                loading: false,
            }
        case EDIS_SENDER_ADDRESS_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edissenderaddress;