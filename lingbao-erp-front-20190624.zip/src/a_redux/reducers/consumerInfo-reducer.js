import { GET_ConsumerInfo_REQUEST, 
    GET_ConsumerInfo_END, } from '../actions/consumerInfo-action';


const consumerInfo = (state={
    loading: false,
}, action) => {
    switch (action.type) {
        case GET_ConsumerInfo_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_ConsumerInfo_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default consumerInfo;