import { LOGISTIC_ORDER_REQUEST, LOGISTIC_ORDER_SUCCESS, LOGISTIC_ORDER_END} from '../actions/logistic-order-action';


const logisticOrder = (state={
    loading: false,
    logisticOrders: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal:0,
    errMsg:'',
}, action) => {
    switch (action.type) {
        case LOGISTIC_ORDER_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case LOGISTIC_ORDER_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case LOGISTIC_ORDER_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logisticOrder;