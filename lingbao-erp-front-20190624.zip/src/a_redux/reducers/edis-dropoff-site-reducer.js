import { EDIS_DROPOFF_SITE_REQUEST, EDIS_DROPOFF_SITE_SUCCESS, EDIS_DROPOFF_SITE_END, } from '../actions/edis-dropoff-site-action';


const edisdropoffsite = (state={
    loading: false,
    errMsg:'',
    edisDropoffSites:[],
    total:0,
}, action) => {
    switch (action.type) {
        case EDIS_DROPOFF_SITE_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_DROPOFF_SITE_SUCCESS:
            return {
                ...state,
                edisDropoffSites: action.payload.rows,
                total: action.payload.total,
                loading: false,
            }
        case EDIS_DROPOFF_SITE_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edisdropoffsite;