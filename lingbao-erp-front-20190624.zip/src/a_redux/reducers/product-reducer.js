import { GET_Product_REQUEST, GET_Product_SUCCESS, GET_Product_END } from '../actions/product-action';


const product = (state={
    loading: false,
    productData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Product_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Product_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Product_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default product;