import { EDIS_ADDRESS_REQUEST, EDIS_ADDRESS_SUCCESS, EDIS_ADDRESS_END, } from '../actions/edis-address-action';


const edisaddress = (state={
    loading: false,
    errMsg:'',
    edisAddresses:[],
}, action) => {
    switch (action.type) {
        case EDIS_ADDRESS_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_ADDRESS_SUCCESS:
            return {
                ...state,
                edisAddresses: action.payload,
                loading: false,
            }
        case EDIS_ADDRESS_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edisaddress;