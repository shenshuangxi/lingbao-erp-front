import { Image_END, Image_REQUEST} from '../actions/image-action';


const menuInfo = (state={
    loading: false,
    errMsg:'',
}, action) => {
    switch (action.type) {
        case Image_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case Image_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default menuInfo;