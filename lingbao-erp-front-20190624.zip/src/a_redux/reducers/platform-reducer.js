import { GET_Platform_REQUEST, 
    GET_Platform_SUCCESS, GET_Platform_END} from '../actions/platform-action';


const platform = (state={
    loading: false,
    platforms: [],
}, action) => {
    switch (action.type) {
        case GET_Platform_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Platform_SUCCESS:
            return {
                ...state,
                loading: false,
                platforms: action.payload,
            }
        case GET_Platform_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default platform;