import { GET_Country_REQUEST, 
    GET_Country_SUCCESS, GET_Country_END} from '../actions/country-action';


const country = (state={
    loading: false,
    countries: [],
}, action) => {
    switch (action.type) {
        case GET_Country_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Country_SUCCESS:
            return {
                ...state,
                loading: false,
                countries: action.payload,
            }
        case GET_Country_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default country;