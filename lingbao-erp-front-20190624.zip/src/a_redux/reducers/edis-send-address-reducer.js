import { EDIS_SEND_ADDRESS_REQUEST, EDIS_SEND_ADDRESS_SUCCESS, EDIS_SEND_ADDRESS_END, } from '../actions/edis-send-address-action';


const edissendaddress = (state={
    loading: false,
    errMsg:'',
    edisSendAddresses:[],
}, action) => {
    switch (action.type) {
        case EDIS_SEND_ADDRESS_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case EDIS_SEND_ADDRESS_SUCCESS:
            return {
                ...state,
                edisSendAddresses: action.payload,
                loading: false,
            }
        case EDIS_SEND_ADDRESS_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default edissendaddress;