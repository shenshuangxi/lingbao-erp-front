import { GET_Supplier_REQUEST, GET_Supplier_SUCCESS, GET_Supplier_END, } from '../actions/supplier-action';


const supplier = (state={
    loading: false,
    supplierData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Supplier_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Supplier_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Supplier_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default supplier;