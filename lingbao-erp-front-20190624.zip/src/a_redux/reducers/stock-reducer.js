import { GET_Stock_REQUEST, GET_Stock_SUCCESS, GET_Stock_END, } from '../actions/stock-action';


const stock = (state={
    loading: false,
    stockData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Stock_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Stock_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Stock_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default stock;