import { GET_RetailPlatformAccount_REQUEST, 
    GET_RetailPlatformAccount_SUCCESS, 
    GET_RetailPlatformAccount_END,} from '../actions/retailPlatformAccount-action';


const retailPlatformAccount = (state={
    loading: false,
    pageData: [],
    pageTotal:0,
    errMsg:'',
}, action) => {
    switch (action.type) {
        case GET_RetailPlatformAccount_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_RetailPlatformAccount_SUCCESS:
            return {
                ...state,
                loading: false,
                pageData: action.payload.rows,
                pageTotal: action.payload.total,
            }
        case GET_RetailPlatformAccount_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default retailPlatformAccount;