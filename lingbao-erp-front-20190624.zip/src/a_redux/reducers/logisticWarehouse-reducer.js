import { GET_LogisticWarehouse_REQUEST, GET_LogisticWarehouse_SUCCESS, GET_LogisticWarehouse_END} from '../actions/logisticWarehouse-action';


const logisticWarehouse = (state={
    loading: false,
    logisticWarehouse:{},
}, action) => {
    switch (action.type) {
        case GET_LogisticWarehouse_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case  GET_LogisticWarehouse_SUCCESS:
            return {
                ...state,
                logisticWarehouse: action.payload,
                loading: false,
            }
        case GET_LogisticWarehouse_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logisticWarehouse;