import { GET_Stock_Action_REQUEST, GET_Stock_Action_SUCCESS, GET_Stock_Action_END, } from '../actions/stockaction-action';


const stockAction = (state={
    loading: false,
    stockActionData: [],
    pageSize: 10,
    pageNum: 1,
    pageTotal: 0,
}, action) => {
    switch (action.type) {
        case GET_Stock_Action_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case GET_Stock_Action_SUCCESS:
            return {
                ...state,
                ...action.payload,
                loading: false,
            }
        case GET_Stock_Action_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default stockAction;