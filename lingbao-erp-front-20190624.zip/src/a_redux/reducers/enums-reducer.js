import { ENUMS_REQUEST, ENUMS_SUCCESS, ENUMS_END, } from '../actions/enums-action';



const enums = (state={
    loading: false,
    errMsg:'',
    enums:{},
}, action) => {
    switch (action.type) {
        case ENUMS_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case ENUMS_SUCCESS:
            return {
                ...state,
                enums: action.payload,
                loading: false,
            }
        case ENUMS_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default enums;