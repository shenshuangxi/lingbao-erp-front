import { GET_LogisticChannel_REQUEST, GET_LogisticChannel_SUCCESS, GET_LogisticChannel_END} from '../actions/logisticChannel-action';


const logisticChannel = (state={
    loading: false,
    logisticChannel:{},
}, action) => {
    switch (action.type) {
        case GET_LogisticChannel_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case  GET_LogisticChannel_SUCCESS:
            return {
                ...state,
                logisticChannel: action.payload,
                loading: false,
            }
        case GET_LogisticChannel_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logisticChannel;