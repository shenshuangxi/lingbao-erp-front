import { Directory_REQUEST, Directory_SUCCESS, Directory_END, } from '../actions/directory-action';


const directory = (state={
    loading: false,
    directoryData: [],
}, action) => {
    switch (action.type) {
        case Directory_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case Directory_SUCCESS:
            return {
                ...state,
                loading: false,
                directoryData: action.payload,
            }
        case Directory_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default directory;