import { GET_LOGISTIC_DISPATCH_REQUEST, GET_LOGISTIC_DISPATCH_SUCCESS, GET_LOGISTIC_DISPATCH_END} from '../actions/logistic-dispatch-action';


const logisticDispatch = (state={
    loading: false,
    logisticDispatch:{},
}, action) => {
    switch (action.type) {
        case GET_LOGISTIC_DISPATCH_REQUEST:
            return {
                ...state,
                loading: true,
            }
        case  GET_LOGISTIC_DISPATCH_SUCCESS:
            return {
                ...state,
                logisticDispatch: action.payload,
                loading: false,
            }
        case GET_LOGISTIC_DISPATCH_END:
            return {
                ...state,
                loading: false,
            }
        default: 
            return state;
    }
} 

export default logisticDispatch;