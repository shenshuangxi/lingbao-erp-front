import menuInfo from './reducers/menuInfo-reducer';
import retailPlatformAccount from './reducers/retailPlatformAccount-reducer';
import consumerInfo from './reducers/consumerInfo-reducer';
import country from './reducers/country-reducer';
import platform from './reducers/platform-reducer';
import saleOrder from './reducers/saleOrder-reducer';
import directory from './reducers/directory-reducer';
import image from './reducers/image-reducer';

import enums from './reducers/enums-reducer';
import logistic from './reducers/logisctic-reducer';
import logisticWarehouse from './reducers/logisticWarehouse-reducer';
import logisticChannel from './reducers/logisticChannel-reducer';
import logisticDispatch from './reducers/logistic-dispatch-reducer';
import logisticRule from './reducers/logistic-rule-reducer';
import logisticOrder from './reducers/logistic-order-reducer';
import winitSmallPackagePost from './reducers/winitSmallPackagePost-reducer';
import winitWarehouse from './reducers/winitWarehouse-reducer';

import product from './reducers/product-reducer';
import supplier from './reducers/supplier-reducer';
import stock from './reducers/stock-reducer';
import stockInOrder from './reducers/stockinorder-reducer';
import stockStatistics from './reducers/stockstatistics-reducer';
import stockAction from './reducers/stockaction-reducer';
import edisaddress from './reducers/edis-address-reducer';
import edissenderaddress from './reducers/edis-sender-address-reducer';
import edissendaddress from './reducers/edis-send-address-reducer';
import edisaddresscode from './reducers/edis-address-code-reducer';
import edisdropoffsite from './reducers/edis-dropoff-site-reducer';
import edisservice from './reducers/edis-service-reducer';
import yanwenchannel from './reducers/yanwen-service-reducer';

export default function combineReducers(state={}, action) {
    return {
        menuInfo : menuInfo(state.menuInfo, action),
        retailPlatformAccount: retailPlatformAccount(state.retailPlatformAccount, action),
        consumerInfo: consumerInfo(state.consumerInfo, action),
        country: country(state.country, action),
        platform: platform(state.platform, action),
        saleOrder: saleOrder(state.saleOrder, action),
        directory: directory(state.directory, action),
        image: image(state.image, action),
        enums: enums(state.enums, action),
        logistic: logistic(state.logistic, action),
        logisticWarehouse: logisticWarehouse(state.logisticWarehouse, action),
        logisticChannel: logisticChannel(state.logisticChannel, action),
        logisticDispatch: logisticDispatch(state.logisticDispatch, action),
        logisticRule: logisticRule(state.logisticRule, action),
        logisticOrder: logisticOrder(state.logisticOrder, action),
        winitSmallPackagePost: winitSmallPackagePost(state.winitSmallPackagePost, action),
        winitWarehouse: winitWarehouse(state.winitWarehouse, action),
        product: product(state.product, action),
        supplier: supplier(state.supplier, action),
        stock: stock(state.stock, action),
        stockInOrder: stockInOrder(state.stockInOrder, action),
        stockStatistics: stockStatistics(state.stockStatistics, action),
        stockAction: stockAction(state.stockAction, action),
        edisaddress: edisaddress(state.edisaddress, action),
        edissenderaddress: edissenderaddress(state.edissenderaddress, action),
        edissendaddress: edissendaddress(state.edissendaddress, action),
        edisaddresscode: edisaddresscode(state.edisaddresscode, action),
        edisdropoffsite: edisdropoffsite(state.edisdropoffsite, action),
        edisservice: edisservice(state.edisservice, action),
        yanwenchannel: yanwenchannel(state.yanwenchannel, action)
    }
}