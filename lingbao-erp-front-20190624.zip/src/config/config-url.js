export const baseUrl = window._CONFIG__.get('API_URL');
export const uploadUrl = window._CONFIG__.get('UPLOAD_URL');
export const fileUrl = window._CONFIG__.get('FILE_URL');