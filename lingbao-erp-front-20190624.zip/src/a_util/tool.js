
let code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""); //索引表
let codeStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; //索引表

function arrayBufferToBase64(bytes) {
    let tail = bytes.length % 3;
    let base64 = '';
    for (let i=0; i<=bytes.length; i=i+3) {
        let v1 = code[bytes[i]>>>2];
        let v2 = code[(bytes[i]<<6)+(bytes[i+1]>>>4)];
        let v3 = code[((bytes[i+1]<<4)>>2)+(bytes[i+2]>>>6)];
        let v4 = code[(bytes[i+2]<<2)>>2];
        base64 = v1 + v2 + v3 + v4;
    }
    if (tail === 1) {
        let bit = bytes[bytes.length-1];
        let v1 = code[bit>>>2];
        let v2 = code[bit<<6];
        let v3 = '=';
        let v4 = '=';
        base64 = v1 + v2 + v3 + v4;
    } else if (tail === 2) {
        let bit1 = bytes[bytes.length-2];
        let bit2 = bytes[bytes.length-1];
        let v1 = code[bit1>>>2];
        let v2 = code[(bit1<<6)+(bit2>>>4)];
        let v3 = code[(bit2<<4)>>2];
        let v4 = '=';
        base64 = v1 + v2 + v3 + v4;
    }
    return base64;
}

function base64ToArrayBuffer(base64) {
    let binary = new Array();
    for (var i = 0; i < base64.length; i=i+4) {
        let bit1 = codeStr.indexOf(base64[i]);
        let bit2 = codeStr.indexOf(base64[i+1]);
        let bit3 = codeStr.indexOf(base64[i+2]);
        let bit4 = codeStr.indexOf(base64[i+3]);
        let byteData1 = (((bit1<<2)  & 0xFF) + (bit2>>>4)) & 0xFF;
        let byteData2 = ((((bit2<<4)  & 0xFF)  & 0xFF) + (bit3 >>>2)) & 0xff;
        let byteData3 = ((bit3<<6 & 0xff) + bit4) & 0xff;
        if (base64[i+2] === '=' && base64[i+3] === '=') {
            binary.push(byteData1);
        } else if (base64[i+2] !== '=' && base64[i+3] === '=') {
            binary.push(byteData1);
            binary.push(byteData2);
        } else {
            binary.push(byteData1);
            binary.push(byteData2);
            binary.push(byteData3);
        }
    }
    return binary;
}

const tool = {
    /**
        * 清除一个对象中那些属性为空值的属性
        * 0 算有效值
        * **/
    clearNull(obj) {
        const temp = {};
        Object.keys(obj).forEach((item) => {
            if (obj[item] === 0 || !!obj[item]) {
                temp[item] = obj[item];
            }
        });
        return temp;
    },

    fileSize(fileSize) {
        return fileSize > 1024 * 1024 ? 
                    (fileSize / (1024 * 1024)).toFixed(2) + ' MBit' : 
                    fileSize > 1024 ? 
                        (fileSize / 1024).toFixed(2) + ' KBit' 
                        : 
                        fileSize.toFixed(2) + ' Bit'
    },

    base64Encode(arrayBuffer) {
        return arrayBufferToBase64(arrayBuffer);
    },

    base64Decode(base64) {
        return base64ToArrayBuffer(base64);
    }

}

export default tool;