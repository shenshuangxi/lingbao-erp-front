
import axios from 'axios';
import qs from 'qs';
import errorsUtils from '../error/errorsUtils';
import {baseUrl} from '../config/config-url';

//请求时的拦截
axios.interceptors.request.use(config => {
    return Object.assign(config, {timeout:25000});
}, err => {
    message.error('请求超时!', 5);
    return Promise.resolve(err);
});

//响应时的拦截
axios.interceptors.response.use(data => {
    // 返回响应时做一些处理
    return data;
},err => {
    // 当响应异常时做一些处理
    errorsUtils.handleError(err);
    return Promise.reject(err);
});

const getHeaders = (headers={}) =>{
    return Object.assign({},{
        'Accept': 'application/manage+json;charset=utf-8',
        'Content-Type': 'application/json;charset=utf-8'
    },headers||{});
};


export function fetchGetBlob(url, header, bodyObj = {}) {
    return axios({
        url: `${url}`,
        method: 'get',
        headers: getHeaders(header),
        responseType: 'blob',
        params: bodyObj,
    });
}


// delete请求
export function fetchDelete(url, headers, bodyObj = {}) {
    return axios({
        url: `${baseUrl}/${url}`,
        method: 'delete',
        headers: getHeaders(headers),
        params: bodyObj,
        data: JSON.stringify(bodyObj)
    });
}


// patch请求
export function fetchPatch(url, bodyObj = {}) {
    return axios({
        url: `${baseUrl}/${url}`,
        method: 'patch',
        headers: getHeaders(),
        data: JSON.stringify(bodyObj)
    });
}

// get请求
export function fetchGet(url, bodyObj = {}) {
    return axios({
        url: `${baseUrl}/${url}`,
        method: 'get',
        headers: getHeaders(),
        params: bodyObj,
        paramsSerializer: params => {
            return qs.stringify(params, { indices: false })
        }
    });
}

// post请求
export function fetchPost(url, bodyObj = {}) {
    return axios({
        url: `${baseUrl}/${url}`,
        method: 'post',
        headers: getHeaders(),
        data: JSON.stringify(bodyObj)
    });
}

// post请求
export function fetchPut(url, bodyObj = {}) {
    return axios({
        url: `${baseUrl}/${url}`,
        method: 'put',
        headers: getHeaders(),
        data: JSON.stringify(bodyObj)
    });
}