import React from 'react';
import ReactDom from 'react-dom';
import {Provider} from 'react-redux';

import getRouter from './a_router/router';
import store from './a_redux/store'

import './style/layout.less';
import 'antd/dist/antd.css';


ReactDom.render(
    <Provider store={store}>
        {
            getRouter()
        }
    </Provider>, 
    document.getElementById('app'))