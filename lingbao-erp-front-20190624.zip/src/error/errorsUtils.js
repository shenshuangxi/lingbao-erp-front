import {message} from "antd";

let errorsUtils = {
    handleError: (error) => {
        message.destroy();
        if (error.response !== undefined) {
            if (error.response.status === 500) {
                message.error("系统错误code=" + error.response.data.message, 10);
            } 
            else if (error.response.status === 400) {
                message.error(error.response.data.message, 10);
            }
            else if (error.response.status === 449) {
                message.error("需要验证码验证码!", 10);
            }
            else if (error.response.status === 404) {
                message.error("服务异常 code="+error.response.status, 10);
            }
            else if (error.response.status === 403) {
                message.error("当前用户未登录!", 10);
            }
            else if (error.response.status === 401) {
                message.error("登录后访问未授权资源!", 10);
            }
            else if (error.response.status === 504) {
                message.error("网络超时!", 10);
            }  else {
                message.error("连接错误: code="+error.response.status, 10);
            }
        } else if (error.code === 'ECONNABORTED') {
            message.error("请求超时, 请重新刷新!", 5);
        } else if (error.code === 12) {
            message.error(error.message, 5);
        } else if (error.message === "Network Error") {
            message.error("网络异常, 操作失败", 5);
        }
    },
};

export default errorsUtils;