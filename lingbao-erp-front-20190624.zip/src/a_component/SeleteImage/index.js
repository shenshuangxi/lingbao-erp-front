import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import P from 'prop-types';
import {Button, Input, Form, Tree, Spin, Pagination} from 'antd';
import './selectImage.less';
import { getDirectoryList } from '../../a_redux/actions/directory-action';
import { listImage } from '../../a_redux/actions/image-action';
import tool from '../../a_util/tool';

const TreeNode = Tree.TreeNode;

@connect(
    (state) => ({
        image: state.image,
        directoryTree: state.directory,
    }),
    (dispatch) => ({
        actions: bindActionCreators({ getDirectoryList, listImage }, dispatch),
    })
)

@Form.create()
export default class SelectImage extends React.Component {

    static propTypes = {
        onRef: P.func,
        images: P.array,
    }

    constructor(props) {
        super(props);
        this.state = {
            images: [],
            searchImageName: undefined,
            pageNum: 0,
            pageSize: 10,
            pageTotal: 0,
            selectImages: props.images?props.images:[],
            treeSelect: { title: "全部", key: '0' },
        }
    }

    componentDidMount() {
        this.props.onRef(this);
        this.onRefreshDirectory();
        this.onRefreshImages();
    }

    onRefreshDirectory = () => {
        let self = this;
        self.props.actions.getDirectoryList();
    }


    onRefreshImages = (pageNum = this.state.pageNum, pageSize = this.state.pageSize, directoryId=this.state.treeSelect.key ) => {
        const params = {
            directoryId: directoryId === '0' ? undefined : directoryId,
            name: this.state.searchImageName,
            pageNum: pageNum,
            pageSize: pageSize,
        };
        this.props.actions.listImage(tool.clearNull(params)).then(res => {
            this.setState({
                images: res.data.body.rows,
                pageTotal: res.data.body.total,
            })
        })
    }

    onSearch = () => {
        this.onRefreshImages(1);
    }

    searchImageNameChange = (e) => {
        this.setState({
            searchImageName: e.target.value
        })
    }
    

    onTreeSelect = (treeSelect) => {
        this.setState({
            treeSelect
        })
    }


    makeImages = (images) => {
        let selectImageSet = new Set(this.state.selectImages.map(item=>item.id));
        return images.filter(item=>!selectImageSet.has(item.id)).map((image, index) => {
            let dispFileSize = tool.fileSize(image.size);
            let dispBottomTitle = dispFileSize;
            return <li key={index} style={{fontSize:'10px', margin:'10px'}}>
                <center>
                    <span>{'名称:'+image.name}</span>
                </center>
                <img className='image' src={image.path} title={image.name+' ['+dispBottomTitle+']'}></img>
                <center>
                    <a style={{ verticalAlign: 'middle', cursor: 'pointer' }} onClick={()=>this.onSelectImage(image)}>选择</a>
                    <span style={{ cursor: 'pointer' }} title={image.name} >{dispFileSize}</span>
                </center>
            </li>
        });
    }

    makeSelectImages = (selectImages) => {
        return selectImages.map((image, index) => {
            let dispFileSize = tool.fileSize(image.size);
            let dispBottomTitle = dispFileSize;
            return <li key={index} style={{fontSize:'8px'}}>
                <img className='image' src={image.path} title={image.name+' ['+dispBottomTitle+']'}></img>
                <center>
                    <a style={{ verticalAlign: 'middle', cursor: 'pointer' }} onClick={()=>this.onRemoveSelectImage(image)}>删除</a>
                </center>
            </li>
        });
    }

    onRemoveSelectImage = (image) => {
        let selectImages = this.state.selectImages;
        selectImages = selectImages.filter(item=>item.id!==image.id);
        this.setState({
            selectImages
        })
    }

    onSelectImage = (image) => {
        let selectImages = this.state.selectImages;
        selectImages = [...selectImages, image]
        this.setState({
            selectImages
        })
        
    }

    onRefreshDirectory = () => {
        let self = this;
        self.props.actions.getDirectoryList();
    }

    onTreeSelect = (keys, e) => {
        let treeSelect = { title: '全部', key: '0' };
        if (e.selected) {   // 选中
            const p = e.node.props;
            treeSelect = { title: p.title, key: p.eventKey };
        }
        this.setState({
            treeSelect,
        });
        this.onRefreshImages(this.state.pageNum, this.state.pageSize, treeSelect.key);
    }

    makeTreeDom = (data) => {
        return data.map((item) => {
            if (item.children) {
                return (
                    <TreeNode title={item.name} key={`${item.id}`}>
                        {this.makeTreeDom(item.children)}
                    </TreeNode>
                );
            } else {
                return <TreeNode title={item.name} key={`${item.id}`} />;
            }
        });
    }

    onShowImageSizeChange = (page, pageSize) => {
        this.onRefreshImages(page, pageSize);
    }

    render() {
        const {treeSelect, pageNum, pageTotal} = this.state;
        const {searchImageName, images, selectImages } = this.state;
        const { directoryData } = this.props.directoryTree;
        return (
            <div>
                <div className='selectImagePage'>
                    <div className='l'>
                        <div className='title'>目录结构<Button loading={this.props.directoryTree.loading} onClick={this.onRefreshDirectory.bind(this)} style={{ float: 'right', top: '4px' }}>刷新</Button></div>
                        <Tree
                            showLine
                            defaultExpandedKeys={['0']}
                            onSelect={this.onTreeSelect.bind(this)}
                            selectedKeys={[treeSelect.key]}
                        >
                            <TreeNode title="全部" key="0">
                                {this.makeTreeDom(directoryData)}
                            </TreeNode>
                        </Tree>
                    </div>
                    <div className='c'>
                        <div style={{ width: '100%', height: '100%' }}>
                            <div className="g-search">
                                <ul className="search-ul">
                                    <li><Input placeholder="图片名称" onChange={(e) => this.searchImageNameChange(e)} value={searchImageName}/></li>
                                    <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                                </ul>
                            </div>
                            <div style={{ display: 'flex', flexFlow: 'row wrap' }}>
                                {
                                    this.makeImages(images)
                                }
                                {
                                    this.props.image.loading && <Spin tip="Loading..."></Spin>
                                }
                            </div>
                            <div style={{textAlign:'center'}}>
                                <Pagination 
                                    showSizeChanger 
                                    showQuickJumper 
                                    pageSizeOptions={['4', '5', '8', '10', '12', '20', '24', '30', '32', '40']}
                                    onChange={this.onShowImageSizeChange.bind(this)} 
                                    onShowSizeChange={this.onShowImageSizeChange.bind(this)} 
                                    current={pageNum} 
                                    total={pageTotal} 
                                />
                            </div>
                        </div>
                    </div>
                    <div className='r'>
                        <div style={{ width: '100%', height: '100%' }}>
                            <div style={{ display: 'flex', flexFlow: 'row wrap' }}>
                                {
                                    this.makeSelectImages(selectImages)
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        )
    }

} 