import React from 'react';
import P from 'prop-types';
import './index.less';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Table, Icon, Button, Input, Modal, Form, message, TreeSelect, Spin, Pagination } from 'antd';
import tool from '../../a_util/tool';
import { listImage, deleteImage, actionImage } from '../../a_redux/actions/image-action';

const FormItem = Form.Item;
const TreeNode = TreeSelect.TreeNode;


@connect(
    (state) => ({
        image: state.image,
        directoryTree: state.directory,
    }),
    (dispatch) => ({
        actions: bindActionCreators({ listImage, deleteImage, actionImage }, dispatch),
    })
)

@Form.create()
export default class ErpImages extends React.Component {

    static propTypes = {
        directory: P.any,
        onRef: P.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            images: [],
            searchImageName: undefined,
            showMoveDirectoryModal: false,
            pageNum: 0,
            pageSize: 10,
            pageTotal: 0,
        };
    }

    componentDidMount() {
        if (this.props.onRef) {
            this.props.onRef(this);
        }
        this.onRefreshImages();
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.directory !== this.props.directory) {
            this.onRefreshImages(nextProps.directory);
        }
    }

    onRefreshImages = (directoryId = this.props.directory, pageNum = this.state.pageNum, pageSize = this.state.pageSize) => {
        const params = {
            directoryId: directoryId === '0' ? undefined : directoryId,
            name: this.state.searchImageName,
            pageNum: pageNum,
            pageSize: pageSize,
        };
        this.props.actions.listImage(tool.clearNull(params)).then(res => {
            this.setState({
                images: res.data.body.rows,
                pageTotal: res.data.body.total,
            })
        })
    }

    directoryTreeToFlat = (directoryTreeData) => {
        let data = [];
        for (let i = 0; i < directoryTreeData.length; i++) {
            data.push(directoryTreeData[i]);
            if (directoryTreeData[i].children) {
                data.push(this.directoryTreeToFlat(directoryTreeData[i].children))
            }
        }
        return data;
    }

    getDirectoryById = (directoryId) => {
        const { directoryTreeData } = this.props.directoryTree;
        let directoryData = this.directoryTreeToFlat(directoryTreeData);
        let data = directoryData.filter(item => item.id === directoryId);
        return data.length > 0 ? data[0] : undefined;
    }


    makeImages = (images) => {
        return images.map((image, index) => {
            let dispFileSize = tool.fileSize(image.size);
            let checked = image.checked?true:false;
            return (
                <li key={index} className='liImage' >
                    <center>
                        <span>{'目录:'+image.directoryName}</span>&nbsp;
                        <span>{'名称:'+image.name}</span>
                    </center>
                    <img  onClick={this.onOpenMoveModal.bind(this, 'edit', image)} src={image.path} title={image.name}></img>
                    <center>
                        <input type='checkbox' onChange={this.onFileCheckChange.bind(this)} value={image.id} checked={checked} style={{ verticalAlign: 'middle', cursor: 'pointer' }} />
                        <span style={{ cursor: 'pointer' }} title={image.name} >{dispFileSize}</span>
                    </center>
                </li>
            ); 
        });
    }

    onFileCheckChange = (e) => {
        let images = this.state.images;
        let image = images.filter(item => String(item.id) === e.target.value)[0]
        image.checked = !image.checked;
        this.setState({
            images
        })
    }



    onCheckAll = () => {
        let images = this.state.images;
        images.forEach(image => {
            image.checked = true;
        })
        this.setState({
            images
        })
    }

    onUnCheckAll = () => {
        let images = this.state.images;
        images.forEach(image => {
            image.checked = false;
        })
        this.setState({
            images
        })
    }

    onDelete = () => {
        let self = this;
        let canDeleteImages = this.state.images.filter(item => item.checked);
        if (canDeleteImages.length<1) {
            message.error("请选择一条数据");
            return;
        }
        Promise.all(canDeleteImages.map(image => {
            let params = {
                id: image.id,
            }
            return self.props.actions.deleteImage(params)
        })).then(function (ress) {
            if (ress.filter(res=>res.status===200).length>0) {
                self.onRefreshImages();
            }
        });
    }

    onOpenMoveModal = (action, image) => {
        if (image) {
            image.checked = true;
        }
        this.setState({
            action: action,
            selectImage: image,
            showMoveDirectoryModal: true,
        });
    }

    onCommitMoveDirectoryModal = () => {
        let self = this;
        self.props.form.validateFields([
            'directory',
            'name',
        ], (err, values) => {
            if (err) {
                return false;
            }
            if (self.state.selectImage) {
                let params = {
                    id: self.state.selectImage.id,
                    directoryId: values.directory,
                    name : values.name,
                    action: self.state.action,
                }
                self.props.actions.actionImage(params).then(res=>{
                    if (res.status === 200) {
                        self.onCloseMoveDirectoryModal();
                        self.onRefreshImages();
                    }
                })
            } else {
                let doImages = this.state.images.filter(item => item.checked);
                if (doImages.length<1) {
                    message.error("请选择一条数据");
                    return;
                }
                Promise.all(doImages.map(image => {
                    let params = {
                        id: image.id,
                        directoryId: values.directory,
                        action: self.state.action,
                    }
                    return self.props.actions.actionImage(params);
                })).then(function (ress) {
                    if (ress.filter(res=>res.status===200).length>0) {
                        self.onCloseMoveDirectoryModal();
                        self.onRefreshImages();
                    }
                });
            }
        });
    }

    onCloseMoveDirectoryModal = () => {
        this.setState({
            action: undefined,
            selectImage: undefined,
            showMoveDirectoryModal: false,
        });
        this.props.form.resetFields();
    }

    makeTreeDom = (data) => {
        return data.map((item) => {
            if (item.children) {
                return (
                    <TreeNode title={item.name} key={`${item.id}`} value={item.id}>
                        {this.makeTreeDom(item.children)}
                    </TreeNode>
                );
            } else {
                return <TreeNode title={item.name} key={`${item.id}`} value={item.id} />;
            }
        });
    }

    searchImageNameChange = (e) => {
        this.setState({
            searchImageName: e.target.value
        })
    }

    onSearch = () => {
        this.onRefreshImages();
    }

    onShowImageSizeChange = (page, pageSize) => {
        this.onRefreshImages(this.state.directory, page, pageSize);
    }

    render() {
        const { searchImageName, images, showMoveDirectoryModal, action, selectImage, pageNum, pageSize, pageTotal } = this.state;
        const { loading } = this.props.image;
        const { directoryData } = this.props.directoryTree;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            },
        };
        return (
            <div style={{ width: '100%', height: '100%' }}>
                 <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="图片名称" onChange={(e) => this.searchImageNameChange(e)} value={searchImageName}/></li>
                        <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                        <li><Button onClick={this.onCheckAll.bind(this)}>全选</Button></li>
                        <li><Button onClick={this.onUnCheckAll.bind(this)}>取消</Button></li>
                        <li><Button onClick={this.onDelete.bind(this)}>删除</Button></li>
                        <li><Button onClick={()=>this.onOpenMoveModal('move')}>移动</Button></li>
                    </ul>
                </div>
                <div style={{ display: 'flex', flexFlow: 'row wrap' }}>
                    {
                        this.makeImages(images)
                    }
                    {
                        loading && <Spin tip="Loading..."></Spin>
                    }
                    
                </div>
                <div style={{textAlign:'center'}}>
                    <Pagination 
                        showSizeChanger 
                        showQuickJumper 
                        pageSizeOptions={['4', '5', '8', '10', '12', '20', '24', '30', '32', '40']}
                        onChange={this.onShowImageSizeChange.bind(this)} 
                        onShowSizeChange={this.onShowImageSizeChange.bind(this)} 
                        current={pageNum} 
                        total={pageTotal} 
                    />
                </div>
                
                <Modal
                    title={{ 'move': '移动', 'edit': '编辑' }[action]}
                    visible={showMoveDirectoryModal}
                    onOk={this.onCommitMoveDirectoryModal.bind(this)}
                    onCancel={this.onCloseMoveDirectoryModal.bind(this)}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="目录">
                            {getFieldDecorator('directory', {
                                initialValue: (selectImage && selectImage.directoryId) ? String(selectImage.directoryId) : undefined,
                                rules: [{ required: action === 'move', message: '请选择一个目录' }]
                            })(
                                <TreeSelect
                                    style={{ width: 300 }}
                                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                                    treeDefaultExpandAll
                                >{this.makeTreeDom(directoryData || [])}</TreeSelect>
                            )}
                        </FormItem>
                        {
                            action === 'edit' &&
                            <FormItem {...formItemLayout} label="名称">
                                {getFieldDecorator('name', {
                                    initialValue: selectImage ? selectImage.name : undefined,
                                    rules: [{ required: true, message: '图片名称不能为空' }]
                                })(
                                    <Input placeholder="请填图片名称" />
                                )}
                            </FormItem>
                        }
                    </Form>
                </Modal>
            </div>
        ) 
    }

}