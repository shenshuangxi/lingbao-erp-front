import React from 'react';
import { Table } from 'antd';
import { DragDropContext, DragSource, DropTarget } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

import P from 'prop-types';

function dragDirection(
    dragIndex,
    hoverIndex,
    initialClientOffset,
    clientOffset,
    sourceClientOffset,
) {
    const hoverMiddleY = (initialClientOffset.y - sourceClientOffset.y) / 2;
    const hoverClientY = clientOffset.y - sourceClientOffset.y;
    if (dragIndex < hoverIndex && hoverClientY > hoverMiddleY) {
        return 'downward';
    }
    if (dragIndex > hoverIndex && hoverClientY < hoverMiddleY) {
        return 'upward';
    }
}

class BodyRow extends React.Component {
    render() {
        const {
            isOver,
            connectDragSource,
            connectDropTarget,
            moveRow,
            dragRow,
            clientOffset,
            sourceClientOffset,
            initialClientOffset,
            ...restProps
        } = this.props;
        const style = { ...restProps.style };

        let className = restProps.className;
        if (isOver && initialClientOffset) {
            const direction = dragDirection(
                dragRow.index,
                restProps.index,
                initialClientOffset,
                clientOffset,
                sourceClientOffset
            );
            if (direction === 'downward') {
                className += ' drop-over-downward';
            }
            if (direction === 'upward') {
                className += ' drop-over-upward';
            }
        }

        return connectDragSource(
            connectDropTarget(
                <tr
                    {...restProps}
                    className={className}
                    style={style}
                />
            )
        );
    }
}

const rowSource = {
    beginDrag(props) {
        return {
            index: props.index,
        };
    },
};

const rowTarget = {
    drop(props, monitor) {
        const dragIndex = monitor.getItem().index;
        const hoverIndex = props.index;

        // Don't replace items with themselves
        if (dragIndex === hoverIndex) {
            return;
        }

        // Time to actually perform the action
        props.moveRow(dragIndex, hoverIndex);

        // Note: we're mutating the monitor item here!
        // Generally it's better to avoid mutations,
        // but it's good here for the sake of performance
        // to avoid expensive index searches.
        monitor.getItem().index = hoverIndex;
    },
};

const DragableBodyRow = DropTarget('row', rowTarget, (connect, monitor) => ({
    connectDropTarget: connect.dropTarget(),
    isOver: monitor.isOver(),
    sourceClientOffset: monitor.getSourceClientOffset(),
}))(
    DragSource('row', rowSource, (connect, monitor) => ({
        connectDragSource: connect.dragSource(),
        dragRow: monitor.getItem(),
        clientOffset: monitor.getClientOffset(),
        initialClientOffset: monitor.getInitialClientOffset(),
    }))(BodyRow)
);

class DragSortingTable extends React.Component {

    static propTypes = {
        columns: P.array,
        dataSource: P.array,
        loading: P.bool,
        moveRowFunc: P.func,
        onDoubleClick: P.func,
        pagination: P.any,
        title: P.any,
    };

    constructor(props) {
        super(props);
        this.state = {
            columns: props.columns,
            dataSource: props.dataSource,
            loading: props.loading,
            pagination: props.pagination,
            title: this.props.title,
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            columns: nextProps.columns,
            dataSource: nextProps.dataSource,
            loading: nextProps.loading,
            moveRow: nextProps.moveRow,
            pagination: nextProps.pagination,
            title: this.props.title,
        })
    }

    components = {
        body: {
            row: DragableBodyRow,
        },
    }

    moveRow = (dragIndex, hoverIndex) => {
        // const { dataSource } = this.state;
        // const dragRow = dataSource[dragIndex];
        // this.setState(
        //     update(this.state, {
        //         dataSource: {
        //             $splice: [[dragIndex, 1], [hoverIndex, 0, dragRow]],
        //         },
        //     }),
        // );
        this.props.moveRowFunc(dragIndex, hoverIndex);
    }

    onDoubleClick = (event, record, index) => {
        this.props.onDoubleClick(event, record, index);
    }

    render() {
        const { loading, title, columns, dataSource, pagination } = this.state;
        return (
            <Table
                bordered
                title={title}
                columns={columns}
                dataSource={dataSource}
                loading={loading}
                components={this.components}
                rowClassName="pointer"
                onRow={(record, index) => ({
                    index,
                    moveRow: this.moveRow,
                    onDoubleClick: (e) => this.onDoubleClick(event, record, index),
                })}
                pagination={pagination}
            />
        );
    }
}

export default DragDropContext(HTML5Backend)(DragSortingTable);