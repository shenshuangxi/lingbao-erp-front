import React from 'react';
import axios from 'axios';
import md5 from 'md5';
import P from 'prop-types';
import { Form, Tree, Button, Input, Progress, message } from 'antd';

import { uploadUrl } from '../../config/config-url'

import './index.less';
import tool from '../../a_util/tool';


export default class UploadErpImages extends React.Component {

    static propTypes = {
        directory: P.any
    };

    constructor(props) {
        super(props);
        this.state = {
            uploadedFiles: [],
            files: [],
            cancelSource: undefined,
            uploading: false,
            percent: 0.00
        };
    }

    onChooseFile = (e) => {
        e.preventDefault();
        document.getElementById('chooseFile').click();
    }

    onFileChnage = (e) => {
        let self = this;
        let existFileSet = new Set(...[self.state.files.map(file=>file.name+":"+file.size)]);
        let chooseFiles = [...e.target.files];
        let addFiles = chooseFiles.filter(file=>!existFileSet.has(file.name+":"+file.size))
        let files = [...this.state.files, ...addFiles];
        this.setState({
            files
        });
        self.updateProgress(0, files, self.state.uploadedFiles)
        addFiles.map(file => {
            let reader = new FileReader(); // 判断图片是否加载完毕
            reader.onload = function (evt) {
                if (reader.readyState === 2) { // 加载完毕后赋值
                    file.imageSrc = evt.target.result;
                    file.checked = false;
                    let realBase64 = evt.target.result.replace(/^data:.*;base64,/, "");
                    file.md5 = md5(tool.base64Decode(realBase64));
                    self.setState({
                        files: self.state.files
                    })
                }
            }
            reader.readAsDataURL(file);
            return file;
        })
    }

    makeImages = (imageFiles) => {
        let uploadedFileSet = new Set([...this.state.uploadedFiles.map(item=>item.md5)]);
        return imageFiles.map((file, index) => {
            let dispFileSize = tool.fileSize(file.size);
            let disabled = file.md5?uploadedFileSet.has(file.md5):false;
            let checked = file.checked?!uploadedFileSet.has(file.md5):false;
            return <li key={index}>
                <img className='image' src={file.imageSrc} title={file.name}></img>
                <center style={{color: disabled?'#C0C0C0':undefined}}>
                    <input onChange={this.onFileCheckChange.bind(this)} value={file.md5} type='checkbox' disabled={disabled} checked={checked}  style={{ verticalAlign: 'middle', cursor: 'pointer' }} />
                    {
                        file.name.length > 8 ?
                            <span style={{ cursor: 'pointer' }} title={file.name} >{file.name.substring(0, 8) + '... (' + dispFileSize + ')'}</span>
                            :
                            <span style={{ cursor: 'pointer' }} title={file.name} >{file.name + '(' + dispFileSize + ')'}</span>
                    }
                </center>
            </li>
        });
    }

    onFileCheckChange = (e) => {
        let fileMd5 = e.target.value;
        let files = this.state.files;
        let file = files.filter(item=>item.md5===fileMd5)[0]
        file.checked = !file.checked;
        this.setState({
            files
        })
    }

    onDelete = () => {
        let uploadedFileSet = new Set([...this.state.uploadedFiles.map(item=>item.md5)]);
        let existFiles = this.state.files.filter(item=>uploadedFileSet.has(item.md5)||!item.checked);
        let canDeleteFiles = this.state.files.filter(item=>!uploadedFileSet.has(item.md5)&&item.checked);
        this.setState({
            files: existFiles
        })
        let target = document.getElementById('chooseFile');
        target.files = new FileList();
        target.value = '';
        target.outerHTML = target.outerHTML
        this.updateProgress(0, existFiles, this.state.uploadedFiles);
    }

    onCheckAll = () => {
        let files = this.state.files;
        files.forEach(file=>{
            file.checked = true;
        })
        this.setState({
            files
        })
    }

    onUnCheckAll = () => {
        let files = this.state.files;
        files.forEach(file=>{
            file.checked = false;
        })
        this.setState({
            files
        })
    }

    onUpload = () => {
        let self = this;
        let uploadedFileSet = new Set(...[self.state.uploadedFiles.map(file=>file.md5)]);
        let needUploadFiles = this.state.files.filter(file=>!uploadedFileSet.has(file.md5))
        if (needUploadFiles.length < 1) {
            message.error('请选择文件');
            return;
        }
        self.setState({
            uploading: true
        })
        let instance = axios.create({
            baseURL: uploadUrl,
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            onUploadProgress: function (progressEvent) {
                self.updateProgress(progressEvent.loaded);
            }
        });
        let CancelToken = axios.CancelToken;
        let source = CancelToken.source();
        self.setState({
            cancelSource : source
        })
        needUploadFiles.forEach((file, index) => {
            let formData = new FormData();
            formData.append("image", file);
            formData.append("originMd5", file.md5);
            formData.append("directoryId", self.props.directory);
            instance.post('/api/v1/image', formData, {
                cancelToken: source.token
            }).then(res => {
                if (res && res.status === 200) {
                    let uploadedFiles = [...self.state.uploadedFiles, file];
                    self.setState({
                        uploadedFiles
                    })
                    self.updateProgress(0, self.state.files, uploadedFiles)
                    if (self.state.files.length === uploadedFiles.length) {
                        self.setState({
                            uploading: false
                        })
                    }
                }
            }).catch(function (thrown) {
                message.error(thrown.message);
                if (axios.isCancel(thrown)) {
                    console.log('Request canceled', thrown.message);
                } else {
                    // 处理错误
                    source.cancel('Operation canceled by the user.');
                    self.updateProgress();
                    self.setState({
                        uploading: false
                    })
                }
            })
        })
    }

    updateProgress = (currentPercent = 0.00, allFiles = this.state.files, uploadedFiles = this.state.uploadedFiles) => {
        let self = this;
        let allFileSize = 0.00;
        let percentage = currentPercent;
        allFiles.forEach(function (file, index, array) {
            allFileSize = allFileSize + file.size;
        });
        uploadedFiles.forEach(function (file, index, array) {
            percentage = percentage + file.size;
        });
        let percent = parseFloat(parseFloat((percentage / allFileSize * 100)).toFixed(2));
        if (percent > 100) {
            percent = 100.00;
        }
        self.setState({
            percent: percent
        })
    }


    cancleUpload = () => {
        if (this.state.cancelSource) {
            this.state.cancelSource.cancel('Operation canceled by the user.');
        }
        this.setState({
            uploading: false
        })
    }

    render() {
        const { files, percent, uploading } = this.state;
        return <div style={{ width: '100%', height: '100%' }}>
            <Input id='chooseFile' multiple={true} type='file' accept='image/jpeg, image/png' onChange={this.onFileChnage.bind(this)} style={{ visibility: 'hidden' }} />
            <div style={{ border: 'solid 1px #f0f0f0', paddingLeft: '5px' }}>
                <span>
                    <Button onClick={this.onChooseFile.bind(this)}>选择文件</Button>
                    <Button onClick={this.onDelete.bind(this)}>删除</Button>
                    <Button onClick={this.onCheckAll.bind(this)}>全选</Button>
                    <Button onClick={this.onUnCheckAll.bind(this)}>取消</Button>
                </span>
            </div>
            <div style={{ display: 'flex', flexFlow: 'row wrap' }}>
                {
                    this.makeImages(files)
                }
            </div>
            <div style={{ display: 'flex', margin: '10px 0px 0px 0px', border: 'solid 1px #f0f0f0' }}>
                <Progress percent={percent} strokeWidth={20} style={{ width: '90%' }} />
                {
                    uploading?
                        <Button style={{ marginLeft: '15px', right: '0px' }} onClick={this.cancleUpload.bind(this)}>取消</Button>
                        :
                        <Button style={{ marginLeft: '15px', right: '0px' }} onClick={this.onUpload.bind(this)}>上传</Button>
                }
                
            </div>
        </div>
    }

}