import React from 'react';
import PropTypes from 'prop-types';
import './index.less';

export default class DropoffSitList extends React.Component {

    static propTypes = {
        value: PropTypes.any,
        onChange: PropTypes.func,
        dropoffSits: PropTypes.array,
        multiple: PropTypes.bool
    };

    constructor(props) {
        super(props);
        let dropoffSits = [];
        if (props.dropoffSits && props.dropoffSits.length > 0) {
            dropoffSits = props.dropoffSits;
        }
        this.state = {
            dropoffSits: dropoffSits,
            chooseDropoffSitId: props.value,
        };
    }

    componentWillReceiveProps(nextProps) {
        if (!this.equals(nextProps.dropoffSits, this.state.dropoffSits)) {
            this.setState({
                dropoffSits: nextProps.dropoffSits,
            });
        }
        if (nextProps.value === this.state.chooseDropoffSitId) {
            this.setState({
                chooseDropoffSitId: nextProps.value,
            });
        }
    }

    equals = (newDropoffSits, originalDropoffSits) => {
        console.log(newDropoffSits);
        let newDropoffSiteIds = new Set(newDropoffSits.map(dropoffSit=>dropoffSit.dropoffSiteId));
        let originalDropoffSiteIds = new Set(originalDropoffSits.map(dropoffSit=>dropoffSit.dropoffSiteId));
        let diffs = new Set([...newDropoffSiteIds].filter(dropoffSiteId => !originalDropoffSiteIds.has(dropoffSiteId)), [...originalDropoffSiteIds].filter(dropoffSiteId => !newDropoffSiteIds.has(dropoffSiteId)));
        if (diffs.size>0) {
            return false;
        } 
        return true;
    }

    onChoose = (dropoffSiteId) => {
        this.setState({
            chooseDropoffSitId: dropoffSiteId,
        })
        this.props.onChange(dropoffSiteId);
    }

    render() {
        const { dropoffSits, chooseDropoffSitId } = this.state;
        console.log(dropoffSits)
        return (
            <div className="dropoffSiteDiv">
                {
                    dropoffSits.map(dropoffSit => {
                       return (<div key={dropoffSit.dropoffSiteId}  className={'dropoffSiteTableDiv '+(chooseDropoffSitId===dropoffSit.dropoffSiteId?'chooseDropoffSite':'unChooseDropoffSite')}>
                            <table className="dropoffSiteTable" onClick={()=>this.onChoose(dropoffSit.dropoffSiteId)}>
                                <tbody>
                                    <tr>
                                        <td className='label'>站点名称: </td><td className='content'>{dropoffSit.name}</td>
                                    </tr>
                                    <tr>
                                        <td className='label'>联系人: </td><td className='content'>{dropoffSit.contact}</td>
                                    </tr>
                                    <tr>
                                        <td className='label'>电话: </td><td className='content'>{dropoffSit.mobile}</td>
                                    </tr>
                                    <tr>
                                        <td className='label'>地址: </td><td className='content'>{dropoffSit.countryNameZh + ' ' + dropoffSit.provinceNameZh + ' ' + dropoffSit.cityNameZh + ' ' + dropoffSit.districtNameZh + ' ' + dropoffSit.street1}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                       );
                    })
                }
            </div>
        );
    }


}