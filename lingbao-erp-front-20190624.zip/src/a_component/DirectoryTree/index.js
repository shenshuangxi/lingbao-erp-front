import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Form, Tree, Modal, Input, Button } from 'antd';
import P from 'prop-types';
import tools from '../../a_util/tool'

import { getDirectoryList, addDirectory, actionDirectory, deleteDirectory } from '../../a_redux/actions/directory-action';

const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;

@connect(
    (state) => {
        return {
            directory: state.directory,
            country: state.country,
            platform: state.platform,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ getDirectoryList, addDirectory, actionDirectory, deleteDirectory }, dispatch),
    })
)

@Form.create()
export default class DirectoryTree extends React.Component {

    static propTypes = {
        onSelect: P.func,
        title: P.any,
        onRef: P.func,
    };

    constructor(props) {
        super(props)
        this.state = {
            showRightClickMenu: false,
            rightClickMenuLeft: 0,
            rightClickMenuTop: 0,
            treeSelect: { title: "全部", key: '0' },
        }
    }

    onSelect = (treeSelect) => {
        this.props.onSelect(treeSelect);
    }

    componentDidMount() {
        this.props.onRef(this);
        this.onRefreshDirectory();
    }

    onRefreshDirectory = () => {
        let self = this;
        self.props.actions.getDirectoryList();
    }

    onTreeSelect = (keys, e) => {
        let treeSelect = { title: '全部', key: '0' };
        if (e.selected) {   // 选中
            const p = e.node.props;
            treeSelect = { title: p.title, key: p.eventKey };
        }
        this.setState({
            treeSelect,
        });
        this.onSelect(treeSelect);
    }

    makeTreeDom = (data) => {
        return data.map((item) => {
            if (item.children) {
                return (
                    <TreeNode title={item.name} key={`${item.id}`}>
                        {this.makeTreeDom(item.children)}
                    </TreeNode>
                );
            } else {
                return <TreeNode title={item.name} key={`${item.id}`} />;
            }
        });
    }


    loop = (directoryData, key, callback) => {
        directoryData.forEach((item, index, arr) => {
            if (String(item.id) === key) {
                return callback(item, index, arr);
            }
            if (item.children) {
                return this.loop(item.children, key, callback);
            }
        });
    };

    onDrop = (info) => {

        const dropKey = info.node.props.eventKey;
        const dragKey = info.dragNode.props.eventKey;
        const dropPos = info.node.props.pos.split('-');
        const dropPosition = info.dropPosition - Number(dropPos[dropPos.length - 1]);

        let directoryData = [...this.props.directory.directoryData];
        if (dropKey !== '0' && dropKey !== dragKey) {
            let dragDirectoryData;
            let dropDirectoryData;
            this.loop(directoryData, dragKey, (item, index, array) => {
                dragDirectoryData = item;
            })
            this.loop(directoryData, dropKey, (item, index, array) => {
                dropDirectoryData = item;
            })

            let pid;
            let sort;
            if (dropPosition === -1) {
                pid = dropDirectoryData.pid;
                sort = dropDirectoryData.sort - 1;
            } else if (dropPosition === 0) {
                pid = dropDirectoryData.id;
                sort = dropDirectoryData.children.length;
            } else {
                pid = dropDirectoryData.pid;
                sort = dropDirectoryData.sort + 1;
            }

            let params = {
                id: dragDirectoryData.id,
                pid: pid,
                sort: sort,
                action: 'move',
            }
            let self = this;
            self.props.actions.actionDirectory(tools.clearNull(params)).then(res => {
                if (res.status === 200) {
                    self.onRefreshDirectory()
                }
            })





            // this.loop(directoryData, dragKey, (item, index, array)=>{
            //     dragDirectoryData = item;
            //     array.splice(index, 1)
            // })
            // if (dropPosition === -1) {
            //     this.loop(directoryData, dropKey, (item, index, array)=>{
            //         array.splice(index, 0, dragDirectoryData)
            //     })
            // } else if (dropPosition === 0) {
            //     this.loop(directoryData, dropKey, (item, index, array)=>{
            //         item.children = item.children || [];
            //         item.children.push(dragDirectoryData);
            //     })
            // } else {
            //     this.loop(directoryData, dropKey, (item, index, array)=>{
            //         array.splice(index+1, 0, dragDirectoryData)
            //     })
            // }
            // this.setState({
            //     directoryData: directoryData,
            // });
        }
    }


    // 浏览器的可见高度
    getClientHeight = () => {
        let clientHeight = 0;
        if (document.body.clientHeight && document.documentElement.clientHeight) {
            clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight : document.documentElement.clientHeight;
        } else {
            clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight : document.documentElement.clientHeight;
        }
        return clientHeight;
    }

    // 浏览器的可见宽度
    getClientWidth = () => {
        let clientWidth = 0;
        if (document.body.clientWidth && document.documentElement.clientWidth) {
            clientWidth = (document.body.clientWidth < document.documentElement.clientWidth) ? document.body.clientWidth : document.documentElement.clientWidth;
        } else {
            clientWidth = (document.body.clientWidth > document.documentElement.clientWidth) ? document.body.clientWidth : document.documentElement.clientWidth;
        }
        return clientWidth;
    }

    onRightClick = (info) => {
        // console.log(info)
        let self = this;
        const eventKey = info.node.props.eventKey;
        let clickDirectoryData;
        self.loop(this.props.directory.directoryData, eventKey, (item, index, array) => {
            clickDirectoryData = item;
        })
        if (!clickDirectoryData) {
            clickDirectoryData = {};
            clickDirectoryData.name = self.state.treeSelect.title;
            clickDirectoryData.id = self.state.treeSelect.key;
        }
        // console.log(info.event.target)
        // console.log('clientX: '+info.event.clientX)
        // console.log('clientY: '+info.event.clientY)
        // console.log('pageX: '+info.event.pageX)
        // console.log('pageY: '+info.event.pageY)
        // console.log('movementX: '+info.event.movementX)
        // console.log('movementY: '+info.event.movementY)
        // console.log('screenX: '+info.event.screenX)
        // console.log('screenY: '+info.event.screenY)
        // console.log('clientTop: '+info.event.target.clientTop)
        // console.log('clientLeft: '+info.event.target.clientLeft)
        // console.log('clientWidth: '+info.event.target.clientWidth)
        // console.log('clientHeight: '+info.event.target.clientHeight)
        // console.log('offsetTop: '+info.event.target.offsetTop)
        // console.log('offsetLeft: '+info.event.target.offsetLeft)
        // console.log('offsetWidth: '+info.event.target.offsetWidth)
        // console.log('offsetHeight: '+info.event.target.offsetHeight)
        let x = info.event.clientX; //x坐标
        let y = info.event.clientY; //y坐标
        self.setState({
            rightClickMenuLeft: x,
            rightClickMenuTop: y,
            showRightClickMenu: true,
            clickDirectoryData: clickDirectoryData,
        })
    }

    onHideRightClickMenu = () => {
        this.setState({
            showRightClickMenu: false,
            clickDirectoryData: undefined,
        })
    }

    openDirectoryModal = (operateType) => {
        this.setState({
            showRightClickMenu: false,
            showDirectoryModal: true,
            operateType: operateType
        })
    }

    onCloseDirectoryModal = () => {
        this.setState({
            showRightClickMenu: false,
            clickDirectoryData: undefined,
            showDirectoryModal: false,
            operateType: undefined,
        })
        this.props.form.resetFields();
    }

    onCommitDirectoryModal = () => {
        let self = this;
        self.props.form.validateFields([
            'directory',
        ], (err, values) => {
            if (err) {
                return false;
            }
            let params = {
                name: values.directory,
            }
            if (self.state.operateType === 'add') {
                params = { ...params, 'pid': self.state.clickDirectoryData.id }
                self.props.actions.addDirectory(tools.clearNull(params)).then(() => {
                    self.onCloseDirectoryModal();
                    self.onRefreshDirectory();
                })
            } else {
                params = { ...params, 'id': self.state.clickDirectoryData.id, 'action': 'rename' }
                self.props.actions.actionDirectory(tools.clearNull(params)).then(() => {
                    self.onCloseDirectoryModal();
                    self.onRefreshDirectory();
                });
            }
        });
    }

    onDeleteDirectory = () => {
        let self = this;
        let params = {
            id: self.state.clickDirectoryData.id
        }
        self.props.actions.deleteDirectory(tools.clearNull(params)).then(res => {
            if (res.status === 200) {
                self.onCloseDirectoryModal();
                self.onRefreshDirectory();
            }
        })
    }

    render() {
        const { treeSelect, showRightClickMenu, rightClickMenuLeft, rightClickMenuTop, showDirectoryModal, clickDirectoryData, operateType } = this.state;
        const {loading, directoryData} = this.props.directory;
        const {title} = this.props;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            },
        };
        return <div>
            <div className='title'>{title?title:'目录结构'}<Button loading={loading} onClick={this.onRefreshDirectory.bind(this)} style={{ float: 'right', top: '4px' }}>刷新</Button></div>
            <Tree
                showLine
                draggable
                defaultExpandedKeys={['0']}
                onSelect={this.onTreeSelect.bind(this)}
                selectedKeys={[treeSelect.key]}
                onDrop={this.onDrop.bind(this)}
                onRightClick={this.onRightClick.bind(this)}
            >
                <TreeNode title="全部" key="0">
                    {this.makeTreeDom(directoryData)}
                </TreeNode>
            </Tree>
            <div id='rightclickmenu' style={{ display: showRightClickMenu ? 'block' : 'none', position: 'fixed', left: rightClickMenuLeft, top: rightClickMenuTop, width: '155px' }} className="rightclickmenu">
                <ul>
                    <li onClick={this.openDirectoryModal.bind(this, 'add')}>新建</li>
                    <li onClick={this.openDirectoryModal.bind(this, 'edit')}>修改</li>
                    <li onClick={this.onDeleteDirectory.bind(this)}>删除</li>
                    <li onClick={this.onHideRightClickMenu.bind(this)}>取消</li>
                </ul>
            </div>
            <Modal
                title={operateType === 'add' ? '新增' : '编辑'}
                visible={showDirectoryModal}
                onOk={this.onCommitDirectoryModal.bind(this)}
                onCancel={this.onCloseDirectoryModal.bind(this)}
            >
                <Form>
                    {
                        operateType === 'add' &&
                        <FormItem {...formItemLayout} label="父目录">
                            {getFieldDecorator('parentDirectory', {
                                initialValue: clickDirectoryData ? clickDirectoryData.name : undefined,
                                rules: [{ required: true, message: '请填目录名称' }]
                            })(<Input disabled={true} placeholder="请填目录名称" />)}
                        </FormItem>
                    }
                    <FormItem {...formItemLayout} label="目录">
                        {getFieldDecorator('directory', {
                            initialValue: operateType === 'add' ? undefined : clickDirectoryData ? clickDirectoryData.name : undefined,
                            rules: [{ required: true, message: '请填目录名称' }]
                        })(<Input placeholder="请填目录名称" />)}
                    </FormItem>
                </Form>
            </Modal>
        </div>
    }

}