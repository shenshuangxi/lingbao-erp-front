import React from 'react';
import {Table, Modal, Input, Button} from 'antd';
import P from 'prop-types';

export default class SelectModal extends React.Component {

    static propTypes = {
        columns : P.array,
        dataSource: P.array,
        loading: P.bool,
        formItemLayout: P.any,
        title: P.any,
        visible: P.bool,
        type: P.any,
        pageTotal: P.number,
        pageSize: P.number,
        pageNum: P.number,
        onSelectOk: P.func,
        onSelectCancel: P.func,
        onPageChange: P.func,
        onSearch: P.func,
        searchComponents: P.array,
    }

    constructor(props) {
        super(props);
        this.state = {
            dataSource : props.dataSource,
            loading: props.loading,
            selectedRowKeys: [],
            selectedRows:[],
            searchName: undefined,
        }
    }

    componentWillReceiveProps(props) {
        this.setState({
            dataSource : props.dataSource,
            loading: props.loading
        });
        if (!props.visible) {
            this.setState({
                selectedRowKeys:[],
                selectedRows:[],
            })
        }
    }

    onSelectOk = () => {
        if (this.state.selectedRows.length>0) {
            this.props.onSelectOk(this.state.selectedRows);
        } else {
            this.props.onSelectCancel();
        }
    }

    onSelectCancel = () => {
        this.props.onSelectCancel();
    }

    onChange = (selectedRowKeys, selectedRows) =>{
        let allSelectRowKeys = new Set(selectedRowKeys);
        let currentSelectRowKeys = new Set(selectedRows.map(item=>item.key));
        let nweSelectedRows = this.state.selectedRows.filter(item=>!currentSelectRowKeys.has(item.key));
        nweSelectedRows = [...nweSelectedRows, ...selectedRows];
        nweSelectedRows = nweSelectedRows.filter(item=>allSelectRowKeys.has(item.key));
        this.setState({
            selectedRowKeys,
            selectedRows: nweSelectedRows
        })
    }

    onPageChange = (pageNum, pageSize) => {
        this.props.onPageChange(pageNum, pageSize);
    }

    onSearch = () => {
        this.props.onSearch();
    }

    makeSearchComponents = (searchComponents) => {
        if (searchComponents) {
            return searchComponents.map((component, index)=>{
                return <li key={index}>{component}</li>
            })
        }
    }

    render() {
        const {selectedRowKeys} = this.state;
        const rowSelection = {
            type: this.props.type,
            selectedRowKeys: selectedRowKeys,
            onChange: this.onChange.bind(this),
        };
        return <div>
                
                <Modal
                    width={1040}
                    maskClosable={false}
                    keyboard={false}
                    title={this.props.title}
                    okText="确认"
                    cancelText="取消"
                    visible={this.props.visible}
                    onOk={this.onSelectOk.bind(this)}
                    onCancel={this.onSelectCancel.bind(this)}
                    confirmLoading={this.props.loading}
                >
                    <div className="g-search">
                        <ul className="search-ul">
                            {
                                 this.makeSearchComponents(this.props.searchComponents)
                            }
                            <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                        </ul>
                    </div>
                    <Table
                        bordered
                        rowSelection={rowSelection}
                        columns={this.props.columns}
                        loading={this.props.loading}
                        dataSource={this.props.dataSource}
                        pagination={{
                            total: this.props.pageTotal,
                            current: this.props.pageNum,
                            pageSize: this.props.pageSize,
                            showQuickJumper: true,
                            showSizeChanger: true,
                            showTotal: (total, range) => `共 ${total} 条数据`,
                            onShowSizeChange: (pageNum, pageSize) => this.onPageChange(1, pageSize),
                            onChange: (page, pageSize) => this.onPageChange(page, pageSize)
                        }}
                    />
                </Modal>
            </div>
    }

} 