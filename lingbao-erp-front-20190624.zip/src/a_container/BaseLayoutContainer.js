import React from 'react';

import { Layout, Menu, Icon } from 'antd';

import {Link} from 'react-router-dom';

//import {Link, withRouter} from 'react-router-dom';

import {connect} from 'react-redux';

import {bindActionCreators} from 'redux';

import {getMenuInfo} from '../a_redux/actions/menus-action';

import './BaseLayoutContainer.less';

const { Header, Content, Footer, Sider, } = Layout;
const {SubMenu, Item} = Menu;




@connect(
    (state) => ({
        menus: state.menuInfo.menus,
        loading: state.menuInfo.loading,
    }),
    (dispatch) => ({
        actions: bindActionCreators({getMenuInfo}, dispatch),
    })
)



// const mapStateToProps = (state) => {
//     return {
//         menus: state.menuInfo.menus,
//         loading: state.menuInfo.loading,
//     }
// };

// const mapDispatchToProps = (dispatch) => {
//     return {
//         getMenuInfo: () => {
//             dispatch(getMenuInfo);
//         },
//     }
// };


export default class BaseLayoutContainer extends React.Component {

    componentWillMount(){
        this.props.actions.getMenuInfo();
    }

    render() {
        const {loading, menus} = this.props;
        return (
            <Layout>
                <Sider
                    breakpoint="lg"
                    collapsedWidth="0"
                    onBreakpoint={(broken) => { console.log(broken); }}
                    onCollapse={(collapsed, type) => { console.log(collapsed, type); }}
                >
                    <div className="logo" />
                    <Menu theme="dark" mode="inline">
                    {
                        menus.map((menu) => {
                            if (menu.children && menu.children.length) {
                                return (
                                <SubMenu key={menu.key} title={<span><Icon type={menu.icon} /><span>{menu.name}</span></span>}>
                                    {menu.children.map(childMenu => (
                                        <Item key={menu.key+'/'+childMenu.key}><Link to={`/${childMenu.url}`}>{childMenu.name}</Link></Item>
                                    ))}
                                </SubMenu>
                                )
                            }
                            else if(menu.url){
                                return (
                                        <Item key={menu.key}>
                                            <Link to={`/${menu.url}`}>
                                                <Icon type={menu.icon} /><span className="nav-text">{menu.name}</span>
                                            </Link>
                                        </Item>
                                )
                            } else {
                                return (<span><Icon type={menu.icon} /><span className="nav-text">{menu.name}</span></span>)
                            }
                        })
                    }
                    </Menu>
                </Sider>
                <Layout>
                    <Header style={{ background: '#fff', padding: 0 }} />
                    <Content style={{ margin: '24px 16px 0' }}>
                        <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
                            content
                        </div>
                    </Content>
                    <Footer style={{ textAlign: 'center' }}>
                        Ant Design ©2018 Created by Ant UED
                    </Footer>
                </Layout>
            </Layout>
        );
    }

}

// export default withRouter(connect(mapStateToProps, mapDispatchToProps)(BaseLayoutContainer));