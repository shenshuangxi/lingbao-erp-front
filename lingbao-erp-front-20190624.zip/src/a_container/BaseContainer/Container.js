
import React from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getMenuInfo } from '../../a_redux/actions/menus-action';
import { listLogisticWarehouse } from '../../a_redux/actions/logisticWarehouse-action';
import { listLogisticChannel } from '../../a_redux/actions/logisticChannel-action';
import {enumsCountry, enumsPlatform, enumsLogistic, enumsDispatchType} from '../../a_redux/actions/enums-action';
import {getRetailPlatformAccountList} from '../../a_redux/actions/retailPlatformAccount-action';
const { Sider } = Layout;
const { SubMenu, Item } = Menu;

import Top from './Top';
import Context from './Context';
import Bottom from './Bottom';

import './Container.less';


@connect(
	(state) => ({
		enums: state.enums,
		logisticWarehouse: state.logisticWarehouse,
		logisticChannel: state.logisticChannel,
		retailPlatformAccount: state.retailPlatformAccount,
		menus: state.menuInfo.menus,
		loading: state.menuInfo.loading,
	}),
	(dispatch) => ({
		actions: bindActionCreators({ 
			getMenuInfo,
			listLogisticWarehouse,
			listLogisticChannel,
			enumsCountry, 
			enumsPlatform, 
			enumsLogistic,
			enumsDispatchType,
			getRetailPlatformAccountList,
		}, dispatch),
	})
)
export default class Container extends React.Component {

	state = {
		theme: 'dark',
		current: '/index',
		collapsed: false,
		mode: 'inline',  // 水平垂直展现
		selectedKeys:[],
		openKeys:[],
	}

	componentWillMount() {
		this.openPathMenu(this.props.location);
		this.props.actions.getMenuInfo();
		this.onRefreshBasicData();
	}

	onRefreshBasicData = () => {
        if (this.props.retailPlatformAccount.pageData.length<1) {
            this.props.actions.getRetailPlatformAccountList();
        }
        if (!this.props.enums.enums.logistic) {
            this.props.actions.enumsLogistic();
        }
        if (!this.props.enums.enums.platfrom) {
            this.props.actions.enumsPlatform();
        }
        if (!this.props.enums.enums.country) {
            this.props.actions.enumsCountry();
		}
		if (!this.props.enums.enums.dispatchtype) {
            this.props.actions.enumsDispatchType();
        }
        if (this.props.enums.enums.logistic) {
            this.props.enums.enums.logistic.forEach(logisticPlatform => {
                if (!this.props.logisticWarehouse.logisticWarehouse[logisticPlatform.name]) {
                    this.props.actions.listLogisticWarehouse(tool.clearNull({logistic:logisticPlatform.name}));
                }
                if (!this.props.logisticChannel.logisticChannel[logisticPlatform.name]) {
                    this.props.actions.listLogisticChannel(tool.clearNull({logistic:logisticPlatform.name}));
                }
            });
        }
    }

	componentWillReceiveProps(nextP) {
		if (this.props.location !== nextP.location) {
			this.openPathMenu(nextP.location);
		}
	}

	openPathMenu = (location) => {
		let path = location.pathname;
		if (path === '' || path === '/') {
			path = '/index';
		}

		let openKeys = path.split("/").reduce((sum, current)=>{
			if (current === '') {
				return [];
			} else if (sum.length === 0) {
				return ['/'+current];
			} else {
				return [...sum, sum[sum.length-1] + '/'+current]
			}
		}, []);
		this.setState({
			selectedKeys: [path],
			openKeys: openKeys,
		});
	}

	changeTheme = (value) => {
		this.setState({
			theme: value ? 'dark' : 'light',
		});
	}

	toggle = () => {
		this.setState({
			collapsed: !this.state.collapsed,
			mode: this.state.collapsed ? 'inline' : 'vertical',
		});
	}

	makeMenus = (menus, pKey) => {
		return menus.map(item => {
			const newKey = `${pKey}/${item.key}`;
			if (item.children && Array.isArray(item.children) && item.children.length > 0) {
				return <SubMenu key={newKey} title={<span>{item.icon?<Icon type={item.icon} />:''}<span>{item.name}</span></span>}>
					{
						this.makeMenus(item.children, newKey)
					}
				</SubMenu>
			} else {
				return <Item key={newKey}>
					<Link to={newKey}>
						{
							item.icon&&<Icon type={item.icon} />
						}
						<span className="nav-text">{item.name}</span>
					</Link>
				</Item>
			}
		})
	}

	onOpenChange = (openKeys) => {
		this.setState({
			openKeys
		})
	}

	onSelect = (menu) => {
		this.setState({
			selectedKeys: [menu.key]
		});
	}

	render() {
		const { loading, menus } = this.props;
		const {mode, openKeys, selectedKeys} = this.state;
		return (
			<Layout className="containAll">
				<Sider width={220} className="leftMenu" collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}  >
					<div className="logo"><img src='/images/logo_n.png' /></div>
					<Menu 
						className="menu" 
						theme='light' 
						onClick={this.onSelect.bind(this)} 
						onOpenChange={this.onOpenChange.bind(this)}
						openKeys={openKeys}
						selectedKeys={selectedKeys} 
						mode={mode}
					>
						{
							this.makeMenus(menus, '')
						}
					</Menu>
				</Sider>
				<Layout>
					<Top toggle={this.toggle} collapsed={this.state.collapsed} username={this.props.username} />
					<Context path={this.props.history.location.pathname} />
					<Bottom />
				</Layout>
			</Layout>
		);
	}
}