import React from 'react';
import { withRouter, Redirect } from 'react-router';
import { connect } from "react-redux";
import { Link } from 'react-router-dom';
import { Menu, Icon, Layout } from 'antd';
// import {modifyAdminPassword, resetUsercenter} from '../redux/actions/usercenter';
// import ModifyUserPasswordModal from '../components/ModifyUserPasswordModal'

import './Top.less';

const SubMenu = Menu.SubMenu;
const { Header } = Layout;

export default  class Top extends React.Component {

	state ={
		loading : false,
		visible : false,
		modifyPassword : false
	}

	handleSubmit = (values) => {
	//    this.setState({
	//    		loading : true
	//    });
	//    this.props.modifyAdminPassword(values);
  	}

  	handleCancel = () => {
    	this.setState({
  			visible : false
  		});
  	}

  	openModifyPasswordModal = ()=>{
  		this.setState({
  			visible : true
  		});
  	}

  	componentWillReceiveProps(nextProps){
	  	this.setState({
	  		loading: nextProps.isLoading,
	  		visible : nextProps.isLoading
	  	});
	}

	componentWillMount() {
		// this.props.resetUsercenter();
	}

	componentDidUpdate() {
		// if(this.props.modifyPasswordOk){
    	// 	this.props.history.replace('/login');
		// }
	}

	render(){
		return (
			<div>
				{/* <ModifyUserPasswordModal visible={this.state.visible} handleSubmit={this.handleSubmit} handleCancel={this.handleCancel} loading={this.state.loading} /> */}
				<Header style={{ background: '#fff'}}>
					<Icon  className="trigger" type={this.props.collapsed ? 'menu-unfold' : 'menu-fold'} onClick={this.props.toggle} />
	                {/* <Menu mode="horizontal" className="logOut" >
	                    <SubMenu title={<span><Icon type="user" />{ this.props.username }</span>} >
	                        <Menu.Item key="logOut"><Link to="/login" >退出</Link></Menu.Item>
	                        <Menu.Item key="modifyPassword"><a onClick={this.openModifyPasswordModal}>修改密码</a></Menu.Item>
	                    </SubMenu>
	                </Menu> */}
				</Header>
			</div>
		);
	}
}