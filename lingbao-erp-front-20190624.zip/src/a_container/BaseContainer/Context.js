import React from 'react';
import {Route,Switch} from 'react-router-dom';
import { Layout } from 'antd';

import './Context.less';

// import Index from '../pages/index/Index';
// import UserAudit from '../pages/useraudit/UserAudit';
// import BasicUsers from '../pages/basic/BasicUsers';
// import RoleMenu from '../pages/basic/RoleMenu';
// import AppRoleMenu from '../pages/basic/AppRoleMenu';

import retailPlatformAccount from 'bundle-loader?lazy&name=retailPlatformAccount!../../a_page/RetailPlatformAccount';
import customerInfo from 'bundle-loader?lazy&name=customerInfo!../../a_page/CustomerInfo';
import saleOrder from 'bundle-loader?lazy&name=saleOrder!../../a_page/SaleOrder';
import imageUpload from 'bundle-loader?lazy&name=imageUpload!../../a_page/ImageUpload';
import image from 'bundle-loader?lazy&name=image!../../a_page/Image';

import logisticOrder from 'bundle-loader?lazy&name=logisticOrder!../../a_page/Logistic/Order';
import logisticOrderHistory from 'bundle-loader?lazy&name=logisticOrder!../../a_page/Logistic/History';
import logisticRule from 'bundle-loader?lazy&name=logisticRule!../../a_page/logistic/Rule';
import logisticWinitWarehouse from 'bundle-loader?lazy&name=logisticWinitWarehouse!../../a_page/Logistic/Winit/Warehouse';
import logisticWinitSmallPackagePost from 'bundle-loader?lazy&name=logisticWinitSmallPackagePost!../../a_page/logistic/Winit/Channel';
import logisticSpeedPakSendAddress from 'bundle-loader?lazy&name=logisticSpeedPakSendAddress!../../a_page/logistic/SpeedPak/SendAddress';
import logisticSpeedPakSenderAddress from 'bundle-loader?lazy&name=logisticSpeedPakSenderAddress!../../a_page/logistic/SpeedPak/SenderAddress';
import logisticSpeedPakService from 'bundle-loader?lazy&name=logisticSpeedPakService!../../a_page/logistic/SpeedPak/Service';
import logisticSpeedPakDropoffSite from 'bundle-loader?lazy&name=logisticSpeedPakDropoffSite!../../a_page/logistic/SpeedPak/DropoffSite';

import logisticYanwenChannel from  'bundle-loader?lazy&name=logisticYanwenChannel!../../a_page/logistic/Yanwen/Channel';

import product from 'bundle-loader?lazy&name=product!../../a_page/Product';
import supplier from 'bundle-loader?lazy&name=supplier!../../a_page/Supplier';
import stock from 'bundle-loader?lazy&name=stock!../../a_page/Stock/Stock';
import stockStatistics from 'bundle-loader?lazy&name=stock!../../a_page/Stock/StockStatistics';
import stockInOrder from 'bundle-loader?lazy&name=stockInOrder!../../a_page/Stock/StockInOrder';
import stockAction from 'bundle-loader?lazy&name=stockAction!../../a_page/Stock/StockAction';

import Bundle from '../../a_router/Bundle';


const { Content } = Layout


const createComponent = (component, props) => {
    return <Bundle load={component}>
        {
            (Component) => Component ? <Component {...props} />: <Loading/>
        }
    </Bundle>
}


const Loading = function() {
    return <div>Loading...</div>
}


export default class Context extends React.Component {

	shouldComponentUpdate(nextProps) {
        return nextProps.path !== this.props.path;
    }

	render(){
		return (
			<Content className="content">
				<Switch>
					<Route  path="/retail-platform-manager/account" render={(props)=>createComponent(retailPlatformAccount, props)} />
					<Route  path="/retail-platform-manager/customer" render={(props)=>createComponent(customerInfo, props)} />
					<Route  path="/retail-platform-manager/order" render={(props)=>createComponent(saleOrder, props)} />
					<Route  path="/image-manager/upload" render={(props)=>createComponent(imageUpload, props)} />
					<Route  path="/image-manager/image" render={(props)=>createComponent(image, props)} />
					<Route  path="/logistic-platform-manager/order" render={(props)=>createComponent(logisticOrder, props)} />
					<Route  path="/logistic-platform-manager/history" render={(props)=>createComponent(logisticOrderHistory, props)} />
					<Route  path="/logistic-platform-manager/rule" render={(props)=>createComponent(logisticRule, props)} />
					<Route  path="/logistic-platform-manager/winit/warehouses" render={(props)=>createComponent(logisticWinitWarehouse, props)} />
					<Route  path="/logistic-platform-manager/winit/channels" render={(props)=>createComponent(logisticWinitSmallPackagePost, props)} />
					<Route  path="/logistic-platform-manager/speedPak/sendAddress" render={(props)=>createComponent(logisticSpeedPakSendAddress, props)} />
					<Route  path="/logistic-platform-manager/speedPak/senderAddress" render={(props)=>createComponent(logisticSpeedPakSenderAddress, props)} />
					<Route  path="/logistic-platform-manager/speedPak/services" render={(props)=>createComponent(logisticSpeedPakService, props)} />
					<Route  path="/logistic-platform-manager/speedPak/dropoffSites" render={(props)=>createComponent(logisticSpeedPakDropoffSite, props)} />
					
					<Route  path="/logistic-platform-manager/yanwen/channels" render={(props)=>createComponent(logisticYanwenChannel, props)} />
					
					
					<Route  path="/product-manager/product" render={(props)=>createComponent(product, props)} />
					<Route  path="/supplier-manager/supplier" render={(props)=>createComponent(supplier, props)} />
					<Route  path="/stock-manager/stock" render={(props)=>createComponent(stock, props)} />
					<Route  path="/stock-manager/stockstatistics" render={(props)=>createComponent(stockStatistics, props)} />
					<Route  path="/stock-manager/stockinorder" render={(props)=>createComponent(stockInOrder, props)} />
					<Route  path="/stock-manager/stockaction" render={(props)=>createComponent(stockAction, props)} />
					{/* <Route exact path="/index" component={Index}/>
					<Route exact path="/audituser" component={UserAudit} />
					<Route exact path="/basicusers" component={BasicUsers} />
					<Route exact path="/basicrole" component={RoleMenu} />
					<Route exact path="/modifyPassword" component={RoleMenu} />
					<Route exact path="/basicapprole" component={AppRoleMenu} /> */}
				</Switch>
			</Content>
		);
	}
}