
import React from 'react';
import {Router, Route, Switch} from 'react-router-dom';
import {createBrowserHistory as createHistory}  from 'history';

import Bundle from './Bundle';
import BaseLayoutContainer from 'bundle-loader?lazy&name=baselayout!../a_container/BaseContainer/Container';



const createComponent = (component, props) => {
    return <Bundle load={component}>
        {
            (Component) => Component ? <Component {...props} />: <Loading/>
        }
    </Bundle>
}


const Loading = function() {
    return <div>Loading...</div>
}

const getRouter = () => (
    <Router history={createHistory()}>
        <Route render={(props)=>(
            <Switch>
                <Route path="/" render={(props)=>createComponent(BaseLayoutContainer, props)}/>
            </Switch>
        )}/>
    </Router>
);


export default getRouter;