import React from 'react';
import ErpImages from '../../a_component/ErpImages';

import './index.less';
import DirectoryTree from '../../a_component/DirectoryTree';


export default class ImagePage extends React.Component {

    state = {
        directoryTree: undefined,
        treeSelect: { title: "全部", key: '0' },
    }

    onDirectoryTreeRef = (ref) => {
        this.setState({
            directoryTree: ref
        })
    }

    getDirectory = () => {
        const {directoryTree} = this.state;
        const treeSelect = directoryTree?directoryTree.state.treeSelect:{ title: "全部", key: '0' };
        return treeSelect.key;
    }

    onTreeSelect = (treeSelect) => {
        this.setState({
            treeSelect
        })
    }

    render() {
        const {treeSelect} = this.state;
        return (
            <div>
                <div className='page'>
                    <div className='l'>
                        <DirectoryTree onRef={this.onDirectoryTreeRef.bind(this)} onSelect={this.onTreeSelect.bind(this)} />
                    </div>
                    <div className='r'>
                        <ErpImages directory={treeSelect.key} />
                    </div>
                </div>
            </div>

        )
    }

} 