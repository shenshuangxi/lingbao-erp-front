import React, {Component} from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../../a_util/tool';
import {Input, Button, Table, Modal, Tag, Select } from 'antd';
import {getChannelList, syncChannel} from '../../../../a_redux/actions/yanwen-service-action';

const { CheckableTag } = Tag;

const Option = Select.Option;

@connect(
    (state) => {
        return {
            yanwenchannel: state.yanwenchannel,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getChannelList,
            syncChannel,
        }, dispatch),
    })
)
export default class YanwenChannel extends Component {

    state = {
        searchName: undefined,
        searchCountryToName: undefined,
        showCountryModal: false,
        selectRecord: undefined,
        channelType: undefined,
    }

    componentDidMount() {
        this.onRefreshChannel();
    }

    onRefreshChannel = (searchName=this.state.searchName, pageNum=this.props.yanwenchannel.pageNum, pageSize=this.props.yanwenchannel.pageSize) => {
        let self = this;
        this.props.actions.getChannelList(tool.clearNull({
            name:searchName,
            pageNum:pageNum,
            pageSize:pageSize,
            channelType: self.state.channelType,
        }));
    }

    onSyncChannel = () => {
        let self = this;
        self.props.actions.syncChannel().then(()=>{
            self.onRefreshChannel();
        });
    }

    makeColumnsData = (data) => {
        let newData = [...data];
        return newData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.id,
                id: item.id,
                channelId: item.channelId,
                name: item.name,
                channelType: item.channelType,
                countries: item.countries,
            }
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '名称',
            dataIndex: 'name',
            key: 'name',      
		},
		{
            title: '编码',
            dataIndex: 'channelId',
            key: 'channelId',      
        },
        {
            title: '类型',
            dataIndex: 'channelType',
            key: 'channelType',    
            render:(text, record) =>{
                return record.channelType && record.channelType.name
            }  
        },
        {
            title: '到达国家',
            dataIndex:'countries',
            key:'countries',
            render: (text, record) => {
                return <span style={{cursor:'pointer', color:'blue'}} onClick={()=>this.openCountryModal(record)}>点击查看路线</span> ;
            } 
        },
    ];

    openCountryModal = (record) => {
        this.setState({
            showCountryModal: true,
            selectRecord: record,
        })
    }

    closeCountryModal = () => {
        this.setState({
            showCountryModal: false,
            selectRecord: undefined,
        })
    }

    makeCountryColumns = (directionData) => {
        let newdirectionData = JSON.parse(JSON.stringify(directionData));
        let search = this.state.searchCountryToName
        if (search !== undefined) {
            newdirectionData = newdirectionData.filter(item=>item.regionCh.indexOf(search)>0 || item.regionEn.indexOf(search)>0 ||item.regionCode.indexOf(search)>0)
        }
        return newdirectionData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.countryId,
                countryId : item.countryId,
                regionCh : item.regionCh,
                regionEn : item.regionEn,
                regionCode : item.regionCode,
            }
        })
    }

    countryColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '国家(中文)',
            dataIndex: 'regionCh',
            key: 'regionCh',
		},
		{
            title: '国家(英文)',
            dataIndex: 'regionEn',
            key: 'regionEn',     
        },
        {
            title: '编码',
            dataIndex: 'regionCode',
            key: 'regionCode',     
        },
    ];

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshChannel(this.state.searchName, pageNum, pageSize);
    }

    onSearchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        })
    }

    onSearchCountryToNameChange = (e) => {
        this.setState({
            searchCountryToName: e.target.value,
        })
    }

    onTypeChange = (value) => {
        this.setState({
            channelType: value,
        });
    }

    render() {
        const {loading, yanwenChannels, pageSize, pageNum, pageTotal} = this.props.yanwenchannel;
        const {showCountryModal, searchCountryToName, selectRecord, searchName, channelType} = this.state;
        let channelCountries = selectRecord?selectRecord.countries:[];
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="名称" defaultValue={searchName} onChange={this.onSearchNameChange.bind(this)}/></li>
                        <li>
                            <Select style={{width:120}} placeholder="渠道类型" value={channelType} onChange={this.onTypeChange.bind(this)}>
                                <Option value={2}>线下渠道</Option>
                                <Option value={1}>线上渠道</Option>
                            </Select>
                        </li>
                        <li><Button icon="search" onClick={()=>this.onRefreshChannel()}>查询</Button></li>
                        <li><Button icon="reload" onClick={this.onSyncChannel.bind(this)}>同步</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(yanwenChannels)} 
                    columns={this.columns} 
                    size="small"
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal 
                    visible={showCountryModal}
                    onOk={this.closeCountryModal.bind(this)}
                    onCancel={this.closeCountryModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    width={800}
                    height={600}
                >
                     <div className="g-search">
                        <ul className="search-ul">
                            <li><Input placeholder="名称" defaultValue={searchCountryToName} onChange={this.onSearchCountryToNameChange.bind(this)}/></li>

                        </ul>
                    </div>
                    <Table 
                        bordered
                        loading={loading}
                        dataSource={this.makeCountryColumns(channelCountries)} 
                        columns={this.countryColumns} 
                        size="small"
                        pagination={{
                            showQuickJumper: true,
                            showSizeChanger: true,
                            showTotal: (total, range) => `共 ${total} 条数据`,
                        }}
                    />
                </Modal>
            </div>
        )
    }

}