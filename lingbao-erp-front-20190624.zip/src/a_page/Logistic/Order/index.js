import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Table, Form, Modal, Input, Select, Radio, Button, Divider, message } from 'antd';
import './index.less';
import { listLogisticWarehouse } from '../../../a_redux/actions/logisticWarehouse-action';
import { listLogisticChannel } from '../../../a_redux/actions/logisticChannel-action';
import { listLogisticDispatch } from '../../../a_redux/actions/logistic-dispatch-action';
import { enumsCountry, enumsPlatform, enumsLogistic, enumsDispatchType } from '../../../a_redux/actions/enums-action';
import { getRetailPlatformAccountList } from '../../../a_redux/actions/retailPlatformAccount-action';
import { listStocks, addStock } from '../../../a_redux/actions/stock-action';
import { listLogistcOrder, addLogistcOrder, syncLogistcOrder, deleteLogisticOrder, actionLogistcOrder, printLogisticPackageLable, getLogistcOrderDetail } from '../../../a_redux/actions/logistic-order-action';
import { getConsumerInfoList, actionCustomerInfo, actionConsumerContactInfo } from '../../../a_redux/actions/consumerInfo-action';
import tool from '../../../a_util/tool';
import { fetchGetBlob } from '../../../a_util/fetch';
import SelectModal from '../../../a_component/SelectModal';

const Option = Select.Option;
const TextArea = Input.TextArea;
const RadioGroup = Radio.Group;

@connect(
    (state) => {
        return {
            enums: state.enums,
            logisticWarehouse: state.logisticWarehouse,
            logisticChannel: state.logisticChannel,
            retailPlatformAccount: state.retailPlatformAccount,
            logisticOrder: state.logisticOrder,
            logisticDispatch: state.logisticDispatch,
            stock: state.stock,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            listLogistcOrder,
            addLogistcOrder,
            syncLogistcOrder,
            deleteLogisticOrder,
            actionLogistcOrder,
            getLogistcOrderDetail,
            getConsumerInfoList,
            actionCustomerInfo,
            actionConsumerContactInfo,
            getRetailPlatformAccountList,
            listLogisticWarehouse,
            listLogisticChannel,
            listLogisticDispatch,
            printLogisticPackageLable,
            enumsCountry,
            enumsPlatform,
            enumsLogistic,
            enumsDispatchType,
            listStocks,
            addStock,
        }, dispatch),
    })
)


@Form.create()
export default class LogisticOrder extends React.Component {


    state = {
        selectedRowKeys: [],
        selectedRows: [],

        logisticOrderDetailModalShow: false,
        selectRecord: undefined,
        selectRecordDetail: [],
        buyerInfo: undefined,
        editBuyerInfo: false,
        addressInfo: undefined,
        editAddressInfo: false,
        logisticInfo: undefined,
        editLogisticInfo: false,

        searchStatus: undefined,
        searchLogistic: undefined,
        searchChannel: undefined,
        searchPlatform: undefined,
        searchSeller: undefined,
        searchBuyer: undefined,
        searchCounrty: undefined,

        orderLineItems: undefined,

        selectStockStatus: 0,
    }

    componentDidMount() {
        this.onRefreshLogisticOrder();
    }

    onRefreshBasicData = () => {
        if (this.props.retailPlatformAccount.pageData.length < 1) {
            this.props.actions.getRetailPlatformAccountList();
        }
        if (!this.props.enums.enums.logistic) {
            this.props.actions.enumsLogistic();
        }
        if (!this.props.enums.enums.platfrom) {
            this.props.actions.enumsPlatform();
        }
        if (!this.props.enums.enums.country) {
            this.props.actions.enumsCountry();
        }
        if (!this.props.enums.enums.dispatchtype) {
            this.props.actions.enumsDispatchType();
        }
    }

    onRefreshLogisticOrder = (pageNum = this.props.logisticOrder.pageNum, pageSize = this.props.logisticOrder.pageSize) => {
        this.onRefreshBasicData();
        this.props.actions.listLogistcOrder(tool.clearNull({
            pageNum: pageNum,
            pageSize: pageSize,
            statuses: this.state.searchStatus !== undefined ? [this.state.searchStatus] : [-1, 0, 1],
            logistic: this.state.searchLogistic,
            channelCode: this.state.searchChannel,
            platform: this.state.searchPlatform,
            seller: this.state.searchSeller,
            buyer: this.state.searchBuyer,
            country: this.state.searchCounrty,
        }));
    }

    onSyncLogisticOrder = () => {
        let self = this;
        self.props.actions.syncLogistcOrder().then(() => {
            self.onRefreshLogisticOrder();
        });
    }

    onMergeLogisticOrder = () => {
        let self = this;
        if (self.state.selectedRowKeys.length < 2) {
            message.error('请选择两个以上');
            return;
        }
        let ids = [...self.state.selectedRowKeys];
        let params = {
            action: 'merge',
            id: ids.shift(),
            ids: ids,
        }
        self.props.actions.actionLogistcOrder(tool.clearNull(params)).then(() => {
            self.setState({
                selectedRowKeys: [params.id],
            })
            self.onRefreshLogisticOrder();
        });
    }

    onPrintAllLogisticOrder = () => {
        let selectedRows = this.state.selectedRows;
        for (let i = 0; i < selectedRows.length; i++) {
            let orderLablePath = selectedRows[i].orderLablePath;
            if (orderLablePath) {
                fetchGetBlob(orderLablePath).then((res) => { // 处理返回的文件流
                    const content = res.data;
                    const blob = new Blob([content]);
                    const fileName = orderLablePath.substring(orderLablePath.lastIndexOf("\/") + 1, orderLablePath.length);
                    if ('download' in document.createElement('a')) { // 非IE下载
                        const elink = document.createElement('a')
                        elink.download = fileName
                        elink.style.display = 'none'
                        elink.href = URL.createObjectURL(blob)
                        document.body.appendChild(elink)
                        elink.click()
                        URL.revokeObjectURL(elink.href) // 释放URL 对象
                        document.body.removeChild(elink)
                    } else { // IE10+下载
                        navigator.msSaveBlob(blob, fileName)
                    }
                })
            } else {
                this.props.actions.actionLogistcOrder(tool.clearNull({
                    action: 'print-logistic-order-lable',
                    id: selectedRows[i].id,
                })).then((res) => {
                    let orderLablePath = res.data.body;
                    fetchGetBlob(orderLablePath).then((res) => { // 处理返回的文件流
                        const content = res.data;
                        const blob = new Blob([content]);
                        const fileName = orderLablePath.substring(orderLablePath.lastIndexOf("\/") + 1, orderLablePath.length);
                        if ('download' in document.createElement('a')) { // 非IE下载
                            const elink = document.createElement('a')
                            elink.download = fileName
                            elink.style.display = 'none'
                            elink.href = URL.createObjectURL(blob)
                            document.body.appendChild(elink)
                            elink.click()
                            URL.revokeObjectURL(elink.href) // 释放URL 对象
                            document.body.removeChild(elink)
                        } else { // IE10+下载
                            navigator.msSaveBlob(blob, fileName)
                        }
                    })
                    // const fileName = res.data.body.fileName;
                    // const content = res.data.body.fileData;
                    // const blob = new Blob([tool.base64Decode(content)]);
                    // if ('download' in document.createElement('a')) { // 非IE下载
                    //     const elink = document.createElement('a')
                    //     elink.download = fileName
                    //     elink.style.display = 'none'
                    //     elink.href = URL.createObjectURL(blob)
                    //     document.body.appendChild(elink)
                    //     elink.click()
                    //     URL.revokeObjectURL(elink.href) // 释放URL 对象
                    //     document.body.removeChild(elink)
                    // } else { // IE10+下载
                    //     navigator.msSaveBlob(blob, fileName)
                    // }
                })
            }
        }
    }



    onSearch = () => {
        this.onRefreshLogisticOrder(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshLogisticOrder(pageNum, pageSize);
    }

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.logisticOrder.pageNum - 1) * this.props.logisticOrder.pageSize,
                key: item.id,

                id: item.id,
                logistic: item.logistic,
                channelCode: item.channelCode,
                channelName: item.channelName,
                warehouseCode: item.warehouseCode,
                warehouseName: item.warehouseName,
                dispatchtypeCode: item.dispatchtypeCode,
                dispatchtypeName: item.dispatchtypeName,
                length: item.length,
                width: item.width,
                height: item.height,
                weight: item.weight,
                amount: item.amount,
                currency: item.currency,

                logisticOrderNo: item.logisticOrderNo,
                orderLablePath: item.orderLablePath,
                logisticTrackingNo: item.logisticTrackingNo,
                printCount: item.printCount,

                platform: item.platform,
                seller: item.seller,

                buyerId: item.buyerId,
                buyer: item.buyer,
                buyerName: item.buyerName,
                buyerPhone: item.buyerPhone,
                buyerEmail: item.buyerEmail,

                customerContactInfoId: item.customerContactInfoId,
                country: item.country,
                stateOrProvince: item.stateOrProvince,
                city: item.city,
                street1: item.street1,
                street2: item.street2,
                houseNumber: item.houseNumber,
                post: item.post,

                orderLineItems: item.orderLineItems,

                status: item.status,
                createTime: item.createTime,
            };
        })
    }

    nestColumns = [
        {
            title: '物流',
            dataIndex: 'logistic',
            key: 'logistic',
            className: 'table',
        },
        {
            title: '渠道',
            dataIndex: 'channelName',
            key: 'channelName',
            className: 'table',
        },
        {
            title: '仓库',
            dataIndex: 'warehouseName',
            key: 'warehouseName',
            className: 'table',
        },
        {
            title: '送货方式',
            dataIndex: 'dispatchtypeName',
            key: 'dispatchtypeName',
            className: 'table',
        },
        {
            title: '订单号',
            dataIndex: 'logisticOrderNo',
            key: 'logisticOrderNo',
            className: 'table',
        },
        {
            title: '跟踪单号',
            dataIndex: 'logisticTrackingNo',
            key: 'logisticTrackingNo',
            className: 'table',
        },
    ];
    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className: 'table',
        },
        {
            title: '平台',
            dataIndex: 'platform',
            key: 'platform',
            className: 'table',
        },
        {
            title: '卖家',
            dataIndex: 'seller',
            key: 'seller',
            className: 'table',
        },
        {
            title: '国家',
            dataIndex: 'country',
            key: 'country',
            className: 'table',
            render: (text, record) => {
                return record.country ? (record.country.value + " [" + record.country.name + "]") : undefined;
            }
        },
        {
            title: '买家',
            dataIndex: 'buyer',
            key: 'buyer',
            className: 'table',
        },
        {
            title: '总金额',
            dataIndex: 'amount',
            key: 'amount',
            className: 'table',
            render: (text, record) => {
                return record.amount + " " + record.currency
            }
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
            render: (text, record) => {
                let skus = [];
                if (record && record.orderLineItems) {
                    for (let orderNo in record.orderLineItems) {
                        skus.push(record.orderLineItems[orderNo].map((item, index) => <span style={{ display: 'inlineBlock' }} key={index}>{item.sku + " "}</span>));
                    }
                }
                return skus;
            }
        },
        {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            className: 'table',
            render: (text, record) => {
                return record.status ? record.status.name : undefined;
            }
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className: 'table',
        },
        {
            title: '操作',
            key: 'operation',
            className: 'table',
            render: (text, record) => {
                return <div>
                    <span className="control-btn red" onClick={() => this.openLogisticOrderModal(record)}>
                        <a>编辑</a>
                    </span>
                    <Divider type="vertical" />
                    {
                        record.status && record.status.value === 0 &&
                        <span className="control-btn red" onClick={this.onPlaceOrder.bind(this, record)}>
                            <a>下单</a>
                        </span>
                    }
                    {
                        record.status && record.status.value === 0 && <Divider type='vertical' />
                    }
                    {
                        record.status && record.status.value > 0 && ((record.orderLablePath != undefined) ?
                            <span className="control-btn red">
                                <a href={record.orderLablePath} onClick={this.onPrintOrderLabelAgain.bind(this, record)}>再次打印物流单</a>
                            </span>
                            :
                            <span className="control-btn red">
                                <a href="javascript:void(0)" onClick={this.onPrintOrderLabel.bind(this, record)}>打印物流单</a>
                            </span>
                        )
                    }
                    {
                        record.status && record.status.value > 0 && <Divider type='vertical' />
                    }
                    {
                        record.status && record.status.value === 1 &&
                        <span className="control-btn red" onClick={this.finishLogisticOrder.bind(this, record)}>
                            <a>确认发货</a>
                        </span>
                    }
                    {
                        record.status && (record.status.value === 1) && <Divider type='vertical' />
                    }
                    {
                        record.status && record.status.value >= 1 &&
                        <span className="control-btn red" onClick={this.invalideLogisticOrder.bind(this, record)}>
                            <a>作废</a>
                        </span>
                    }
                    {
                        record.status && (record.status.value >= 1) && <Divider type='vertical' />
                    }
                    <span className="control-btn red" onClick={this.deleteLogisticOrder.bind(this, record)}>
                        <a>删除</a>
                    </span>
                </div>
            }
        }
    ];


    onPlaceOrder = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        if (record.logistic === undefined) {
            message.error("请选择物流方式");
            return;
        }
        if (record.channelCode === undefined) {
            message.error("请选择物流渠道");
            return;
        }
        this.props.actions.actionLogistcOrder(tool.clearNull({
            action: 'place-order',
            id: record.id,
        })).then((res) => {
            this.onRefreshLogisticOrder();
        })
    }

    onPrintOrderLabel = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!record.status || !record.status.value || (record.status.value < 1)) {
            message.error("请先下单");
            return;
        }
        this.props.actions.actionLogistcOrder(tool.clearNull({
            action: 'print-logistic-order-lable',
            id: record.id,
        })).then((res) => {
            let orderLablePath = res.data.body;
            fetchGetBlob(orderLablePath).then((res) => { // 处理返回的文件流
                const content = res.data;
                const blob = new Blob([content]);
                const fileName = orderLablePath.substring(orderLablePath.lastIndexOf("\/") + 1, orderLablePath.length);
                if ('download' in document.createElement('a')) { // 非IE下载
                    const elink = document.createElement('a')
                    elink.download = fileName
                    elink.style.display = 'none'
                    elink.href = URL.createObjectURL(blob)
                    document.body.appendChild(elink)
                    elink.click()
                    URL.revokeObjectURL(elink.href) // 释放URL 对象
                    document.body.removeChild(elink)
                } else { // IE10+下载
                    navigator.msSaveBlob(blob, fileName)
                }
            })
            this.onRefreshLogisticOrder();
        })
    }

    onPrintOrderLabelAgain = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        fetchGetBlob(record.orderLablePath).then((res) => { // 处理返回的文件流
            const content = res.data;
            const blob = new Blob([content]);
            const fileName = record.orderLablePath.substring(record.orderLablePath.lastIndexOf("\/") + 1, record.orderLablePath.length);
            if ('download' in document.createElement('a')) { // 非IE下载
                const elink = document.createElement('a')
                elink.download = fileName
                elink.style.display = 'none'
                elink.href = URL.createObjectURL(blob)
                document.body.appendChild(elink)
                elink.click()
                URL.revokeObjectURL(elink.href) // 释放URL 对象
                document.body.removeChild(elink)
            } else { // IE10+下载
                navigator.msSaveBlob(blob, fileName)
            }
        })
    }


    onPlaceLogisticOrder = () => {
        let self = this;
        let selectedRows = self.state.selectedRows.filter(record => {
            return record.logistic !== undefined && record.channelCode !== undefined && record.status && record.status.value === 0
        });
        Promise.all(selectedRows.map(record => {
            return self.props.actions.actionLogistcOrder(tool.clearNull({
                action: 'place-order',
                id: record.id,
            }))
        })).then(function (ress) {
            if (ress.filter(res => res.status === 200).length > 0) {
                self.onRefreshLogisticOrder();
            }
        });
    }

    onFinishLogisticOrder = () => {
        let self = this;
        let selectedRows = self.state.selectedRows.filter(record => {
            return record.status && record.status.value === 1
        });
        Promise.all(selectedRows.map(record => {
            return self.props.actions.actionLogistcOrder(tool.clearNull({
                action: 'finish',
                id: record.id,
            }))
        })).then(function (ress) {
            if (ress.filter(res => res.status === 200).length > 0) {
                self.onRefreshLogisticOrder();
            }
        });
    }

    onPrintlogisticpackagelable = () => {
        let self = this;
        let selectedRows = self.state.selectedRows.filter(record => {
            return record.status && record.status.value && (record.status.value > 0)
        });
        self.props.actions.printLogisticPackageLable(tool.clearNull({
            logisticIds: selectedRows.map(item => item.id),
        })).then(res => {
            if (res.status === 200) {
                fetchGetBlob(res.data.body).then((res) => { // 处理返回的文件流
                    const content = res.data;
                    const blob = new Blob([content]);
                    const fileName = res.data.body.substring(res.data.body.lastIndexOf("\/") + 1, res.data.body.length);
                    if ('download' in document.createElement('a')) { // 非IE下载
                        const elink = document.createElement('a')
                        elink.download = fileName
                        elink.style.display = 'none'
                        elink.href = URL.createObjectURL(blob)
                        document.body.appendChild(elink)
                        elink.click()
                        URL.revokeObjectURL(elink.href) // 释放URL 对象
                        document.body.removeChild(elink)
                    } else { // IE10+下载
                        navigator.msSaveBlob(blob, fileName)
                    }
                })
            }
        })
    }

    onInvalidLogisticOrder = () => {
        let self = this;
        Promise.all(selectedRows.map(record => {
            return self.props.actions.actionLogistcOrder(tool.clearNull({
                action: 'invalide',
                id: record.id,
            }))
        })).then(function (ress) {
            if (ress.filter(res => res.status === 200).length > 0) {
                self.onRefreshLogisticOrder();
            }
        });
    }


    finishLogisticOrder = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!record.status || !record.status.value || (record.status.value < 1)) {
            message.error("请先下单");
            return;
        }
        this.props.actions.actionLogistcOrder(tool.clearNull({
            action: 'finish',
            id: record.id,
        })).then(() => {
            this.onRefreshLogisticOrder();
        })
    }

    invalideLogisticOrder = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        this.props.actions.actionLogistcOrder(tool.clearNull({
            action: 'invalide',
            id: record.id,
        })).then(() => {
            this.onRefreshLogisticOrder();
        })
    }

    deleteLogisticOrder = (record, event) => {
        event.preventDefault();
        event.stopPropagation();
        if (record.status.value > 0) {
            message.error("不能删除已下单的物流订单");
            return false;
        }
        let self = this;
        Modal.confirm({
            title: '删除物流单?',
            content: "如果Winit已确认发货，请联系物流商删除订单!",
            onOk() {
                self.props.actions.deleteLogisticOrder(tool.clearNull({
                    id: record.id,
                })).then(() => {
                    self.onRefreshLogisticOrder();
                })
            }
        });
    }




    openLogisticOrderModal = (record) => {
        let self = this;
        self.setState({
            selectRecord: JSON.parse(JSON.stringify(record)),
            logisticOrderDetailModalShow: true,
        });
        self.props.actions.getLogistcOrderDetail(tool.clearNull({ id: record.id })).then(res => {
            if (res.status === 200) {
                self.setState({
                    selectRecordDetail: res.data.body,
                })
            }
        })

    }

    logisticOrderDetailModalCommit = () => {
        let self = this;
        self.props.actions.actionLogistcOrder(tool.clearNull({
            ...self.state.selectRecord,
            ...{ country: self.state.selectRecord.country.name },
            action: 'info',
        })).then(res => {
            if (res.status === 200) {
                self.onRefreshLogisticOrder();
                this.logisticOrderDetailModalClose();
            }
        })
    }

    logisticOrderDetailModalClose = () => {
        this.setState({
            selectRecord: undefined,
            selectRecordDetail: [],
            logisticOrderDetailModalShow: false,
        })
    }

    onCheckChange = (selectedRowKeys, selectedRows) => {
        this.setState({
            selectedRowKeys,
            selectedRows
        });
    }

    onChangeBuyerName = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.buyerName = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeBuyerPhone = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.buyerPhone = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeBuyerEmail = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.email = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeCountry = (value) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.country = { name: value, value: this.props.enums.enums.country.filter(item => item.name === value)[0].country };
        this.setState({
            selectRecord,
        })
    }

    onChangeStateOrProvince = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.stateOrProvince = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeCity = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.city = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangePost = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.post = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeStreet1 = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.street1 = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeStreet2 = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.street2 = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeHouseNumber = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.houseNumber = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeWeight = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.weight = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeLength = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.length = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeWidth = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.width = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeHeight = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.height = e.target.value;
        this.setState({
            selectRecord,
        })
    }

    onChangeAmount = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.amount = e.target.value;
        this.setState({
            selectRecord,
        })
    }


    onChangeorderLineItemsku = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].sku = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemCnTitle = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].cnTitle = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemEnTitle = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].enTitle = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemPrice = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].price = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemQuality = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].quality = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemTransactionNo = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].transactionNo = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemItemNo = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].itemNo = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemBatteryType = (orderNo, index, e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].batteryType = e.target.value;
        this.setState({
            selectRecord
        })
    }
    onChangeLineItemOriginal = (orderNo, index, value) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[orderNo][index].original = value;
        this.setState({
            selectRecord
        })
    }


    onChangeLogistic = (value) => {
        this.props.actions.listLogisticChannel(tool.clearNull({ logistic: value }));
        this.props.actions.listLogisticDispatch(tool.clearNull({ logistic: value }));
        let selectRecord = this.state.selectRecord;
        selectRecord.logistic = value;
        selectRecord.channelCode = undefined;
        selectRecord.channelName = undefined;
        selectRecord.warehouseCode = undefined;
        selectRecord.warehouseName = undefined;
        selectRecord.dispatchtypeCode = undefined;
        selectRecord.dispatchtypeName = undefined;
        this.setState({
            selectRecord,
        })
    }

    onChangeLogisticChannel = (value) => {
        this.props.actions.listLogisticWarehouse(tool.clearNull({ logistic: this.state.selectRecord.logistic, service: value }));
        let selectRecord = this.state.selectRecord;
        let channelName = this.props.logisticChannel.logisticChannel[this.state.selectRecord.logistic].filter(item => item.code === value)[0].name;
        selectRecord.channelCode = value;
        selectRecord.channelName = channelName;
        this.setState({
            selectRecord,
        })
    }

    onChangeLogisticWarehouse = (value) => {
        let selectRecord = this.state.selectRecord;
        let logisticWarehouses = this.props.logisticWarehouse.logisticWarehouse[this.state.selectRecord.logistic];
        let warehouseName = logisticWarehouses?logisticWarehouses.filter(item => item.code === value)[0].name:undefined;
        selectRecord.warehouseCode = value;
        selectRecord.warehouseName = warehouseName;
        this.setState({
            selectRecord,
        })
    }

    onChangeLogisticDispatchtype = (value) => {
        let selectRecord = this.state.selectRecord;
        let dispatchtypeName = this.props.logisticDispatch.logisticDispatch[this.state.selectRecord.logistic].filter(item => item.code === value)[0].name;
        selectRecord.dispatchtypeCode = value;
        selectRecord.dispatchtypeName = dispatchtypeName;
        this.setState({
            selectRecord,
        })
    }

    onSearchStatusChange = (value) => {
        this.setState({
            searchStatus: value
        })
    }

    onSearchLogisticChange = (value) => {
        this.setState({
            searchLogistic: value
        })
    }

    onSearchChannelChange = (value) => {
        this.setState({
            searchChannel: value
        })
    }

    searchSellerChange = (e) => {
        this.setState({
            searchSeller: e.target.value,
        })
    }

    searchBuyerChange = (e) => {
        this.setState({
            searchBuyer: e.target.value,
        })
    }

    onSearchPlarformChange = (value) => {
        this.setState({
            searchPlatform: value,
        })
    }

    onSearchCountryChange = (value) => {
        this.setState({
            searchCounrty: value,
        })
    }

    makeCountrySelect = (countries) => {
        if (!countries) {
            return [];
        }
        return countries.map((item, index) => {
            return <Option key={index} value={item.name}>{item.country + ' [' + item.name + ']'}</Option>
        })
    }

    makeLogisticSelect = (logistics) => {
        if (!logistics) {
            return [];
        }
        return logistics.map((item, index) => {
            return <Option key={index} value={item.name}>{item.name}</Option>
        })
    }

    makePlatformSelect = (platfroms) => {
        if (!platfroms) {
            return [];
        }
        return platfroms.map((item, index) => {
            return <Option key={index} value={item.name}>{item.name}</Option>
        })
    }


    makeStockData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.stock.pageNum - 1) * this.props.stock.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                productName: item.productName,
                supplierId: item.supplierId,
                supplierName: item.supplierName,
                productUrl: item.productUrl,
                price: item.price,
                weight: item.weight,
                length: item.length ? item.length : 0,
                width: item.width ? item.width : 0,
                height: item.height ? item.height : 0,
                number: item.number,
                status: item.status,
                createTime: item.createTime,
            };
        })
    }

    stockColumns = [
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
        },
        {
            title: '库存编号',
            dataIndex: 'number',
            key: 'number',
            className: 'table',
        },
        {
            title: '价格',
            dataIndex: 'price',
            key: 'price',
            className: 'table',
        },
        {
            title: '重量(g)',
            dataIndex: 'weight',
            key: 'weight',
            className: 'table',
        },
        {
            title: '长*宽*高(cm)',
            dataIndex: 'v',
            key: 'v',
            className: 'table',
            render: (text, record) => {
                return record.length + '*' + record.width + '*' + record.height
            }
        },
        {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            className: 'table',
            render: (text, record) => {
                return record.status ? record.status.name : undefined;
            }
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className: 'table',
        }
    ];

    onRefreshStock = (status = this.state.selectStockStatus, sku = this.state.selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].realSku, pageNum = this.props.stock.pageNum, pageSize = this.props.stock.pageSize) => {
        let params = {
            pageNum,
            pageSize,
            sku: sku,
            status: status,
        }
        this.props.actions.listStocks(tool.clearNull(params));
    }

    onSearchStock = (status = this.state.selectStockStatus, sku = this.state.selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].realSku) => {
        this.onRefreshStock(status, sku, 1);
    }

    onSelectStockPageChange = (pageNum, pageSize) => {
        this.onRefreshStock(this.state.selectStockStatus, this.state.selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].realSku, pageNum, pageSize);
    }

    searchSelectStockStatusChange = (value) => {
        this.setState({
            selectStockStatus: value,
        })
    }

    searchSelectStockSkuChange = (e) => {
        let selectRecord = this.state.selectRecord;
        selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].realSku = e.target.value;
        this.setState({
            selectRecord
        })
    }

    searchStockComponents = () => {
        let defaultSku = (this.state.selectRecord && this.state.selectOrderNo && this.state.selectLineItemIndex)?this.state.selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].realSku:undefined;
        let components = [
            <Select placeholder="状态" style={{ width: '100px' }} defaultValue={0} onChange={(value) => this.searchSelectStockStatusChange(value)}>
                <Option value={-1}>退货</Option>
                <Option value={0}>在库</Option>
                <Option value={1}>出库</Option>
                <Option value={2}>退款</Option>
            </Select>,
            <Input placeholder="sku" style={{ width: '200px' }} defaultValue={defaultSku}  onChange={this.searchSelectStockSkuChange.bind(this)}/>
        ];
        return components;
    }

    onSelectStockOk = (stocks) => {
        let selectRecord = this.state.selectRecord;
        if (!selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].stockNumbers) {
            selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].stockNumbers = [];
        }
        let weight = isNaN(parseFloat(selectRecord.weight)) ? 0.00 : parseFloat(selectRecord.weight);
        for (let i = 0; i < stocks.length; i++) {
            if (stocks[i].status.value !== 0) {
                message.error(stocks[i].number + " 非在库");
                return;
            }
            selectRecord.orderLineItems[this.state.selectOrderNo][this.state.selectLineItemIndex].stockNumbers[i] = stocks[i].number;
            weight = weight + parseFloat((stocks[i].weight) / 1000);
        }
        selectRecord.weight = weight.toFixed(3);
        selectRecord.length = selectRecord.length + stocks[0].length;
        selectRecord.width = selectRecord.width + stocks[0].width;
        selectRecord.height = selectRecord.height + stocks[0].height;
        this.setState({
            selectRecord
        })
        this.onSelectStockCancel();
    }

    onSelectStockCancel = () => {
        this.setState({
            selectLineItemIndex: undefined,
            showStockModal: false,
        })
    }

    onOpenStockModal = (orderNo, index) => {
        this.onSearchStock(0, this.state.selectRecord.orderLineItems[orderNo][index].realSku);
        this.setState({
            selectOrderNo: orderNo,
            selectLineItemIndex: index,
            showStockModal: true,
        })
    }

    onShowImageModal = (image) => {
        this.setState({
            showImage: image,
            showImageModal: true,
        })
    }

    closeImageModal = () => {
        this.setState({
            showImage: undefined,
            showImageModal: false,
        })
    }

    makeDisplyFirstLineItems = (editable, orderLineItems) => {
        let displyLineItems = [];
        Object.keys(orderLineItems).forEach(orderNo => {
            displyLineItems.push(
                orderLineItems[orderNo].map((lineItem, index) => {
                    return <tr key={index}>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.stockNumbers ? lineItem.stockNumbers.join(', ') : ''} onClick={this.onOpenStockModal.bind(this, orderNo, index)} /></td>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.sku} onChange={this.onChangeorderLineItemsku.bind(this, orderNo, index)} /></td>
                        <td><TextArea disabled={!editable} style={{ fontSize: '12px' }} rows={3} cols={60} value={lineItem.cnTitle} onChange={this.onChangeLineItemCnTitle.bind(this, orderNo, index)} /></td>
                        <td><TextArea disabled={!editable} style={{ fontSize: '12px' }} rows={3} cols={60} value={lineItem.enTitle} onChange={this.onChangeLineItemEnTitle.bind(this, orderNo, index)} /></td>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.price} onChange={this.onChangeLineItemPrice.bind(this, orderNo, index)} /></td>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.quality} onChange={this.onChangeLineItemQuality.bind(this, orderNo, index)} /></td>
                        <td>{lineItem.price * lineItem.quality}</td>

                    </tr>
                })
            );
        })
        return displyLineItems;
    }

    makeDisplySecondLineItems = (editable, orderLineItems) => {
        let displyLineItems = [];
        Object.keys(orderLineItems).forEach(orderNo => {
            displyLineItems.push(
                orderLineItems[orderNo].map((lineItem, index) => {
                    return <tr key={index}>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.transactionNo} onChange={this.onChangeLineItemTransactionNo.bind(this, orderNo, index)} /></td>
                        <td><Input disabled={!editable} style={{ fontSize: '12px' }} size='small' value={lineItem.itemNo} onChange={this.onChangeLineItemItemNo.bind(this, orderNo, index)} /></td>
                        <td><RadioGroup disabled={!editable} options={[{ label: '无电', value: 0 }, { label: '内置', value: 1 }, { label: '纯电', value: 2 }, { label: '带电', value: 3 },]} value={lineItem.batteryType} onChange={this.onChangeLineItemBatteryType.bind(this, orderNo, index)} /></td>
                        <td>
                            <Select disabled={!editable} showSearch OptionFilterProp="children" size='small' style={{ width: '400px' }} placeholder="选择国家" allowClear defaultValue={lineItem.original} onChange={this.onChangeLineItemOriginal.bind(this, orderNo, index)}>
                                {this.makeCountrySelect(this.props.enums.enums.country)}
                            </Select>
                        </td>

                    </tr>
                })
            );
        })
        return displyLineItems;
    }


    makeLogisticChannel = (logisticChannels) => {
        const { selectRecord } = this.state;
        if (selectRecord && selectRecord.logistic) {
            if (logisticChannels && logisticChannels[selectRecord.logistic]) {
                return logisticChannels[selectRecord.logistic].map((item, index) => {
                    return <Option key={item.code} value={item.code}>{item.name}</Option>
                })
            } else {
                return <Option key={selectRecord.channelCode} value={selectRecord.channelCode}>{selectRecord.channelName}</Option>;
            }
        }
    }

    makeLogisticWarehouse = (logisticWarehouses) => {
        const { selectRecord } = this.state;
        if (selectRecord && selectRecord.logistic) {
            if (logisticWarehouses && logisticWarehouses[selectRecord.logistic]) {
                return logisticWarehouses[selectRecord.logistic].filter(item => item.channelCode === selectRecord.channelCode).map((item, index) => {
                    return <Option key={item.code} value={item.code}>{item.name}</Option>
                })
            } else {
                return <Option key={selectRecord.warehouseCode} value={selectRecord.warehouseCode}>{selectRecord.warehouseName}</Option>;
            }
        }
    }

    makeLogisticDispatchType = (logisticDispatchTypes) => {
        const { selectRecord } = this.state;
        if (selectRecord && selectRecord.logistic) {
            if (logisticDispatchTypes && logisticDispatchTypes[selectRecord.logistic]) {
                return logisticDispatchTypes[selectRecord.logistic].map((item, index) => {
                    return <Option key={item.code} value={item.code}>{item.name}</Option>
                })
            } else {
                return <Option key={selectRecord.dispatchtypeCode} value={selectRecord.dispatchtypeCode}>{selectRecord.dispatchtypeName}</Option>;
            }
        }
    }


    render() {
        const {
            selectedRowKeys,
            logisticOrderDetailModalShow,
            selectRecord,
            selectRecordDetail,

            searchStatus,
            searchLogistic,
            searchChannel,
            searchPlatform,
            searchSeller,
            searchBuyer,
            searchCounrty,
            showStockModal,
            showImageModal,
            showImage,
        } = this.state;
        const { logisticWarehouse } = this.props.logisticWarehouse;
        const { logisticChannel } = this.props.logisticChannel;
        const { logisticDispatch } = this.props.logisticDispatch;
        const { country, platform, logistic, dispatchtype } = this.props.enums.enums;
        const { logisticOrders, pageSize, pageNum, pageTotal } = this.props.logisticOrder;
        const loading = this.props.logisticWarehouse.loading || this.props.enums.enums.loading || this.props.logisticDispatch.loading || this.props.logisticChannel.loading || this.props.logisticOrder.loading;
        const editable = (selectRecord && selectRecord.status && selectRecord.status.value <= 0);
        const rowSelection = {
            type: 'checkbox',
            selectedRowKeys: selectedRowKeys,
            onChange: this.onCheckChange.bind(this),
        }
        return <div>
            <div className='searchBox'>
                <ul >
                    <li>
                        <div className="g-search">
                            <ul className="search-ul">
                                <li><Input style={{ width: '200px' }} placeholder="卖家" onChange={this.searchSellerChange.bind(this)} value={searchSeller} /></li>
                                <li><Input style={{ width: '200px' }} placeholder="买家" onChange={this.searchBuyerChange.bind(this)} value={searchBuyer} /></li>
                                <li>
                                    <Select style={{ width: '200px' }} placeholder="选择平台" allowClear defaultValue={searchPlatform} onChange={this.onSearchPlarformChange.bind(this)}>
                                        {this.makePlatformSelect(platform)}
                                    </Select>
                                </li>
                                <li>
                                    <Select showSearch OptionFilterProp="children" style={{ width: '400px' }} placeholder="选择国家" allowClear defaultValue={searchCounrty} onChange={this.onSearchCountryChange.bind(this)}>
                                        {this.makeCountrySelect(country)}
                                    </Select>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div className="g-search">
                            <ul className="search-ul">
                                <li>
                                    <Select style={{ width: '200px' }} placeholder="物流" optionFilterProp='children' allowClear defaultValue={searchLogistic} onChange={this.onSearchLogisticChange.bind(this)}>
                                        {
                                            logistic && logistic.map((item, index) => {
                                                return <Option key={index} value={item.name}>{item.name}</Option>
                                            })
                                        }
                                    </Select>
                                </li>
                                <li>
                                    <Select style={{ width: '450px' }} showSearch placeholder="渠道" optionFilterProp='children' allowClear defaultValue={searchChannel} onChange={this.onSearchChannelChange.bind(this)}>
                                        {
                                            logisticChannel && searchLogistic && logisticChannel[searchLogistic] &&
                                            logisticChannel[searchLogistic].map((item, index) => {
                                                return <Option key={index} value={item.code}>{item.name}</Option>
                                            })
                                        }
                                    </Select>
                                </li>
                                <li>
                                    <Select style={{ width: '200px' }} placeholder="状态" defaultValue={searchStatus} allowClear onChange={this.onSearchStatusChange.bind(this)}>
                                        <Option value={-1}>待分配</Option>
                                        <Option value={0}>已分配</Option>
                                        <Option value={1}>已下单</Option>
                                        <Option value={2}>已发货</Option>
                                    </Select>
                                </li>
                                <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                            </ul>
                        </div>
                    </li>

                    <li>
                        <div className="g-search">
                            <ul className="search-ul">
                                <li><Button icon="hdd" onClick={() => {
                                    Modal.confirm({
                                        title: '合并物流单?',
                                        content: "请确保为同一个买家的订单!!!",
                                        onOk: this.onMergeLogisticOrder.bind(this),
                                    });
                                }}>订单合并</Button></li>
                                <li><Button icon="shopping-cart" onClick={() => {
                                    Modal.confirm({
                                        title: '确认物流下单?',
                                        content: "请确保已经配置物流方式!!!",
                                        onOk: this.onPlaceLogisticOrder.bind(this)
                                    });
                                }}>下单</Button></li>
                                <li><Button icon="printer" onClick={() => {
                                    Modal.confirm({
                                        title: '打印物流单?',
                                        content: "请确保已经下物流单!!!",
                                        onOk: this.onPrintAllLogisticOrder.bind(this)
                                    });
                                }}>打印物流单</Button></li>
                                <li><Button icon="audit" onClick={() => {
                                    Modal.confirm({
                                        title: '确认物流发货',
                                        content: "请确保已经向物流商下订单!!!",
                                        onOk: this.onFinishLogisticOrder.bind(this)
                                    });
                                }}>确认发货</Button></li>
                                <li><Button icon="printer" onClick={() => {
                                    Modal.confirm({
                                        title: '确认物流发货',
                                        content: "请确保已经向物流商下订单!!!",
                                        onOk: this.onPrintlogisticpackagelable.bind(this)
                                    });
                                }}>打印揽收单(SpeedPak)</Button></li>
                                <li><Button icon="eye-invisible" onClick={() => {
                                    Modal.confirm({
                                        title: '确认物流订单作废',
                                        content: "!!!",
                                        onOk: this.onInvalidLogisticOrder.bind(this)
                                    });
                                }}>作废</Button></li>
                                <li><Button icon="reload" onClick={this.onSyncLogisticOrder.bind(this)}>同步</Button></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <Table
                bordered
                size={'small'}
                rowSelection={rowSelection}
                loading={loading}
                columns={this.columns}
                dataSource={this.makeColumnsData(logisticOrders)}
                // rowClassName="pointer"
                // onRow={(record) => {
                //     return {
                //         onClick: () => this.openLogisticOrderModal(record),       // 点击行
                //     };
                // }}
                expandedRowRender={(rowData) => {
                    return (
                        <Table
                            columns={this.nestColumns}
                            dataSource={[rowData]}
                            pagination={false}
                        />
                    );
                }}
                pagination={{
                    total: pageTotal,
                    current: pageNum,
                    pageSize: pageSize,
                    showQuickJumper: true,
                    showSizeChanger: true,
                    showTotal: (total, range) => `共 ${total} 条数据`,
                    onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                    onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                }}

            />
            <Modal
                visible={logisticOrderDetailModalShow}
                onOk={editable ? this.logisticOrderDetailModalCommit.bind(this) : this.logisticOrderDetailModalClose.bind(this)}
                onCancel={this.logisticOrderDetailModalClose.bind(this)}
                okText="确认"
                cancelText="关闭"
                destroyOnClose={true}
                confirmLoading={loading}
                width={1200}
                height={1000}
            >
                <div style={{ margin: '32px 32px' }}>
                    <div style={{ border: '1px solid #D2E9FF', margin: '30px' }}>
                        <span className="title">平台信息</span>
                        <table style={{ margin: '10px' }}>
                            <tbody style={{ paddingLeft: '10px' }}>
                                <tr>
                                    <td style={{ width: '200px' }}>销售平台: {selectRecord ? selectRecord.platform : undefined}</td>
                                    <td style={{ width: '200px' }}>卖家ID: {selectRecord ? selectRecord.seller : undefined}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', margin: '30px' }}>
                        <span className="title">订单信息</span>
                        {
                            selectRecordDetail.length > 0 && selectRecordDetail.map((order, index) => {
                                return <div key={index}>
                                    <table style={{ margin: '10px' }}>
                                        <tbody style={{ paddingLeft: '10px' }}>
                                            <tr>
                                                <td colSpan={3}>订单号: {order ? order.platformOrderId : undefined}</td>
                                            </tr>
                                            <tr>
                                                <td style={{ width: '250px' }}>金额: {order ? (order.amount + " " + order.currency) : undefined}</td>
                                                <td style={{ width: '250px' }}>创建时间: {order ? order.createTime : undefined}</td>
                                            </tr>
                                            <tr>
                                                <td style={{ width: '250px' }}>交易状态: {order ? order.cancelState : undefined}</td>
                                                <td style={{ width: '250px' }}>支付状态: {order ? order.paymentStatus : undefined}</td>
                                                <td style={{ width: '250px' }}>交付状态: {order ? order.fullFillmentState : undefined}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    {
                                        order.lineItems && order.lineItems.length > 0 && order.lineItems.map((lineItem, index) => {
                                            return <div key={index} style={{ border: '1px solid #D2E9FF', margin: '30px' }}>
                                                <span className="title">商品信息</span>
                                                <table>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                {
                                                                    (lineItem.images && Array.isArray(lineItem.images) && lineItem.images.length > 0) &&
                                                                    <img className='image' src={lineItem.images[0].path} onClick={() => this.onShowImageModal(lineItem.images[0])} title={lineItem.images[0].name + ' [' + tool.fileSize(lineItem.images[0].size) + ']'} />
                                                                }
                                                            </td>
                                                            <td>
                                                                <table key={lineItem.id} style={{ margin: '10px' }}>
                                                                    <tbody style={{ paddingLeft: '10px' }}>
                                                                        <tr>
                                                                            <td colSpan={3}>标题: {lineItem ? lineItem.title : undefined}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style={{ width: '250px' }}>SKU: {lineItem ? lineItem.sku : undefined} </td>
                                                                            <td style={{ width: '400px' }}>物品编号: {lineItem ? lineItem.legacyItemId : undefined}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colSpan={3}>交易号: {lineItem ? lineItem.transactionId : undefined}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style={{ width: '500px' }}>总价格: {lineItem ? (lineItem.price + ' ' + lineItem.currency) : undefined}</td>
                                                                            <td style={{ width: '250px' }}>数量: {lineItem ? lineItem.quality : undefined}</td>
                                                                            <td style={{ width: '500px' }}>销售类型: {lineItem ? lineItem.type : undefined}</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style={{ width: '250px' }}>刊登市场: {lineItem ? lineItem.listMarket : undefined}</td>
                                                                            <td style={{ width: '250px' }}>销售市场: {lineItem ? lineItem.purchaseMarket : undefined}</td>
                                                                            <td style={{ width: '250px' }}>交付状态: {lineItem ? lineItem.lineItemFulfillmentStatus : undefined}</td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        })
                                    }
                                </div>

                            })
                        }
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', position: 'relative', margin: '30px' }}>
                        <span className="title">买家信息</span>
                        <div className="infoVerchialTable">
                            <table>
                                <tbody>
                                    <tr>
                                        <th>平台ID:</th>
                                        <td>{selectRecord ? selectRecord.buyer : undefined}</td>
                                        <th>姓名:</th>
                                        <td><Input disabled={!editable} size='small' defaultValue={selectRecord ? selectRecord.buyerName : undefined} onChange={this.onChangeBuyerName.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>电话:</th>
                                        <td><Input disabled={!editable} size='small' defaultValue={selectRecord ? selectRecord.buyerPhone : undefined} onChange={this.onChangeBuyerPhone.bind(this)} /></td>
                                        <th>邮件地址:</th>
                                        <td><Input disabled={!editable} size='small' defaultValue={selectRecord ? selectRecord.buyerEmail : undefined} onChange={this.onChangeBuyerEmail.bind(this)} /></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', position: 'relative', margin: '30px' }}>
                        <span className="title">地址信息</span>
                        <div className="infoVerchialTable">
                            <table>
                                <tbody>
                                    <tr>
                                        <th>国家:</th>
                                        <td>
                                            <Select disabled={!editable} style={{ width: '400px' }} size={'small'} optionFilterProp='children' allowClear={true} showSearch={true} defaultValue={(selectRecord && selectRecord.country) ? selectRecord.country.name : undefined} onChange={this.onChangeCountry.bind(this)}>
                                                {
                                                    this.makeCountrySelect(country)
                                                }
                                            </Select>
                                        </td>
                                        <th>省/州:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.stateOrProvince : undefined} onChange={this.onChangeStateOrProvince.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>城市:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.city : undefined} onChange={this.onChangeCity.bind(this)} /></td>
                                        <th>邮编:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.post : undefined} onChange={this.onChangePost.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>街道1:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.street1 : undefined} onChange={this.onChangeStreet1.bind(this)} /></td>
                                        <th>街道2:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.street2 : undefined} onChange={this.onChangeStreet2.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>门牌号:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.houseNumber : undefined} onChange={this.onChangeHouseNumber.bind(this)} /></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', position: 'relative', margin: '30px' }}>
                        <span className="title">包裹信息</span>
                        <div className="infoVerchialTable">
                            <table>
                                <tbody>
                                    <tr>
                                        <th>重量(kg):</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.weight : undefined} onChange={this.onChangeWeight.bind(this)} /></td>
                                        <th>长(cm):</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.length : undefined} onChange={this.onChangeLength.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>宽(cm)</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.width : undefined} onChange={this.onChangeWidth.bind(this)} /></td>
                                        <th>高(cm):</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.height : undefined} onChange={this.onChangeHeight.bind(this)} /></td>
                                    </tr>
                                    <tr>
                                        <th>包裹价值:</th>
                                        <td><Input disabled={!editable} size='small' value={selectRecord ? selectRecord.amount : undefined} onChange={this.onChangeAmount.bind(this)} /></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', position: 'relative', margin: '30px' }}>
                        <span className="title">货物信息</span>
                        <div className="infoTable">
                            <table >
                                <tbody>
                                    <tr>
                                        <th>物品编号</th>
                                        <th>sku</th>
                                        <th>中文标题</th>
                                        <th>英文标题</th>
                                        <th>单价(USD)</th>
                                        <th>数量</th>
                                        <th>总价(USD)</th>
                                    </tr>
                                    {
                                        selectRecord && selectRecord.orderLineItems && this.makeDisplyFirstLineItems(editable, selectRecord.orderLineItems)
                                    }
                                    <tr>
                                        <th>交易号</th>
                                        <th>物品编号</th>
                                        <th>带电</th>
                                        <th>原产地</th>
                                    </tr>
                                    {
                                        selectRecord && selectRecord.orderLineItems && this.makeDisplySecondLineItems(editable, selectRecord.orderLineItems)
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div style={{ border: '1px solid #D2E9FF', position: 'relative', margin: '30px' }}>
                        <span className="title">物流信息</span>
                        <div className="infoVerchialTable">
                            <table>
                                <tbody>
                                    <tr>
                                        <th>物流商:</th>
                                        <td>
                                            <Select disabled={!editable} style={{ width: '400px' }} size={'small'} optionFilterProp='children' allowClear={true} showSearch={true} value={selectRecord ? selectRecord.logistic : undefined} onChange={this.onChangeLogistic.bind(this)}>
                                                {
                                                    logistic && logistic.map((item, index) => {
                                                        return <Option key={index} value={item.name}>{item.name}</Option>
                                                    })
                                                }
                                            </Select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>渠道:</th>
                                        <td>
                                            <Select disabled={!editable} style={{ width: '400px' }} size={'small'} optionFilterProp='children' allowClear={true} showSearch={true} value={selectRecord ? selectRecord.channelCode : undefined} onChange={this.onChangeLogisticChannel.bind(this)}>
                                                {
                                                    this.makeLogisticChannel(logisticChannel)
                                                }
                                            </Select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>仓库:</th>
                                        <td>
                                            <Select disabled={!editable} style={{ width: '400px' }} size={'small'} optionFilterProp='children' allowClear={true} showSearch={true} value={selectRecord ? selectRecord.warehouseCode : undefined} onChange={this.onChangeLogisticWarehouse.bind(this)}>
                                                {
                                                    this.makeLogisticWarehouse(logisticWarehouse)
                                                }
                                            </Select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>送货方式:</th>
                                        <td>
                                            <Select disabled={!editable} style={{ width: '400px' }} size={'small'} optionFilterProp='children' allowClear={true} showSearch={true} value={selectRecord ? selectRecord.dispatchtypeCode : undefined} onChange={this.onChangeLogisticDispatchtype.bind(this)}>
                                                {
                                                    this.makeLogisticDispatchType(logisticDispatch)
                                                }
                                            </Select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>订单号:</th>
                                        <td>{selectRecord ? selectRecord.logisticOrderNo : undefined}</td>
                                        <th>跟踪单号:</th>
                                        <td>{selectRecord ? selectRecord.logisticTrackingNo : undefined}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </Modal>
            <SelectModal
                visible={showStockModal}
                title="选择库存"
                loading={loading}
                columns={this.stockColumns}
                dataSource={this.makeStockData(this.props.stock.stockData)}
                onSelectOk={this.onSelectStockOk.bind(this)}
                onSelectCancel={this.onSelectStockCancel.bind(this)}
                onPageChange={this.onSelectStockPageChange.bind(this)}
                searchComponents={this.searchStockComponents()}
                onSearch={() => this.onSearchStock()}
                pageTotal={this.props.stock.pageTotal}
                pageSize={this.props.stock.pageSize}
                pageNum={this.props.stock.pageNum}
                type={'checkbox'}
            />
            <Modal
                visible={showImageModal}
                onOk={this.closeImageModal.bind(this)}
                onCancel={this.closeImageModal.bind(this)}
                okText="确认"
                cancelText="取消"
                confirmLoading={loading}
                height={400}
                width={800}
            >
                <center>
                    <img style={{ height: '400px', width: 'auto' }} src={showImage && showImage.path} title={showImage && showImage.name}></img>
                </center>
            </Modal>
        </div>
    }





}