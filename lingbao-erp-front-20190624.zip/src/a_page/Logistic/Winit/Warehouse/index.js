import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal} from 'antd';
import {listWinitWarehouse, syncWinitWarehouse} from '../../../../a_redux/actions/winitWarehouse-action';


@connect(
	(state) => {
        return {
        winitWarehouse: state.winitWarehouse,
	}},
	(dispatch) => ({
		actions: bindActionCreators({listWinitWarehouse, syncWinitWarehouse}, dispatch),
	})
)
export default class Warehouse extends React.Component {

    state = {
        pageNum: 0,
        pageSize: 10,
        searchName: undefined,
        searchProductCode: undefined,
    }

    componentDidMount() {
        this.onRefreshWinitWarehouse();
    }

    onRefreshWinitWarehouse = () => {
        this.props.actions.listWinitWarehouse();
    }

    onSyncWinitWarehouse = () => {
        let self = this;
        self.props.actions.syncWinitWarehouse().then(()=>{
            self.props.actions.listWinitWarehouse();
        });
    }

    makeColumnsData = (data) => {
        let newData = [...data];
       
        return newData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.id,
                id: item.id,
                warehouseName: item.warehouseName,
                warehouseCode: item.warehouseCode,
                warehouseAddress: item.warehouseAddress,
                productCode: item.productCode,
                warehouseID: item.warehouseID,
            }
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '仓库名称',
            dataIndex: 'warehouseName',
            key: 'warehouseName',      
		},
		{
            title: '仓库编码',
            dataIndex: 'warehouseCode',
            key: 'warehouseCode',      
        },
        {
            title: '仓库地址',
            dataIndex: 'warehouseAddress',
            key: 'warehouseAddress',      
        },
        {
            title: '仓库ID',
            dataIndex: 'warehouseID',
            key: 'warehouseID',      
        },
        {
            title: '渠道编码',
            dataIndex: 'productCode',
            key: 'productCode',      
        },
    ];

    onChangePage = (pageNum, pageSize) => {
        this.setState({
            pageNum,
            pageSize,
        });
    }

    onSearchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        })
    }

    onSearchProductCodeChange = (e) => {
        this.setState({
            searchProductCode: e.target.value,
        })
    }

    render() {
        const {loading, winitWarehouseData} = this.props.winitWarehouse;
        const {pageSize, pageNum, searchName, searchProductCode} = this.state;
        let filterWinitWarehouseData = [...winitWarehouseData];
        if (this.state.searchName !== undefined) {
            filterWinitWarehouseData = filterWinitWarehouseData.filter(item=>item.warehouseName.indexOf(this.state.searchName)>-1);
        }
        if (this.state.searchProductCode !== undefined) {
            filterWinitWarehouseData = filterWinitWarehouseData.filter(item=>item.productCode.indexOf(this.state.searchProductCode)>-1);
        }
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="仓库名称" defaultValue={searchName} onChange={this.onSearchNameChange.bind(this)}/></li>
                        <li><Input placeholder="渠道编码" defaultValue={searchProductCode} onChange={this.onSearchProductCodeChange.bind(this)}/></li>
                        <li><Button icon="search" onClick={this.onRefreshWinitWarehouse.bind(this)}>查询</Button></li>
                        <li><Button icon="reload" onClick={this.onSyncWinitWarehouse.bind(this)}>同步</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(filterWinitWarehouseData)} 
                    columns={this.columns} 
                    size="small"
                    pagination={{
                        total: filterWinitWarehouseData.length,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        )
    }
}