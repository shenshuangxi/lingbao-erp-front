import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal} from 'antd';
import {listWinitSmallPackagePost, syncWinitSmallPackagePost} from '../../../../a_redux/actions/winitSmallPackagePost-action';


@connect(
	(state) => {
        return {
        winitSmallPackagePost: state.winitSmallPackagePost,
	}},
	(dispatch) => ({
		actions: bindActionCreators({listWinitSmallPackagePost, syncWinitSmallPackagePost}, dispatch),
	})
)
export default class Channel extends React.Component {

    state = {
        pageNum: 0,
        pageSize: 10,
        searchName: undefined,
    }

    componentDidMount() {
        this.onRefreshWinitSmallPackagePost();
    }

    onRefreshWinitSmallPackagePost = () => {
        this.props.actions.listWinitSmallPackagePost();
    }

    onSyncWinitSmallPackagePost = () => {
        let self = this;
        self.props.actions.syncWinitSmallPackagePost().then(()=>{
            self.props.actions.listWinitSmallPackagePost();
        });
    }

    makeColumnsData = (data) => {
        let newData = [...data];
        return newData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.id,
                id: item.id,
                name: item.productName,
                code: item.productCode,
                description: item.description,
            }
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '名称',
            dataIndex: 'name',
            key: 'name',      
		},
		{
            title: '编码',
            dataIndex: 'code',
            key: 'code',      
        },
        {
            title: '描述',
            dataIndex: 'description',
            key: 'description',      
        },
    ];

    onChangePage = (pageNum, pageSize) => {
        this.setState({
            pageNum,
            pageSize,
        });
    }

    onSearchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        })
    }

    render() {
        const {loading, winitSmallPackagePostData} = this.props.winitSmallPackagePost;
        const {pageSize, pageNum, searchName} = this.state;
        let filterWinitSmallPackagePostData = [...winitSmallPackagePostData];
        if (this.state.searchName !== undefined) {
            filterWinitSmallPackagePostData = filterWinitSmallPackagePostData.filter(item=>item.productName.indexOf(this.state.searchName)>-1);
        }
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="名称" defaultValue={searchName} onChange={this.onSearchNameChange.bind(this)}/></li>
                        <li><Button icon="search" onClick={this.onRefreshWinitSmallPackagePost.bind(this)}>查询</Button></li>
                        <li><Button icon="reload" onClick={this.onSyncWinitSmallPackagePost.bind(this)}>同步</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(filterWinitSmallPackagePostData)} 
                    columns={this.columns} 
                    size="small"
                    pagination={{
                        total: filterWinitSmallPackagePostData.length,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        )
    }
}