import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import P from 'prop-types';
import {Table, Form, Modal, Row, Col, Input, Select, Checkbox, Button, Icon} from 'antd';
import DragSortingTable from '../../../a_component/DragSortingTable';

import './index.less';

import { listLogisticWarehouse } from '../../../a_redux/actions/logisticWarehouse-action';
import { listLogisticChannel } from '../../../a_redux/actions/logisticChannel-action';
import {enumsCountry, enumsPlatform, enumsLogistic, enumsDispatchType} from '../../../a_redux/actions/enums-action';
import {getRetailPlatformAccountList} from '../../../a_redux/actions/retailPlatformAccount-action';
import { listLogistcRule, actionLogistcRule, addLogistcRule, deleteLogisticRule, getLogistcRuleDetail} from '../../../a_redux/actions/logistic-rule-action';
import tool from '../../../a_util/tool';

const FormItem = Form.Item;
const Option = Select.Option;

@connect(
    (state) => {
        return {
            enums: state.enums,
            logisticWarehouse: state.logisticWarehouse,
            logisticChannel: state.logisticChannel,
            retailPlatformAccount: state.retailPlatformAccount,
            logisticRule: state.logisticRule,
            directory: state.directory,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ 
            getRetailPlatformAccountList,
            listLogisticWarehouse, 
            listLogisticChannel,
            listLogistcRule, 
            actionLogistcRule,
            addLogistcRule,
            deleteLogisticRule,
            getLogistcRuleDetail,
            enumsCountry, 
            enumsPlatform, 
            enumsLogistic,
            enumsDispatchType,
        }, dispatch),
    })
)


@Form.create()
export default class RulePage extends React.Component {


    state = {
        logisticRuleDetail: undefined,
        showLogisticRuleDetailModal: false,
        logistics:{},
    }

    componentDidMount(){
        this.onRefreshLogisticRule();
    }

    onRefreshBasicData = () => {
        if (this.props.retailPlatformAccount.pageData.length<1) {
            this.props.actions.getRetailPlatformAccountList();
        }
        if (!this.props.enums.enums.logistic) {
            this.props.actions.enumsLogistic();
        }
        if (!this.props.enums.enums.platfrom) {
            this.props.actions.enumsPlatform();
        }
        if (!this.props.enums.enums.country) {
            this.props.actions.enumsCountry();
        }
        if (!this.props.enums.enums.dispatchtype) {
            this.props.actions.enumsDispatchType();
        }
        if (this.props.enums.enums.logistic) {
            this.props.enums.enums.logistic.forEach(logisticPlatform => {
                if (!this.props.logisticWarehouse.logisticWarehouse[logisticPlatform.name]) {
                    this.props.actions.listLogisticWarehouse(tool.clearNull({logistic:logisticPlatform.name}));
                }
                if (!this.props.logisticChannel.logisticChannel[logisticPlatform.name]) {
                    this.props.actions.listLogisticChannel(tool.clearNull({logistic:logisticPlatform.name}));
                }
            });
        }
    }

    onRefreshLogisticRule = () => {
        this.onRefreshBasicData();
        this.props.actions.listLogistcRule();
    }


    makeLogisticRuleColumnsData = (data) => {
        return data.map((item, index)=>{
            return {
                key: item.id,
                id: item.id,
                logistic: item.logistic,
                title: item.title,
                channelCode: item.channelCode,
                channelName: item.channelName,
                warehouseCode: item.warehouseCode,
                warehouseName: item.warehouseName,
                priority: item.priority,
            }
        })
    }

    logisticRuleColumns = [
        {
            title: '优先级',
            dataIndex: 'priority',
            key: 'priority',      
        },
        {
            title: '名称',
            dataIndex: 'title',
            key: 'title',      
		},
        {
            title: '物流',
            dataIndex: 'logistic',
            key: 'logistic',     
        },
		{
            title: '渠道',
            dataIndex: 'channelName',
            key: 'channelName',      
        },
        {
            title: '仓库',
            dataIndex: 'warehouseName',
            key: 'warehouseName',      
        },
        {
            title: '操作', 
            key: 'operation',  
            render: (text, record) => {
                return  <span className="control-btn red" onClick={this.deleteLogisticRuleColumns.bind(this, record)}>
                            <a>删除</a><Icon type="delete"/>
                        </span>
            }
        }
    ];

    deleteLogisticRuleColumns = (record) => {
        this.props.actions.deleteLogisticRule(tool.clearNull({id:record.id})).then(res=>{
            if (res.status === 200) {
                this.onRefreshLogisticRule();
            }
        })
    }

    

    moveRow = (dragIndex, hoverIndex) => {
        let self = this;
        let dragItem = self.props.logisticRule.logisticRules[dragIndex];
        let logisticRule = self.props.logisticRule.logisticRules.filter(item=>item.id!==dragItem.id);
        logisticRule.splice(hoverIndex,0,dragItem);
        let actions = [];
        for(let i=hoverIndex; i< logisticRule.length; i++) {
            logisticRule[i].priority = i+1;
            let newparams = {id:logisticRule[i].id, priority: logisticRule[i].priority, action:'sort'};
            actions.push(self.props.actions.actionLogistcRule(tool.clearNull(newparams)));
        }
        Promise.all(actions).then((ress)=>{
            if (ress.filter(res=>res.status===200).length>0) {
                self.onRefreshLogisticRule();
            }
        });
    }

    openLogisticRulesModal = (event, record, index) => {
        let self = this;
        if (record) {
            this.props.actions.getLogistcRuleDetail(tool.clearNull({id: record.id})).then(res=>{
                if (res.status === 200) {
                    self.setState({
                        logisticRuleDetail: Object.assign(res.data.body, record),
                        showLogisticRuleDetailModal: true,
                    })
                }
            })
        } else {
            self.setState({
                showLogisticRuleDetailModal: true,
            })
        }
    }

    commitLogisticRuleDetailModal = () => {
        let self = this;
        self.props.form.validateFields([
            'logistic',
            'channelCode',
            'warehouseCode',
            'title',
            'platform',
            'account',
            'country',
            'sku',
            'minWeight',
            'maxWeight',
            'eletric',
            'minLenght',
            'maxLenght',
            'minWidth',
            'maxWidth',
            'minHeight',
            'maxHeight',
            'minPrice',
            'maxPrice',
        ], (err, values) => {
            if (err) {
                return false;
            }
            let warehouseName = self.props.logisticWarehouse.logisticWarehouse[values.logistic].filter(item=>item.code === values.warehouseCode)[0].name;
            let channelName = self.props.logisticChannel.logisticChannel[values.logistic].filter(item=>item.code === values.channelCode)[0].name;
            let params = {
                logistic: values.logistic,
                channelCode: values.channelCode,
                channelName: channelName,
                warehouseCode: values.warehouseCode,
                warehouseName: warehouseName,
                title: values.title,
                platforms: values.platform,
                accountIds: values.account,
                countrys: values.country,
                skus: values.sku.split(','),
                minWeight: values.minWeight,
                maxWeight: values.maxWeight,
                containEletric: values.eletric,
                minLenght: values.minLenght,
                maxLenght: values.maxLenght,
                minWidth: values.minWidth,
                maxWidth: values.maxWidth,
                minHeight: values.minHeight,
                maxHeight: values.maxHeight,
                minPrice: values.minPrice,
                maxPrice: values.maxPrice,
            }
            if (!self.state.logisticRuleDetail) {
                params = Object.assign(params, {priority:this.props.logisticRule.logisticRules.length+1});
                self.props.actions.addLogistcRule(tool.clearNull(params)).then(()=>{
                    self.closeLogisticRuleDetailModal();
                    self.onRefreshLogisticRule()
                })
            } else {
                params = {...params, priority:self.state.logisticRuleDetail.priority, 'id':self.state.logisticRuleDetail.id, 'action':'info'}
                self.props.actions.actionLogistcRule(tool.clearNull(params)).then(()=>{
                    self.closeLogisticRuleDetailModal();
                    self.onRefreshLogisticRule()
                });
            }
        });
    }

    closeLogisticRuleDetailModal = () => {
        this.setState({
            logisticRuleDetail: undefined,
            showLogisticRuleDetailModal: false,
        })
        this.props.form.resetFields();
    }

    render() {
        const {logisticWarehouse} = this.props.logisticWarehouse;
        const {logisticChannel} = this.props.logisticChannel;
        const {logisticRules} = this.props.logisticRule;
        const {country, platform, logistic} = this.props.enums.enums;
        const loading = this.props.logisticWarehouse.loading || this.props.logisticChannel.loading || this.props.logisticRule.loading;
        const {logisticRuleDetail, showLogisticRuleDetailModal} = this.state;
        const { getFieldDecorator } = this.props.form;
        return  <div>
                    <div className="g-search">
                        <ul className="search-ul">
                            <li><Button icon="reload" onClick={this.onRefreshLogisticRule.bind(this)}>刷新</Button></li>
                            <li><Button icon="plus" onClick={this.openLogisticRulesModal.bind(this)}>添加</Button></li>
                        </ul>
                    </div>
                    <DragSortingTable 
                        title={() => <strong>可拖曳排序</strong>}
                        columns={this.logisticRuleColumns}
                        loading={loading}
                        dataSource={this.makeLogisticRuleColumnsData(logisticRules)}
                        moveRowFunc={this.moveRow.bind(this)}
                        onDoubleClick = {this.openLogisticRulesModal.bind(this)}
                        pagination={false}
                    />
                    <Modal
                        visible={showLogisticRuleDetailModal}
                        onOk={this.commitLogisticRuleDetailModal.bind(this)}
                        onCancel={this.closeLogisticRuleDetailModal.bind(this)}
                        okText="确认"
                        cancelText="取消"
                        confirmLoading={loading}
                        height={600}
                        width={800}
                    >
                        <Form style={{fontSize:'10px'}}>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="名称">
                                        {getFieldDecorator('title', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.title:undefined,
                                            rules: [{required: true, message: '请填写名称'}]
                                        })(<Input placeholder="规则名称"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="电商平台">
                                        {getFieldDecorator('platform', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.platform.map(item=>item.name):[],
                                            rules: [{required: true, message: '请选择电商平台'}]
                                        })(
                                            <Select optionFilterProp='children' mode='multiple' placeholder="请选择电商平台">
                                                {
                                                    platform && platform.map((item, index)=>{
                                                            return <Option key={index} value={item.name}>{item.name}</Option>
                                                        })
                                                }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="卖家账号">
                                        {getFieldDecorator('account', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.account.map(item=>item.id):undefined,
                                            rules: [{required: true, message: '请选择卖家账号'}]
                                        })(
                                            <Select optionFilterProp='children' mode='multiple' placeholder="请选择卖家账号">
                                                {
                                                    this.props.retailPlatformAccount.pageData && 
                                                    this.props.retailPlatformAccount.pageData.map((item, index)=>{
                                                            return <Option key={index} value={item.id}>{item.account}</Option>
                                                        })
                                                }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="配送国家">
                                        {getFieldDecorator('country', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.country.map(item=>item.name):undefined,
                                            rules: [{required: true, message: '请选择配送国家'}]
                                        })(
                                            <Select optionFilterProp='children' mode='multiple' placeholder="请选择配送国家">
                                            {
                                                country && country.map((item, index)=>{
                                                        return <Option key={index} value={item.name}>{item.country+' ['+item.name+']'}</Option>
                                                    })
                                            }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label={<span>sku<strong>(,隔开)</strong></span>}>
                                        {getFieldDecorator('sku', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.sku?logisticRuleDetail.sku.join(','):undefined,
                                            rules: [{required: true, message: '请填写sku'}]
                                        })(<Input placeholder="请填写sku"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="带电">
                                        {getFieldDecorator('eletric', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.eletric:undefined,
                                            valuePropName: 'checked',
                                        })(<Checkbox />)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:6}, wrapperCol:{span:10}}} label="价格范围">
                                        {getFieldDecorator('minPrice', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.pricescope?logisticRuleDetail.pricescope.split(',')[0]:undefined,
                                        })(<Input placeholder="最低价格"/>)}
                                    </FormItem>
                                </Col>
                                <Col span={12}>
                                    <FormItem  {...{labelCol:{span:1}, wrapperCol:{span:10}}}>
                                        {getFieldDecorator('maxPrice', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.pricescope?logisticRuleDetail.pricescope.split(',')[1]:undefined,
                                        })(<Input placeholder="最高价格"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:6}, wrapperCol:{span:10}}} label="重量范围">
                                        {getFieldDecorator('minWeight', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.weightscope?logisticRuleDetail.weightscope.split(',')[0]:undefined,
                                        })(<Input placeholder="请填写最低重量"/>)}
                                    </FormItem>
                                </Col>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:1}, wrapperCol:{span:10}}}>
                                        {getFieldDecorator('maxWeight', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.weightscope?logisticRuleDetail.weightscope.split(',')[1]:undefined,
                                        })(<Input placeholder="请填写最大重量"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:6}, wrapperCol:{span:10}}} label="长度范围">
                                        {getFieldDecorator('minLength', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.lengthscope?logisticRuleDetail.lengthscope.split(',')[0]:undefined,
                                        })(<Input placeholder="请填写最小长度"/>)}
                                    </FormItem>
                                </Col>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:1}, wrapperCol:{span:10}}}>
                                        {getFieldDecorator('maxLength', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.lengthscope?logisticRuleDetail.lengthscope.split(',')[1]:undefined,
                                        })(<Input placeholder="请填写最大长度"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:6}, wrapperCol:{span:10}}} label="宽度范围">
                                        {getFieldDecorator('minWidth', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.widthscope?logisticRuleDetail.widthscope.split(',')[0]:undefined,
                                        })(<Input placeholder="请填写最小宽度"/>)}
                                    </FormItem>
                                </Col>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:1}, wrapperCol:{span:10}}}>
                                        {getFieldDecorator('maxWidth', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.widthscope?logisticRuleDetail.widthscope.split(',')[1]:undefined,
                                        })(<Input placeholder="请填写最大宽度"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={12}>
                                    <FormItem {...{labelCol:{span:6}, wrapperCol:{span:10}}} label="高度范围">
                                        {getFieldDecorator('minHeight', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.heightscope?logisticRuleDetail.heightscope.split(',')[0]:undefined,
                                        })(<Input placeholder="请填写最小高度"/>)}
                                    </FormItem>
                                </Col>
                                <Col span={12}>
                                    <FormItem  {...{labelCol:{span:1}, wrapperCol:{span:10}}}>
                                        {getFieldDecorator('maxHeight', {
                                            initialValue: logisticRuleDetail && logisticRuleDetail.heightscope?logisticRuleDetail.heightscope.split(',')[1]:undefined,
                                        })(<Input placeholder="请填写最大高度"/>)}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}}  label="物流商">
                                        {getFieldDecorator('logistic', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.logistic:undefined,
                                            rules: [{required: true, message: '选择物流商'}]
                                        })(
                                            <Select showSearch optionFilterProp='children' placeholder="选择物流商">
                                            {
                                                logistic && logistic.map((item, index)=>{
                                                        return <Option key={index} value={item.name}>{item.name}</Option>
                                                    })
                                            }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}} label="物流渠道">
                                        {getFieldDecorator('channelCode', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.channelCode:undefined,
                                            rules: [{required: true, message: '选择物流渠道'}]
                                        })(
                                            <Select showSearch optionFilterProp='children' placeholder="选择物流渠道">
                                            {
                                                logisticChannel && this.props.form.getFieldValue('logistic') && logisticChannel[this.props.form.getFieldValue('logistic')] && 
                                                logisticChannel[this.props.form.getFieldValue('logistic')].map((item, index)=>{
                                                        return <Option key={index} value={item.code}>{item.name}</Option>
                                                    })
                                            }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                            <Row>
                                <Col span={24}>
                                    <FormItem {...{labelCol:{span:3}, wrapperCol:{span:18}}} label="物流仓库">
                                        {getFieldDecorator('warehouseCode', {
                                            initialValue: logisticRuleDetail?logisticRuleDetail.warehouseCode:undefined,
                                            rules: [{required: true, message: '选择物流仓库'}]
                                        })(
                                            <Select showSearch optionFilterProp='children' placeholder="选择物流仓库">
                                            {
                                                logisticWarehouse && this.props.form.getFieldValue('logistic') && this.props.form.getFieldValue('channelCode') && 
                                                logisticWarehouse[this.props.form.getFieldValue('logistic')].filter(item=>item.channelCode===this.props.form.getFieldValue('channelCode')).map((item, index)=>{
                                                        return <Option key={index} value={item.code}>{item.name}</Option>
                                                    })
                                            }
                                            </Select>
                                        )}
                                    </FormItem>
                                </Col>
                            </Row>
                        </Form>
                    </Modal>
                </div>
    }
    
}