import React, {Component} from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../../a_util/tool';
import {Input, Button, Table, Modal, Tag } from 'antd';
import {getServiceList, getDirections, syncService} from '../../../../a_redux/actions/edis-service-action';

const { CheckableTag } = Tag;

@connect(
    (state) => {
        return {
            edisservice: state.edisservice,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getServiceList,
            syncService,
            getDirections,
        }, dispatch),
    })
)
export default class Service extends Component {

    state = {
        pageNum: 0,
        pageSize: 10,
        directionPageNum: 0, 
        directionPageSize: 10,
        searchName: undefined,
        searchDirectionToName: undefined,
        showDirectionModal: false,
        selectRecord: undefined,
        showDescriptioModal: false,
        descriptionType:'zh',
    }

    componentDidMount() {
        this.onRefreshService();
    }

    onRefreshService = (searchName=this.state.searchName, pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        console.log(searchName);
        this.props.actions.getServiceList(tool.clearNull({
            nameZh:searchName,
            pageNum:pageNum,
            pageSize:pageSize,
        }));
    }

    onSyncService = () => {
        let self = this;
        self.props.actions.syncService().then(()=>{
            self.onRefreshService();
        });
    }


    onRefreshDirection = (edisServiceId=this.state.selectRecord.id, pageNum=this.state.directionPageNum, pageSize=this.state.directionPageSize) => {
        this.props.actions.getDirections(tool.clearNull({
            edisServiceId:edisServiceId,
            pageNum:pageNum,
            pageSize:pageSize,
        }));
    }

    makeColumnsData = (data) => {
        let newData = [...data];
        return newData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.id,
                id: item.id,
                supportBatteryType: item.supportBatteryType,
                serviceId: item.serviceId,
                nameZh: item.nameZh,
                nameHk: item.nameHk,
                nameEn: item.nameEn,
                maxWeight: item.maxWeight,
                maxTotalLength: item.maxTotalLength,
                maxLength: item.maxLength,
                incoterms: item.incoterms,
                descriptionZh: item.descriptionZh,
                descriptionHk: item.descriptionHk,
                descriptionEn: item.descriptionEn,
            }
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '名称',
            dataIndex: 'nameZh',
            key: 'nameZh',      
		},
		{
            title: '编码',
            dataIndex: 'serviceId',
            key: 'serviceId',      
        },
        {
            title: '带电',
            dataIndex:'supportBatteryType',
            key:'supportBatteryType',
            render: (text, record) => {
                return record.supportBatteryType ? record.supportBatteryType.name : undefined;
            }
        },
        {
            title: '关税',
            dataIndex:'incoterms',
            key:'incoterms',
            render: (text, record) => {
                return record.incoterms ? record.incoterms.name : undefined;
            }
        },
        {
            title: '最大(周长)',
            dataIndex:'maxTotalLength',
            key:'maxTotalLength',
        },
        {
            title: '最大(长度)',
            dataIndex:'maxLength',
            key:'maxLength',
        },
        {
            title: '最大(重量)',
            dataIndex:'maxWeight',
            key:'maxWeight',
        },
        {
            title: '路线',
            dataIndex:'directions',
            key:'directions',
            render: (text, record) => {
                return <span style={{cursor:'pointer', color:'blue'}} onClick={()=>this.openDrectionModal(record)}>点击查看路线</span> ;
            } 
        },
        {
            title: '描述',
            dataIndex: 'descriptionZh',
            key: 'descriptionZh',   
            render: (text, record) => {
                return <span style={{cursor:'pointer', color:'blue'}} onClick={()=>this.openDescriptionModal(record)}>点击查看描述</span> ;
            }   
        },
    ];

    openDescriptionModal = (record) => {
        this.setState({
            showDescriptioModal: true,
            selectRecord: record,
        })
    }

    closeDescriptionModal = () => {
        this.setState({
            showDescriptioModal: false,
            selectRecord: undefined,
        })
    }

    openDrectionModal = (record) => {
        this.onRefreshDirection(record.id);
        this.setState({
            showDirectionModal: true,
            selectRecord: record,
        })
    }

    closeDirectionModal = () => {
        this.setState({
            showDirectionModal: false,
            selectRecord: undefined,
        })
    }

    makeDirectionColumns = (directionData) => {
       
        return directionData.map((item, index)=>{
            return {
                serial: index+1,
                key: index+1,
                from : item.from,
                to : item.to,
            }
        })
    }

    directionColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '出发地',
            dataIndex: 'from',
            key: 'from',
            render: (text, record) => {
                return record.from && record.from.name;
            }      
		},
		{
            title: '目的地',
            dataIndex: 'to',
            key: 'to',   
            render: (text, record) => {
                return record.to && record.to.name;
            }   
        },
    ];

    onChangePage = (pageNum, pageSize) => {
        this.setState({
            pageNum: pageNum,
            pageSize: pageSize,
        })
        this.onRefreshService(this.state.searchName, pageNum, pageSize);
    }

    onChangeDirectionPage = (pageNum, pageSize) => {
        this.setState({
            directionPageNum: pageNum,
            directionPageSize: pageSize,
        })
    }

    onSearchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        })
    }

    onSearchDirectionToNameChange = (e) => {
        this.setState({
            searchDirectionToName: e.target.value,
        })
    }

    onDescriptionChange = (descriptionType) => {
        this.setState({
            descriptionType: descriptionType,
        })
    }

    render() {
        const {loading, edisServices, edisDirections, total} = this.props.edisservice;
        const {directionPageNum, directionPageSize, showDirectionModal, searchDirectionToName, showDescriptioModal, descriptionType, selectRecord, pageSize, pageNum, searchName} = this.state;
        let newEdisDirections = [...edisDirections];
        if (searchDirectionToName) {
            newEdisDirections = edisDirections.filter(direction=>(
                direction.from.name.toLowerCase().indexOf(this.state.searchDirectionToName.toLowerCase())>-1
                || direction.from.value.toLowerCase().indexOf(this.state.searchDirectionToName.toLowerCase())>-1
                || direction.to.name.toLowerCase().indexOf(this.state.searchDirectionToName.toLowerCase())>-1
                || direction.to.value.toLowerCase().indexOf(this.state.searchDirectionToName.toLowerCase())>-1
                ));
        }

        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="名称" defaultValue={searchName} onChange={this.onSearchNameChange.bind(this)}/></li>
                        <li><Button icon="search" onClick={()=>this.onRefreshService()}>查询</Button></li>
                        <li><Button icon="reload" onClick={this.onSyncService.bind(this)}>同步</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(edisServices)} 
                    columns={this.columns} 
                    size="small"
                    pagination={{
                        total: total,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal 
                    visible={showDirectionModal}
                    onOk={this.closeDirectionModal.bind(this)}
                    onCancel={this.closeDirectionModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    width={800}
                    height={600}
                >
                     <div className="g-search">
                        <ul className="search-ul">
                            <li><Input placeholder="名称" defaultValue={searchDirectionToName} onChange={this.onSearchDirectionToNameChange.bind(this)}/></li>
                            <li><Button icon="search" onClick={()=>this.onRefreshDirection(selectRecord.id)}>查询</Button></li>
                        </ul>
                    </div>
                    <Table 
                        bordered
                        loading={loading}
                        dataSource={this.makeDirectionColumns(newEdisDirections)} 
                        columns={this.directionColumns} 
                        size="small"
                        pagination={{
                            total: newEdisDirections.length,
                            current: directionPageNum,
                            pageSize: directionPageSize,
                            showQuickJumper: true,
                            showSizeChanger: true,
                            showTotal: (total, range) => `共 ${total} 条数据`,
                            onShowSizeChange: (pageNum, pageSize) => this.onChangeDirectionPage(1, pageSize),
                            onChange: (pageNum, pageSize) => this.onChangeDirectionPage(pageNum, pageSize)
                        }}
                    />
                </Modal>
                <Modal 
                    visible={showDescriptioModal}
                    onOk={this.closeDescriptionModal.bind(this)}
                    onCancel={this.closeDescriptionModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    width={800}
                    height={600}
                >
                    <Tag color={descriptionType==='zh'?'#87d068':'green'} onClick={()=>this.onDescriptionChange('zh')}>中文</Tag>
                    <Tag color={descriptionType==='en'?'#f50':'red'} onClick={()=>this.onDescriptionChange('en')}>英文</Tag>
                    {
                        selectRecord && (descriptionType==='zh'?<div dangerouslySetInnerHTML={{__html: selectRecord.descriptionZh}} />:<div dangerouslySetInnerHTML={{__html: selectRecord.descriptionEn}} />)
                    }
                </Modal>
            </div>
        )
    }

}