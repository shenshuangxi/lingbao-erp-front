import React, {Component} from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../a_util/tool';

import {getEdisAddressList, addEdisAddress, actionEdisAddress, deleteEdisAddress} from '../../../a_redux/actions/edis-address-action';

import './index.less';

@connect(
    (state) => {
        return {
            edisaddress: state.edisaddress,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getEdisAddressList,
            addEdisAddress,
            actionEdisAddress,
            deleteEdisAddress,
        }, dispatch),
    })
)

export default class AddressManager extends Component {

    componentDidMount() {
        this.onRefreshEdisAddress();
    }

    onRefreshEdisAddress = () => {
        this.props.actions.getEdisAddressList();
    }

    render() {
        const { edisAddresses, loading } = this.props.edisaddress;
        console.log(edisAddresses);
        return (
            <div className="baseAddressTable">
                <span style={{width:'100%', backgroundColor:'#F7F8FA', fontSize:'16px', fontWeight:'bold'}}>地址信息</span>
                <table >
                    <tbody>
                        <tr style={{backgroundColor:'#EDEEF2'}}>
                            <th>名称</th>
                            <th>公司名称</th>
                            <th>联系人</th>
                            <th>电话号码</th>
                            <th>地址详情(中文)</th>
                            <th>地址详情(英文)</th>
                            <th>邮政编码</th>
                            <th>状态</th>
                        </tr>
                        {
                            edisAddresses.map((edisAddress) => {
                                return <tr key={edisAddress.id}>
                                    <td>{edisAddress.name}</td>
                                    <td>{edisAddress.company}</td>
                                    <td>{edisAddress.contact}</td>
                                    <td>{edisAddress.mobile}</td>
                                    <td>{edisAddress.addressDetailZh}</td>
                                    <td>{edisAddress.addressDetailEn}</td>
                                    <td>{edisAddress.postcode}</td>
                                    <td>{edisAddress.status.name}</td>
                                </tr>
                            })
                        }
                    </tbody>
                </table>
            </div>
        ); 
    }

}
