import React, {Component} from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../../a_util/tool';
import {Input, Button, Table } from 'antd';
import {getEdisDropoffSiteList, syncEdisDropoffSite} from '../../../../a_redux/actions/edis-dropoff-site-action';

@connect(
    (state) => {
        return {
            edisdropoffsite: state.edisdropoffsite,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getEdisDropoffSiteList,
            syncEdisDropoffSite,
        }, dispatch),
    })
)
export default class DropoffSite extends Component {

    state = {
        pageNum: 0,
        pageSize: 10,
        searchName: undefined,
    }

    componentDidMount() {
        this.onRefreshDropoffSite();
    }

    onRefreshDropoffSite = (searchName=this.state.searchName, pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        console.log(searchName);
        console.log(searchName);
        this.props.actions.getEdisDropoffSiteList(tool.clearNull({
            name: searchName,
            pageNum:pageNum,
            pageSize:pageSize,
        }));
    }

    onSyncDropoffSite = () => {
        let self = this;
        self.props.actions.syncEdisDropoffSite().then(()=>{
            self.onRefreshDropoffSite();
        });
    }

    makeColumnsData = (data) => {
        let newData = [...data];
        return newData.map((item, index)=>{
            return {
                serial: index+1,
                key: item.id,
                id: item.id,
                dropoffSiteId: item.dropoffSiteId,
                street1: item.street1,
                province: item.province,
                mobile: item.mobile,
                name: item.name,
                district: item.district,
                country: item.country,
                contact: item.contact,
                city: item.city,
                countryNameZh: item.countryNameZh,
                provinceNameZh: item.provinceNameZh,
                cityNameZh: item.cityNameZh,
                districtNameZh: item.districtNameZh,
                countryNameEn: item.countryNameEn,
                provinceNameEn: item.provinceNameEn,
                cityNameEn: item.cityNameEn,
                districtNameEn: item.districtNameEn,
            }
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '名称',
            dataIndex: 'name',
            key: 'name',      
		},
		{
            title: '编码',
            dataIndex: 'dropoffSiteId',
            key: 'dropoffSiteId',      
        },
        {
            title: '联系人',
            dataIndex:'contact',
            key:'contact',
        },
        {
            title: '电话',
            dataIndex:'mobile',
            key:'mobile',
        },
        {
            title: '地址',
            dataIndex:'address',
            key:'address',
            render: (text, record) => {
                return record.countryNameZh + ' ' + record.provinceNameZh + ' ' + record.cityNameZh + ' ' + record.districtNameZh + ' ' + record.street1;
        
            },
        }
    ];

    onChangePage = (pageNum, pageSize) => {
        this.setState({
            pageNum: pageNum,
            pageSize: pageSize,
        })
        this.onRefreshDropoffSite(this.state.searchName, pageNum, pageSize);
    }

    onSearchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        })
    }

    render() {
        const {loading, edisDropoffSites, total} = this.props.edisdropoffsite;
        const {pageSize, pageNum, searchName} = this.state;
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="名称" defaultValue={searchName} onChange={this.onSearchNameChange.bind(this)}/></li>
                        <li><Button icon="search" onClick={()=>this.onRefreshDropoffSite()}>查询</Button></li>
                        <li><Button icon="reload" onClick={this.onSyncDropoffSite.bind(this)}>同步</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(edisDropoffSites)} 
                    columns={this.columns} 
                    size="small"
                    pagination={{
                        total: total,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        )
    }

}