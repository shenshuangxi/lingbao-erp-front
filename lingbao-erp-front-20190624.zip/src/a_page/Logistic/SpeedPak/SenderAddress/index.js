import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../../a_util/tool';
import {Button, Icon, Modal, Form, Select, Radio, Input, Row, Col, Divider, Tooltip} from 'antd';
import { getEdisSenderAddressList, syncEdisSenderAddressList, addEdisSenderAddress, actionEdisSenderAddress, deleteEdisSenderAddress } from '../../../../a_redux/actions/edis-sender-address-action';
import {getEdisAddressCodeList} from '../../../../a_redux/actions/edis-address-code-action';

import './index.less';
const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;

@connect(
    (state) => {
        return {
            edissenderaddress: state.edissenderaddress,
            edisaddresscode: state.edisaddresscode,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getEdisSenderAddressList,
            syncEdisSenderAddressList,
            addEdisSenderAddress,
            actionEdisSenderAddress,
            deleteEdisSenderAddress,
            getEdisAddressCodeList,
        }, dispatch),
    })
)
@Form.create()
export default class SenderAddress extends Component {

    state = {
        showAddressModal:false,
        selectRecord:undefined,
    }

    componentDidMount() {
        this.onRefreshEdisSenderAddress();
    }

    onRefreshEdisSenderAddress = () => {
        this.props.actions.getEdisSenderAddressList();
    }

    onDefaultAddress = (edisSenderAddress) => {
        this.props.actions.actionEdisSenderAddress(tool.clearNull({
            action: 'defaultAddress',
            id: edisSenderAddress.id,
        })).then(res => {
            if (res.status === 200) {
                this.onRefreshEdisSenderAddress();
            }
        })
    }

    syncSenderAddress = () => {
        this.props.actions.syncEdisSenderAddressList().then(ret => {
            if (ret.status === 200) {
                this.onRefreshEdisSenderAddress();
            }
        });
    }

    openAddressModal = (record) => {
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            level: 0,
        }));
        this.setState({
            showAddressModal: true,
            selectRecord: record,
        })
    }

    commitAddressModal = () => {
        let self = this;
        self.props.form.validateFields([
            'name',
            'type',
            'contact',
            'company',
            'mobile',
            'postcode',
            'countryCode',
            'province',
            'city',
            'district',
            'street1',
        ], (err, values) => {
            console.log(values);
            if (err) {
                return false;
            }

            let params = {
                type: values.type,
                name: values.name,
                contact: values.contact,
                company: values.company,
                mobile: values.mobile,
                postcode: values.postcode,
                countryCode: values.countryCode,
                province: values.province,
                contact: values.contact,
                city: values.city,
                district: values.district,
                street1: values.street1,
            }
            console.log(params);
            if (!self.state.selectRecord) {
                self.props.actions.addEdisSenderAddress(tool.clearNull(params)).then((res) => {
                    if (res.status === 200) {
                        self.closeAddressModal();
                        self.onRefreshEdisSenderAddress();
                    }

                })
            } else {
                params = { ...params, 'id': self.state.selectRecord.id, 'action': 'info' }
                self.props.actions.actionEdisSenderAddress(tool.clearNull(params)).then(() => {
                    self.closeAddressModal();
                    self.onRefreshEdisSenderAddress();
                });
            }
        });

    }

    closeAddressModal = () => {
        this.setState({
            showAddressModal: false,
            selectRecord: undefined,
        })
        this.props.form.resetFields();
    }

    onAddressChange = (parentCode) => {
        console.log(parentCode);
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            parentCode: parentCode
        }));
    }

    onChangeType = () => {
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            level: 0,
        }));
    }

    render() {
        const {showAddressModal, selectRecord} = this.state;
        const { edisSenderAddresses } = this.props.edissenderaddress;
        const {edisAddressCodes} = this.props.edisaddresscode;
        const loading = this.props.edissenderaddress.loading || this.props.edisaddresscode.loading;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: { span: 3 },
            wrapperCol: { span: 17 },
        };
        const formItemLayoutTwo = {  // 表单布局
            labelCol: { span: 7 },
            wrapperCol: { span: 15 },
        };
        return (
            <div>
                <div>设置用户的标签地址信息</div>
                <div style={{ display: 'flex' }}>
                    <div style={{ paddingRight: '10px' }}>已设置 {<strong>{edisSenderAddresses.length}</strong>} 条 标签地址</div>
                    <Button loading={this.props.edissenderaddress.loading} icon="search" onClick={() => this.onRefreshEdisSenderAddress()}>查询</Button>
                    <Divider type='vertical' />
                    <Button loading={this.props.edissenderaddress.loading} icon="reload" onClick={() => this.syncSenderAddress()}>同步</Button>
                    <Divider type='vertical' />
                    <Button loading={this.props.edissenderaddress.loading} icon="plus" onClick={() => this.openAddressModal()}>添加</Button>
                </div>
                <div className='addressDiv'>
                    {
                        edisSenderAddresses.map(edisSenderAddress => {
                            return (
                                <div key={edisSenderAddress.addressId} className="addressTableDiv">
                                    <div className="addressCapation">
                                        <div title={edisSenderAddress.name} className="addressCapationTitle">{edisSenderAddress.name}</div>
                                        <div onClick={()=>this.onDefaultAddress(edisSenderAddress)} className={edisSenderAddress.defaultAddress?'addressCapationButtonChoose':'addressCapationButton'}>默认地址</div>
                                    </div>
                                    <table className="addressTable" >
                                        <tbody>
                                            <tr>
                                                <td className='label'>联系人姓名: </td><td className='content'>{edisSenderAddress.contact}</td>
                                            </tr>
                                            <tr>
                                                <td className='label'>公司名称: </td><td className='content'>{edisSenderAddress.company}</td>
                                            </tr>
                                            <tr>
                                                <td className='label'>地址信息: </td><td className='content'>{edisSenderAddress.countryZh + ' ' + edisSenderAddress.provinceZh + ' ' + edisSenderAddress.cityZh + ' ' + edisSenderAddress.districtZh + ' ' + edisSenderAddress.street1}</td>
                                            </tr>
                                            <tr>
                                                <td className='label'>邮政编码: </td><td className='content'>{edisSenderAddress.postcode}</td>
                                            </tr>
                                            <tr>
                                                <td className='label'>手机号码: </td><td className='content'>{edisSenderAddress.mobile}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            );
                        })
                    }
                </div>
                <Modal
                    visible={showAddressModal}
                    onOk={this.commitAddressModal.bind(this)}
                    onCancel={this.closeAddressModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    width={800}
                    height={600}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="名称">
                            {getFieldDecorator('name', {
                                initialValue: selectRecord ? selectRecord.name : undefined,
                                rules: [{ required: true, message: '请填写名称' }]
                            })(<Input placeholder="请填写名称" />)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="类型">
                            {getFieldDecorator('type', {
                                initialValue: (selectRecord&&selectRecord.type!==undefined)?selectRecord.type.value:0,
                                rules: [{required: true, message: '请选择类型'}]
                            })(
                                <RadioGroup onChange={this.onChangeType.bind(this)} >
                                    <Radio value={0}>发货地址</Radio>
                                    <Radio value={1}>退货地址</Radio>
                                </RadioGroup>
                            )}
                        </FormItem>
                        <Row >
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="联系人">
                                    {getFieldDecorator('contact', {
                                        initialValue: selectRecord ? selectRecord.contact : undefined,
                                        rules: [{ required: true, message: '请填写联系人' }]
                                    })(<Input placeholder="请填写联系人" />)}
                                </FormItem>
                            </Col>
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="公司">
                                    {getFieldDecorator('company', {
                                        initialValue: selectRecord ? selectRecord.company : undefined,
                                    })(<Input placeholder="请填写公司" />)}
                                </FormItem>
                            </Col>
                        </Row>
                        <Row >
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="国家/地区">
                                    {getFieldDecorator('countryCode', {
                                        initialValue: selectRecord ? selectRecord.countryCode : undefined,
                                        rules: [{ required: true, message: '请选择国家/地区' }]
                                    })(
                                        <Select
                                            placeholder='国家/地区'
                                            showSearch
                                            style={{ width: 200 }}
                                            optionFilterProp="children"
                                            onSearch={this.onChangeType.bind(this)}
                                            filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            onChange={(value) => this.onAddressChange(value)}
                                        >
                                            {edisAddressCodes.filter(item => item.level === 0).map(country => <Option key={country.code} value={country.code}>{country.nameZh}</Option>)}
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="省/州">
                                    {getFieldDecorator('province', {
                                        initialValue: selectRecord ? selectRecord.province : undefined,
                                        rules: [{ required: true, message: '请选择省/州' }]
                                    })(
                                        <Select
                                            placeholder='省/州'
                                            showSearch
                                            style={{ width: 200 }}
                                            optionFilterProp="children"
                                            filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            onChange={(value) => this.onAddressChange(value)}
                                        >
                                            {
                                                edisAddressCodes.filter(item => item.level === 1).map(province => <Option key={province.code} value={province.code}>{province.nameZh}</Option>)
                                            }
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label='城市'>
                                    {getFieldDecorator('city', {
                                        initialValue: selectRecord ? selectRecord.city : undefined,
                                        rules: [{ required: true, message: '请选择城市' }]
                                    })(
                                        <Select
                                            placeholder='城市'
                                            showSearch
                                            style={{ width: 200 }}
                                            optionFilterProp="children"
                                            filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            onChange={(value) => this.onAddressChange(value)}
                                        >
                                            {edisAddressCodes.filter(item => item.level === 2).map(city => <Option key={city.code} value={city.code}>{city.nameZh}</Option>)}
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label='区/县'>
                                    {getFieldDecorator('district', {
                                        initialValue: selectRecord ? selectRecord.district : undefined,
                                        rules: [{ required: true, message: '请选择区/县' }]
                                    })(
                                        <Select
                                            placeholder='区/县'
                                            showSearch
                                            style={{ width: 200 }}
                                            optionFilterProp="children"
                                            filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            onChange={(value) => this.onAddressChange(value)}
                                        >
                                            {edisAddressCodes.filter(item => item.level === 3).map(district => <Option key={district.code} value={district.code}>{district.nameZh}</Option>)}
                                        </Select>
                                    )}
                                </FormItem>
                            </Col>
                        </Row>
                        <FormItem {...formItemLayout} label='街道地址'>
                            {getFieldDecorator('street1', {
                                initialValue: selectRecord ? selectRecord.street1 : undefined,
                                rules: [{ required: true, message: '请填写街道地址' }]
                            })(<Input placeholder="请填写街道地址" />)}
                        </FormItem>
                        <Row >
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="邮政编码">
                                    {getFieldDecorator('postcode', {
                                        initialValue: selectRecord ? selectRecord.postcode : undefined,
                                        rules: [{ required: true, message: '请填写邮政编码' }]
                                    })(<Input placeholder="请填邮政编码" />)}
                                </FormItem>
                            </Col>
                            <Col span={10}>
                                <FormItem {...formItemLayoutTwo} label="电话">
                                    {getFieldDecorator('mobile', {
                                        initialValue: selectRecord ? selectRecord.mobile : undefined,
                                        rules: [{ required: true, message: '请填电话' }]
                                    })(<Input placeholder="请填电话" />)}
                                </FormItem>
                            </Col>
                        </Row>
                    </Form>
                </Modal>
            </div>


        );
    }
} 