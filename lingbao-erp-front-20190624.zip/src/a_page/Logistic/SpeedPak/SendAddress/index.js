import React, {Component} from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import tool from '../../../../a_util/tool';
import {Button, Icon, Modal, Form, Select, Radio, Input, Row, Col, Divider, Tooltip} from 'antd';
import DropoffSitList from '../../../../a_component/DropoffSitsList';
import {getEdisSendAddressList, syncEdisSendAddressList, addEdisSendAddress, actionEdisSendAddress, deleteEdisSendAddress} from '../../../../a_redux/actions/edis-send-address-action';
import {getEdisAddressCodeList} from '../../../../a_redux/actions/edis-address-code-action';
import {getEdisDropoffSiteList} from '../../../../a_redux/actions/edis-dropoff-site-action';
import './index.less';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;

@connect(
    (state) => {
        return {
            edissendaddress: state.edissendaddress,
            edisaddresscode: state.edisaddresscode,
            edisdropoffsite: state.edisdropoffsite,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({
            getEdisSendAddressList,
            addEdisSendAddress,
            syncEdisSendAddressList,
            actionEdisSendAddress,
            deleteEdisSendAddress,
            getEdisAddressCodeList,
            getEdisDropoffSiteList,
        }, dispatch),
    })
)
@Form.create()
export default class SendAddress extends Component {

    state = {
        showAddressModal:false,
        selectRecord:undefined,
    }

    componentDidMount() {
        this.onRefreshEdisSendAddress();
    }

    onRefreshEdisSendAddress = () => {
        this.props.actions.getEdisSendAddressList();
    }

    onDefaultAddress = (edisSendAddress) => {
        this.props.actions.actionEdisSendAddress(tool.clearNull({
            action:'defaultAddress',
            id: edisSendAddress.id,
        })).then(res=>{
            if (res.status === 200) {
                this.onRefreshEdisSendAddress();
            }
        })
    }

    syncSendAddress = () => {
        this.props.actions.syncEdisSendAddressList().then(ret=>{
            if (ret.status === 200) {
                this.onRefreshEdisSendAddress();
            }
        });
    }

    openAddressModal = (record) => {
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            level:0,
        }));
        this.setState({
            showAddressModal:true,
            selectRecord:record,
        })
    }

    commitAddressModal = () => {
        let self = this;
        self.props.form.validateFields([
            'name',
            'type',
            'pickupTime',
            'contact',
            'company',
            'mobile',
            'postcode',
            'countryCode',
            'province',
            'city',
            'district',
            'street1',
            'dropoffSiteId',
        ], (err, values) => {
            console.log(values);
            if (err) {
                return false;
            }
            
            let params = {
                name: values.name,
                type: values.type,
                pickupTime: values.pickupTime,
                contact: values.contact,
                company: values.company,
                mobile: values.mobile,
                postcode: values.postcode,
                countryCode: values.countryCode,
                province: values.province,
                contact: values.contact,
                city: values.city,
                district: values.district,
                street1: values.street1,
                dropoffSiteId: values.dropoffSiteId,
                pickupTime: values.pickupTime,
            }
            console.log(params);
            if (!self.state.selectRecord) {
                self.props.actions.addEdisSendAddress(tool.clearNull(params)).then((res)=>{
                    if (res.status === 200) {
                        self.closeAddressModal();
                        self.onRefreshEdisSendAddress();
                    }
                    
                })
            } else {
                params = {...params, 'id':self.state.selectRecord.id, 'action':'info'}
                self.props.actions.actionEdisSendAddress(tool.clearNull(params)).then(()=>{
                    self.closeAddressModal();
                    self.onRefreshEdisSendAddress();
                });
            }
        });
        
    }

    closeAddressModal = () => {
        this.setState({
            showAddressModal:false,
            selectRecord:undefined,
        })
        this.props.form.resetFields();
    }

    onAddressChange = (parentCode) => {
        console.log(parentCode);
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            parentCode:parentCode
        }));
    }

    onChangeType = () => {
        this.props.actions.getEdisAddressCodeList(tool.clearNull({
            level:0,
        }));
    }

    onDropoffSitChange = (dropoffSiteCity) => {
        let self = this;
        self.props.form.validateFields([
            'dropoffSiteCountry',
            'dropoffSiteProvince',
        ], (err, values) => {
            if (err) {
                return ;
            }
            self.props.actions.getEdisDropoffSiteList(tool.clearNull({
                country: values.dropoffSiteCountry,
                province: values.dropoffSiteProvince,
                city: dropoffSiteCity,
            }))
        })
    }

    render() {
        const {showAddressModal, selectRecord} = this.state;
        const { edisSendAddresses } = this.props.edissendaddress;
        const {edisAddressCodes} = this.props.edisaddresscode;
        const {edisDropoffSites} = this.props.edisdropoffsite;
        const loading = this.props.edissendaddress.loading || this.props.edisaddresscode.loading || this.props.edisaddresscode.loading;
        console.log(edisAddressCodes)
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {span: 3},
            wrapperCol: {span: 17},
        };
        const formItemLayoutTwo = {  // 表单布局
            labelCol: {span:7},
            wrapperCol: {span:15},
        };
        return (
            <div>
                <div>设置用户的发货地址信息以及交运方式，交运方式包括卖家自送和上门揽件</div>
                <div style={{display:'flex'}}>
                    <div style={{paddingRight:'10px'}}>已设置 {<strong>{edisSendAddresses.length}</strong>} 条 交运偏好</div>
                    <Button loading={this.props.edissendaddress.loading} icon="search" onClick={()=>this.onRefreshEdisSendAddress()}>查询</Button>
                    <Divider type='vertical' />
                    <Button loading={this.props.edissendaddress.loading} icon="reload" onClick={()=>this.syncSendAddress()}>同步</Button>
                    <Divider type='vertical' />
                    <Button loading={this.props.edissendaddress.loading} icon="plus" onClick={()=>this.openAddressModal()}>添加</Button>
                </div>
                <div className='addressDiv'>
                {
                    edisSendAddresses.map(edisSendAddress=>{
                        return (
                            <div key={edisSendAddress.consignPreferenceId} className="addressTableDiv">
                                <div className="addressCapation" onClick={()=>this.onDefaultAddress(edisSendAddress)}>
                                    <div className={edisSendAddress.defaultAddress?'addressCapationButtonChoose':'addressCapationButton'}>默认地址</div>
                                </div>
                                <table className="addressTable" >
                                    
                                        {
                                            edisSendAddress.dropoffSiteId ?
                                            <tbody>
                                                <tr>
                                                    <td className='label'>交运方式: </td><td  className='content'>{edisSendAddress.type.name}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>名称: </td><td  className='content'>{edisSendAddress.name}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>联系人姓名: </td><td className='content'>{edisSendAddress.dropoffSiteContact}</td>
                                                </tr>
                                                <tr>
                                                <td className='label'>地址信息: </td><td className='content'>{edisSendAddress.dropoffSiteCountryZh + ' ' + edisSendAddress.dropoffSiteProvinceZh + ' ' + edisSendAddress.dropoffSiteCityZh + ' ' + edisSendAddress.dropoffSiteDistrictZh + ' ' + edisSendAddress.dropoffSiteStreet1}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>手机号码: </td><td className='content'>{edisSendAddress.dropoffSiteMobile}</td>
                                                </tr>
                                            </tbody>
                                            :
                                            <tbody>
                                                <tr>
                                                    <td className='label'>交运方式: </td><td  className='content'>{edisSendAddress.type.name}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>揽件时间: </td><td  className='content'>{edisSendAddress.pickupTime.name}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>名称: </td><td  className='content'>{edisSendAddress.name}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>联系人姓名: </td><td className='content'>{edisSendAddress.contact}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>公司名称: </td><td className='content'>{edisSendAddress.company}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>地址信息: </td><td className='content'>{edisSendAddress.countryZh + ' ' + edisSendAddress.provinceZh + ' ' + edisSendAddress.cityZh + ' ' + edisSendAddress.districtZh + ' ' + edisSendAddress.street1}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>邮政编码: </td><td className='content'>{edisSendAddress.postcode}</td>
                                                </tr>
                                                <tr>
                                                    <td className='label'>手机号码: </td><td className='content'>{edisSendAddress.mobile}</td>
                                                </tr>
                                            </tbody>
                                        }
                                </table>
                                {/* <Divider type='horizontal' />
                                <div style={{textAlign:'right'}}>
                                    <Tooltip placement="topLeft" title={'编辑'}>
                                        <Icon style={{width:60, fontSize:'16px', cursor:'pointer'}} onClick={()=>this.openAddressModal(edisSendAddress)} type='edit'/>
                                    </Tooltip>
                                    <Tooltip placement="topRight" title={'删除'}>
                                        <Icon style={{width:60, fontSize:'16px', cursor:'pointer'}} type='delete' />
                                    </Tooltip>
                                </div> */}
                                
                            </div>
                        );
                    })
                }
                </div>
                <Modal
                    visible={showAddressModal}
                    onOk={this.commitAddressModal.bind(this)}
                    onCancel={this.closeAddressModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    width={800}
                    height={600}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="名称">
                            {getFieldDecorator('name', {
                                initialValue: selectRecord?selectRecord.name:undefined,
                                rules: [{required: true, message: '请填写名称'}]
                            })(<Input placeholder="请填写名称"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="揽收方式">
                            {getFieldDecorator('type', {
                                initialValue: (selectRecord&&selectRecord.type!==undefined)?selectRecord.type.value:0,
                                rules: [{required: true, message: '请选择揽收方式'}]
                            })(
                                <RadioGroup onChange={this.onChangeType.bind(this)} >
                                    <Radio value={0}>上门揽收</Radio>
                                    <Radio value={1}>卖家自送</Radio>
                                </RadioGroup>
                            )}
                        </FormItem>
                        {
                            this.props.form.getFieldValue('type')===0?
                            <div>
                                <Row >
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="联系人">
                                            {getFieldDecorator('contact', {
                                                initialValue: selectRecord?selectRecord.contact:undefined,
                                                rules: [{required: true, message: '请填写联系人'}]
                                            })(<Input placeholder="请填写联系人"/>)}
                                        </FormItem>
                                    </Col>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="公司">
                                            {getFieldDecorator('company', {
                                                initialValue: selectRecord?selectRecord.company:undefined,
                                            })(<Input placeholder="请填写公司"/>)}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row >
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="国家/地区">
                                            {getFieldDecorator('countryCode', {
                                                initialValue: selectRecord?selectRecord.countryCode:undefined,
                                                rules: [{required: true, message: '请选择国家/地区'}]
                                            })(
                                                <Select 
                                                    placeholder='国家/地区' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    onSearch={this.onChangeType.bind(this)}
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===0).map(country => <Option key={country.code} value={country.code}>{country.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="省/州">
                                            {getFieldDecorator('province', {
                                                initialValue: selectRecord?selectRecord.province:undefined,
                                                rules: [{required: true, message: '请选择省/州'}]
                                            })(
                                                <Select 
                                                    placeholder='省/州' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {
                                                        edisAddressCodes.filter(item=>item.level===1).map(province => <Option key={province.code} value={province.code}>{province.nameZh}</Option>)
                                                    }
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label='城市'>
                                            {getFieldDecorator('city', {
                                                initialValue: selectRecord?selectRecord.city:undefined,
                                                rules: [{required: true, message: '请选择城市'}]
                                            })(
                                                <Select 
                                                    placeholder='城市' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===2).map(city => <Option key={city.code} value={city.code}>{city.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label='区/县'>
                                            {getFieldDecorator('district', {
                                                initialValue: selectRecord?selectRecord.district:undefined,
                                                rules: [{required: true, message: '请选择区/县'}]
                                            })(
                                                <Select 
                                                    placeholder='区/县' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===3).map(district => <Option key={district.code} value={district.code}>{district.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <FormItem {...formItemLayout} label='街道地址'> 
                                    {getFieldDecorator('street1', {
                                        initialValue: selectRecord?selectRecord.street1:undefined,
                                        rules: [{required: true, message: '请填写街道地址'}]
                                    })(<Input placeholder="请填写街道地址"/>)}
                                </FormItem>
                                <Row >
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="邮政编码">
                                            {getFieldDecorator('postcode', {
                                                initialValue: selectRecord?selectRecord.postcode:undefined,
                                                rules: [{required: true, message: '请填写邮政编码'}]
                                            })(<Input placeholder="请填邮政编码"/>)}
                                        </FormItem>
                                    </Col>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="电话">
                                            {getFieldDecorator('mobile', {
                                                initialValue: selectRecord?selectRecord.mobile:undefined,
                                                rules: [{required: true, message: '请填电话'}]
                                            })(<Input placeholder="请填电话"/>)}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <FormItem {...formItemLayout} label="揽收时间">
                                    {getFieldDecorator('pickupTime', {
                                        initialValue: (selectRecord&&selectRecord.pickupTime!==undefined)?selectRecord.pickupTime.value:0,
                                        rules: [{required: true, message: '请选择揽收方式'}]
                                    })(
                                        <RadioGroup >
                                            <Radio value={1}>14:00-16:00</Radio>
                                            <Radio value={2}>16:00-18:00</Radio>
                                        </RadioGroup>
                                    )}
                                </FormItem>
                            </div>
                            :
                            <div>
                                <Row >
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="国家/地区">
                                            {getFieldDecorator('dropoffSiteCountry', {
                                                initialValue: selectRecord?selectRecord.dropoffSiteCountry:undefined,
                                                rules: [{required: true, message: '请选择国家/地区'}]
                                            })(
                                                <Select 
                                                    placeholder='国家/地区' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onSearch={this.onChangeType.bind(this)}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===0).map(country => <Option key={country.code} value={country.code}>{country.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label="省/州">
                                            {getFieldDecorator('dropoffSiteProvince', {
                                                initialValue: selectRecord?selectRecord.dropoffSiteProvince:undefined,
                                                rules: [{required: true, message: '请选择省/州'}]
                                            })(
                                                <Select 
                                                    placeholder='省/州' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onAddressChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===1).map(province => <Option key={province.code} value={province.code}>{province.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={10}>
                                        <FormItem {...formItemLayoutTwo} label='城市'>
                                            {getFieldDecorator('dropoffSiteCity', {
                                                initialValue: selectRecord?selectRecord.dropoffSiteCity:undefined,
                                                rules: [{required: true, message: '请选择城市'}]
                                            })(
                                                <Select 
                                                    placeholder='城市' 
                                                    showSearch
                                                    style={{ width: 200 }} 
                                                    optionFilterProp="children"
                                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                                    onChange={(value)=>this.onDropoffSitChange(value)}
                                                >
                                                    {edisAddressCodes.filter(item=>item.level===2).map(city => <Option key={city.code} value={city.code}>{city.nameZh}</Option>)}
                                                </Select>
                                            )}
                                        </FormItem>
                                    </Col>
                                </Row>
                                <FormItem {...formItemLayout} label='自送点'>
                                    {getFieldDecorator('dropoffSiteId', {
                                        initialValue: selectRecord?selectRecord.dropoffSiteId:undefined,
                                        rules: [{required: true, message: '请选择站点'}]
                                    })(
                                        <DropoffSitList dropoffSits={edisDropoffSites} />
                                    )}
                                </FormItem>
                            </div>
                            
                        }
                        
                    </Form>
                </Modal>
            </div>
        );
    }
} 