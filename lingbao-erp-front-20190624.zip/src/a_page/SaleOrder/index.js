import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal} from 'antd';
import tool from '../../a_util/tool';
import {getSaleOrderList, getSaleOrderDetail, syncSaleOrder} from '../../a_redux/actions/saleOrder-action';
import {getCountryList} from '../../a_redux/actions/country-action';
import {getPlatformList} from '../../a_redux/actions/platform-action';

const Option = Select.Option;

import './index.less';

@connect(
	(state) => {
        return {
		saleOrder: state.saleOrder, 
        country: state.country,
        platform: state.platform,
	}},
	(dispatch) => ({
		actions: bindActionCreators({ getSaleOrderList, getSaleOrderDetail, syncSaleOrder, getCountryList, getPlatformList}, dispatch),
	})
)



export default class SaleOrder extends React.Component {

	state = {
		platform: undefined,
		country: undefined,
		fulfillmentState: undefined,
		paymentState: undefined,
		cancelState: undefined,
		platformSeller:undefined,
		platformOrderId: undefined,
		platformBuyer: undefined,
        selectRecord: undefined,
		selectRecordDetail:[],
		saleOrderDetailModalShow: false,
		pageData: [],
        pageTotal:0,
        pageSize: 10,
        pageNum:1,
	}

	componentDidMount() {
		this.onRefreshSaleOrder();
        if (this.props.country.countries.length<1) {
            this.props.actions.getCountryList();
        }
        if (this.props.platform.platforms.length<1) {
            this.props.actions.getPlatformList();
        }
    }

    onRefreshSaleOrder = (pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        let self = this;
        let params = {
            pageSize,
            pageNum: pageNum,
            platform: self.state.platform,
            country: self.state.country,
			fulfillmentState: self.state.fulfillmentState,
			paymentState: self.state.paymentState,
			cancelState: self.state.cancelState,
			sellerId: self.state.platformSeller,
			platformOrderId: self.state.platformOrderId,
			identifier: self.state.platformBuyer,
        }
        self.props.actions.getSaleOrderList(tool.clearNull(params)).then(res=>{
            if (res.status === 200) {
                self.setState({
                    pageSize,
                    pageNum,
                    pageData: res.data.body.rows,
                    pageTotal: res.data.body.total,
                })
            }
        })
    }

    makeColumnsData = (data) => {
        const {pageNum, pageSize} = this.state;
        return data.map((item,index)=>{
            return {
                serial: (index + 1) + (pageNum-1) * pageSize,
                key: item.id,
                id: item.id,
				platform: item.platform,
				platformSeller: item.platformSellerId,
				platformBuyer: item.identifier,
				country: item.country,
				platformOrderId: item.platformOrderId,
				amount: item.amount,
				currency: item.currency,
				fullFillmentState: item.fullFillmentState,
				paymentStatus: item.paymentStatus,
				cancelState: item.cancelState,
				createTime: item.createTime,
            };
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '平台',
            dataIndex: 'platform',
            key: 'platform',      
		},
		{
            title: '卖家',
            dataIndex: 'platformSeller',
            key: 'platformSeller',      
        },
        {
            title: '买家',
            dataIndex: 'platformBuyer',
            key: 'platformBuyer',      
        },
        {
            title: '国家',
            dataIndex: 'country',
            key: 'country',
        },
        {
            title: '订单ID',
            dataIndex: 'platformOrderId',
            key: 'platformOrderId',      
		},
		{
            title: '金额',
            dataIndex: 'amount',
			key: 'amount',      
			render: (text, record) => {
				return record.amount + " "+record.currency
			}
		},
		{
            title: '交易状态',
            dataIndex: 'cancelState',
            key: 'cancelState',      
        },
        {
            title: '支付状态',
            dataIndex: 'paymentStatus',
            key: 'paymentStatus',      
		},
		{
            title: '交付状态',
            dataIndex: 'fullFillmentState',
            key: 'fullFillmentState',      
        },
		{
            title: '创建时间',
            dataIndex: 'createTime',
            key: 'createTime',      
        }
	];
	
	makePlatformSelect = (platforms) => {
        return platforms.map(platform=>{
            return <Option key={platform.name} value={platform.name}>{platform.name}</Option>
        })
    }

    onPlatormSelect = (platform) => {
        this.setState({
            platform: platform,
        })
    }

    makeCountrySelect = (countries) => {
        return countries.map(country=>{
            return <Option key={country.name} value={country.name}>{country.country+" ["+country.name+"]"}</Option>
        })
    }

    onCountrySelect = (country) => {
        this.setState({
            country: country,
        })
	}
	
	onCancelStateSelect = (state) => {
		this.setState({
            cancelState: state,
        })
	}

	onFulfillmentStateSelect = (state) => {
		this.setState({
            fulfillmentState: state,
        })
	}

	onPaymentStateSelect = (state) => {
		this.setState({
            paymentState: state,
        })
	}

	searchPlatformOrderIdChange = (e) => {
		this.setState({
			platformOrderId: e.target.value
		})
	}

	searchPlatformSellerChange = (e) => {
		this.setState({
			platformSeller: e.target.value
		})
	}

	searchPlatfromBuyerChange = (e) => {
		this.setState({
			platformBuyer: e.target.value
		})
	} 

	onSearchSaleOrder = () => {
        this.onRefreshSaleOrder(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshSaleOrder(pageNum, pageSize);
    }

    openSaleOrderDetailModal = (record) => {
        this.setState({
            saleOrderDetailModalShow: true,
            selectRecord: record,
        })
        let self = this;
        let params = {
            id: record.id
        }
        self.props.actions.getSaleOrderDetail(tool.clearNull(params)).then(res=>{
            if (res.status === 200) {
                self.setState({
                    selectRecordDetail: res.data.body,
                })
            }
        })
    }

    saleOrderDetailModalCommit = () => {
        this.saleOrderDetailModalClose();
    }

    saleOrderDetailModalClose = () => {
        this.setState({
            saleOrderDetailModalShow: false,
            selectRecord: undefined,
            selectRecordDetail:[]
        })
    }

	onSyncSaleOrder = () => {
		this.props.actions.syncSaleOrder()
	}

	onShowImageModal = (image) => {
        this.setState({
            showImage: image,
            showImageModal: true,
        })
    }

    closeImageModal = () => {
        this.setState({
            showImage: undefined,
            showImageModal: false,
        })
    }
	


	render() {
		const {countries} = this.props.country;
        const {platforms} = this.props.platform;
        const loading = this.props.saleOrder.loading || this.props.country.loading || this.props.platform.loading;
        const {showImage, showImageModal, pageTotal, pageNum, pageSize, pageData, saleOrderDetailModalShow, selectRecord, selectRecordDetail, platformOrderId, platformSeller, platformBuyer} = this.state;
		return 	<div>
					<div className="g-search">
						<ul className="search-ul">
							<li>
								<Select placeholder="选择平台" allowClear style={{width: '250px'}} onChange={this.onPlatormSelect.bind(this)}>
									{this.makePlatformSelect(platforms)}
								</Select>
							</li>
							<li>
								<Select showSearch OptionFilterProp="children" placeholder="选择国家" allowClear style={{width: '350px'}} onChange={this.onCountrySelect.bind(this)}>
									{this.makeCountrySelect(countries)}
								</Select>
							</li>
						</ul>
					</div>
					<div className="g-search">
						<ul className="search-ul">
							<li>
								<Select placeholder="交易状态" allowClear style={{width: '250px'}} onChange={this.onCancelStateSelect.bind(this)}>
									<Option value="NONE_REQUESTED">正常</Option>
									<Option value="IN_PROGRESS">取消中</Option>
									<Option value="CANCELED">已取消</Option>
								</Select>
							</li>
							<li>
								<Select placeholder="支付状态" allowClear style={{width: '250px'}} onChange={this.onPaymentStateSelect.bind(this)}>
									<Option value="FAILED">付款失败</Option>
									<Option value="FULLY_REFUNDED">退全款</Option>
									<Option value="PARTIALLY_REFUNDED">部分退款</Option>
									<Option value="PAID">已付款</Option>
									<Option value="PENDING">付款中</Option>
								</Select>
							</li>
							<li>
								<Select placeholder="交付状态" allowClear style={{width: '250px'}} onChange={this.onFulfillmentStateSelect.bind(this)}>
									<Option value="FULFILLED">已交付</Option>
									<Option value="IN_PROGRESS">交付中</Option>
									<Option value="NOT_STARTED">未交付</Option>
								</Select>
							</li>
						</ul>
					</div>
					<div className="g-search">
						<ul className="search-ul">
							<li><Input style={{width: '250px'}} placeholder="订单号" onChange={(e) => this.searchPlatformOrderIdChange(e)} value={platformOrderId}/></li> 
							<li><Input style={{width: '250px'}} placeholder="卖家" onChange={(e) => this.searchPlatformSellerChange(e)} value={platformSeller}/></li> 
							<li><Input style={{width: '250px'}} placeholder="买家" onChange={(e) => this.searchPlatfromBuyerChange(e)} value={platformBuyer}/></li> 
							<li><Button icon="search" onClick={this.onSearchSaleOrder.bind(this)}>查询</Button></li>
							<li><Button icon="reload" onClick={this.onSyncSaleOrder.bind(this)}>同步</Button></li>
						</ul>
					</div>
					<Table 
						bordered
						loading={loading}
						dataSource={this.makeColumnsData(pageData)} 
						columns={this.columns} 
						rowClassName="pointer"
						onRow={(record) => {
							return {
								onClick: () => this.openSaleOrderDetailModal(record),       // 点击行
							};
						}}
						pagination={{
							total: pageTotal,
							current: pageNum,
							pageSize: pageSize,
							showQuickJumper: true,
							showTotal: (total, range) => `共 ${total} 条数据`,
							onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
						}}
					/>
					<Modal
						visible={saleOrderDetailModalShow}
						onOk={this.saleOrderDetailModalCommit.bind(this)}
						onCancel={this.saleOrderDetailModalClose.bind(this)}
						okText="确认"
						cancelText="取消"
						confirmLoading={loading}
						width={800}
						height={1200}
					>
						<div style={{ border: '1px solid #D2E9FF', margin: '30px' }}>
							<span className="title">订单信息</span>
							<table style={{marginLeft:'15px'}}>
								<tbody style={{paddingLeft:'10px'}}>
									<tr>
										<td style={{width:'200px'}}>平台: {selectRecord?selectRecord.platform:undefined}</td>
										<td style={{width:'200px'}}>卖家: {selectRecord?selectRecord.platformSeller:undefined}</td>
									</tr>
									<tr>
										<td style={{width:'250px'}}>国家: {selectRecord?selectRecord.country:undefined}</td>
										<td colSpan={2}>买家: {selectRecord?selectRecord.platformBuyer:undefined}</td>
									</tr>
									<tr>
										<td colSpan={3}>订单号: {selectRecord?selectRecord.platformOrderId:undefined}</td>
									</tr>
									<tr>
										<td style={{width:'250px'}}>金额: {selectRecord?selectRecord.amount+" "+selectRecord.currency:undefined}</td>
										<td style={{width:'250px'}}>创建时间: {selectRecord?selectRecord.createTime:undefined}</td>
									</tr>
									<tr>
										<td style={{width:'250px'}}>交易状态: {selectRecord?selectRecord.cancelState:undefined}</td>
										<td style={{width:'250px'}}>支付状态: {selectRecord?selectRecord.paymentStatus:undefined}</td>
										<td style={{width:'250px'}}>交付状态: {selectRecord?selectRecord.fullFillmentState:undefined}</td>
									</tr>
								</tbody>
							</table>
							{
								selectRecordDetail.length>0 && selectRecordDetail.map((item, index)=>{
									return <div key={index} style={{ border: '1px solid #D2E9FF', margin: '10px' }}>
												<span className="title">商品信息</span>
												<table>
													<tbody>
														<tr>
															<td>
															{
																(item.images && Array.isArray(item.images) && item.images.length>0) &&
																<img className='image' src={item.images[0].path} onClick={()=>this.onShowImageModal(item.images[0])} title={item.images[0].name+' ['+tool.fileSize(item.images[0].size)+']'}/>
															}
															</td>
															<td>
																<table key={item.id} style={{ margin: '10px' }}>
																	<tbody style={{ paddingLeft: '10px' }}>
																		<tr>
																			<td colSpan={3}>标题: {item ? item.title : undefined}</td>
																		</tr>
																		<tr>
																			<td style={{ width: '250px' }}>SKU: {item ? item.sku : undefined} </td>
																			<td style={{ width: '400px' }}>物品编号: {item ? item.legacyItemId : undefined}</td>
																		</tr>
																		<tr>
																			<td colSpan={3}>交易号: {item ? item.transactionId : undefined}</td>
																		</tr>
																		<tr>
																			<td style={{ width: '500px' }}>总价格: {item ? (item.price + ' ' + item.currency) : undefined}</td>
																			<td style={{ width: '250px' }}>数量: {item ? item.quality : undefined}</td>
																			<td style={{ width: '500px' }}>销售类型: {item ? item.type : undefined}</td>
																		</tr>
																		<tr>
																			<td style={{ width: '250px' }}>刊登市场: {item ? item.listMarket : undefined}</td>
																			<td style={{ width: '250px' }}>销售市场: {item ? item.purchaseMarket : undefined}</td>
																			<td style={{ width: '250px' }}>交付状态: {item ? item.lineItemFulfillmentStatus : undefined}</td>
																		</tr>
																	</tbody>
																</table>
															</td>
														</tr>
													</tbody>
												</table>
											</div>
								})
							}
						</div>
					</Modal>
					<Modal
						visible={showImageModal}
						onOk={this.closeImageModal.bind(this)}
						onCancel={this.closeImageModal.bind(this)}
						okText="确认"
						cancelText="取消"
						confirmLoading={loading}
						height={400}
						width={800}
					>
						<center>
							<img style={{height:'400px', width:'auto'}} src={showImage&&showImage.path} title={showImage&&showImage.name}></img>
						</center>
					</Modal>
				</div>
	}

} 