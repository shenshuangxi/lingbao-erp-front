import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal, Radio, Form, Divider, Icon, Upload} from 'antd';
import tool from '../../a_util/tool';
import { enumsCountry} from '../../a_redux/actions/enums-action';
import {listProducts, addProduct, actionProduct, deleteProduct} from '../../a_redux/actions/product-action';
import SelectImage from '../../a_component/SeleteImage';
import {baseUrl, fileUrl} from '../../config/config-url';
import './product.less';
const TextArea = Input.TextArea;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;

@connect(
	(state) => {
        return {
        enums: state.enums,
        product: state.product, 
	}},
	(dispatch) => ({
		actions: bindActionCreators({enumsCountry, listProducts, addProduct, actionProduct, deleteProduct}, dispatch),
	})
)
@Form.create()
export default class ProductPage extends React.Component {

    state = {
        searchName:undefined,
        searchSku:undefined,
        selectRecord: undefined,
        productFileList: [],
    }

    componentDidMount() {
        this.onRefreshProduct();
    }

    onRefreshProduct = (pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        if (!this.props.enums.enums.country) {
            this.props.actions.enumsCountry();
        }
        let self = this;
        let params = {
            pageNum,
            pageSize,
            name: self.state.searchName,
            sku: self.state.searchSku,
        }
        this.props.actions.listProducts(tool.clearNull(params));
    }

    searchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        });
    } 

    searchSkuChange = (e) => {
        this.setState({
            searchSku: e.target.value,
        });
    } 


    onSearchProduct = () => {
        this.onRefreshProduct(1);
    }

    
    onChangePage = (pageNum, pageSize) => {
        this.onRefreshProduct(pageNum, pageSize);
    }

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.product.pageNum - 1) * this.props.product.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                name: item.name,
                cnName: item.cnName,
                enName: item.enName,
                images: item.images,
                original: item.original,
                batteryType: item.batteryType,
                skuAlias: item.skuAlias,
                description: item.description,
                createTime: item.createTime,
            };
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className:'table',
        },
        {
            title: '首图',
            dataIndex: 'image',
            key: 'image',
            className:'table',
            render:(text, record) => {
                if (record.images.length>0) {
                    let dispFileSize = tool.fileSize(record.images[0].size);
                    return <img className='image' onClick={()=>this.onShowImageModal(record.images[0])} src={record.images[0].path} title={record.images[0].name+' ['+dispFileSize+']'}></img>
                } else {
                    return "";
                }
            }
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className:'table',
        },
        {
            title: 'sku别名',
            dataIndex: 'skuAlias',
            key: 'skuAlias',
            className:'table',
            render: (text, record) => {
                return record.skuAlias && record.skuAlias.join(', ')
            }
        },
        {
            title: '名称',
            dataIndex: 'name',
            key: 'name',
            className:'table',
        },
        {
            title: '中文名',
            dataIndex: 'cnName',
            key: 'cnName',
            className:'table',
        },
        {
            title: '英文名',
            dataIndex: 'enName',
            key: 'enName',
            className:'table',
        },
        {
            title: '带电',
            dataIndex: 'batteryType',
            key: 'batteryType',
            className:'table',
            render:(text, record) => {
                return record.batteryType.name;
            }
        },
        {
            title: '原产地',
            dataIndex: 'original',
            key: 'original',
            className:'table',
            render:(text, record) => {
                return record.original.name+' ['+record.original.value+']';
            }
        },
        {
            title: '描述',
            dataIndex: 'description',
            key: 'description',
            className:'table',
        },
        {
            title: '操作',
            key: 'operation',
            className:'table',
            render: (text, record) => {
                return <div>
                        <span className="control-btn red" onClick={this.openProductModal.bind(this, record)}>
                            <a>编辑</a>
                        </span>
                        <Divider type='vertical' />
                        <span className="control-btn red" onClick={this.openProductImageModal.bind(this, record)}>
                            <a>图片</a>
                        </span>
                        <Divider type='vertical' />
                        <span className="control-btn red" onClick={this.onDelete.bind(this, record)}>
                            <a>删除</a>
                        </span>
                    </div>
            }
        }
    ];

    onShowImageModal = (image) => {
        this.setState({
            showImage: image,
            showImageModal: true,
        })
    }

    closeImageModal = () => {
        this.setState({
            showImage: undefined,
            showImageModal: false,
        })
    }

    openProductImageModal = (record) => {
        this.setState({
            selectRecord: record,
            showSelectImageModal: true,
        })
    }

    commitSelectImageModal = () => {
        let self = this;
        let params = {images:self.state.selectImageComponent.state.selectImages, 'id':self.state.selectRecord.id, 'action':'image'}
        self.props.actions.actionProduct(tool.clearNull(params)).then(()=>{
            self.closeSelectImageModal();
            self.onRefreshProduct();
        });
    }

    closeSelectImageModal = () => {
        this.setState({
            selectRecord: undefined,
            showSelectImageModal: false,
        })
    }

    

    onDelete = (record) => {
        let self = this;
        self.props.actions.deleteProduct(tool.clearNull({'id': record.id})).then(()=>{
            self.onRefreshProduct();
        });
    }

    openProductModal = (record) => {
        this.setState({
            selectRecord: record,
            showProductModal: true,
        })
    }

    commitProductModal = () => {
        let self = this;
        self.props.form.validateFields([
            'sku',
            'name',
            'enName',
            'cnName',
            'skuAlias',
            'batteryType',
            'original',
            'description',
        ], (err, values) => {
            if (err) {
                return false;
            }
            let params = {
                sku: values.sku,
                skuAlias: values.skuAlias,
                name: values.name,
                enName: values.enName,
                cnName: values.cnName,
                batteryType: values.batteryType,
                original: values.original,
                description: values.description,
            }
            console.log(params);
            if (!self.state.selectRecord) {
                self.props.actions.addProduct(tool.clearNull(params)).then(()=>{
                    self.closeProductModal();
                    self.onRefreshProduct();
                })
            } else {
                params = {...params, 'id':self.state.selectRecord.id, 'action':'info'}
                self.props.actions.actionProduct(tool.clearNull(params)).then(()=>{
                    self.closeProductModal();
                    self.onRefreshProduct();
                });
            }
        });
    }

    closeProductModal = () => {
        this.setState({
            selectRecord: undefined,
            showProductModal: false,
        });
        this.props.form.resetFields();
    }

    onSelectImageRef = (component) => {
        this.setState({
            selectImageComponent: component,
        })
    }

    openProductUploadModel = () => {
        this.setState({
            showProductUploadModel: true
        })
    }

    closeProductUploadModel = () => {
        this.setState({
            showProductUploadModel: false
        })
    }

    handleProductFileChange = (info) => {
        let productFileList = info.fileList;
        this.setState({ productFileList });
    }

    onLoadProductTemplate = () => {
        let aTag = document.createElement('a');
        aTag.href= fileUrl+'/template/product.xlsx',
        document.body.appendChild(aTag);
        aTag.click();
        document.body.removeChild(aTag)
    }

    makeCountrySelect = (countries) => {
        if (!countries) {
            return [];
        }
        return countries.map((item, index) => {
            return <Option key={index} value={item.name}>{item.country + ' [' + item.name + ']'}</Option>
        })
    }

    render() {
        const {searchName, searchSku, showProductModal, selectRecord, showSelectImageModal, productFileList, showProductUploadModel, showImage, showImageModal} = this.state;
        const {loading, pageNum, pageSize, pageTotal, productData} = this.props.product;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            },
        };
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="产品名称" onChange={(e) => this.searchNameChange(e)} value={searchName}/></li> 
                        <li><Input placeholder="产品sku" onChange={(e) => this.searchSkuChange(e)} value={searchSku}/></li> 
                        <li><Button icon="search" onClick={this.onSearchProduct.bind(this)}>查询</Button></li>
                        <li><Button icon="plus" onClick={()=>this.openProductModal()}>添加</Button></li>
                        <li><Button icon="upload" onClick={this.openProductUploadModel.bind(this)}>excel</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    rowClassName='table'
                    dataSource={this.makeColumnsData(productData)} 
                    columns={this.columns} 
                    expandedRowRender={(rowData)=>{
                        let images = [];
                        if (rowData.images.length>0) {
                            images = rowData.images.map(image=>{
                                let dispFileSize = tool.fileSize(image.size);
                                return <img key={image.id} className='image' onClick={()=>this.onShowImageModal(image)} src={image.path} title={image.name+' ['+dispFileSize+']'}/>
                            })
                        }
                        return (
                            <div style={{ display: 'flex', flexFlow: 'row wrap' }}>
                            {
                                images
                            }
                            </div>
                        )
                    }}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal
                    visible={showProductModal}
                    onOk={this.commitProductModal.bind(this)}
                    onCancel={this.closeProductModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    height={600}
                    width={600}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="sku">
                            {getFieldDecorator('sku', {
                                initialValue: selectRecord?selectRecord.sku:undefined,
                                rules: [{required: true, message: '请填写sku'}]
                            })(<Input placeholder="请填写sku"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="sku别名">
                            {getFieldDecorator('skuAlias', {
                                initialValue: selectRecord?selectRecord.skuAlias:undefined,
                            })(
                                <Select
                                    placeholder="请输入sku别名"
                                    mode="tags"
                                    style={{ width: '100%' }}
                                    tokenSeparators={[',']}
                                >
                                </Select>
                            )}
                        </FormItem>
                        <FormItem {...formItemLayout} label="名称">
                            {getFieldDecorator('name', {
                                initialValue: selectRecord?selectRecord.name:undefined,
                                rules: [{required: true, message: '请填写产品名称'}]
                            })(<Input placeholder="请填写产品名称"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="中文名称">
                            {getFieldDecorator('cnName', {
                                initialValue: selectRecord?selectRecord.cnName:undefined,
                                rules: [{required: true, message: '请填写产品中文名称'}]
                            })(<Input placeholder="请填写产品中文名称"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="英文名称">
                            {getFieldDecorator('enName', {
                                initialValue: selectRecord?selectRecord.enName:undefined,
                                rules: [{required: true, message: '请填写产品英文名称'}]
                            })(<Input placeholder="请填写产品英文名称"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="带电类型">
                            {getFieldDecorator('batteryType', {
                                initialValue: selectRecord?selectRecord.batteryType.value:undefined,
                                rules: [{required: true, message: '请填写产品英文名称'}]
                            })(<RadioGroup options={[{ label: '无电', value: 0 },{ label: '内置', value: 1 },{ label: '纯电', value: 2 },{ label: '带电', value: 3 },]} />)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="原产地">
                            {getFieldDecorator('original', {
                                initialValue: selectRecord?selectRecord.original.value:undefined,
                                rules: [{required: true, message: ''}]
                            })(
                                <Select showSearch OptionFilterProp="children" size='small' style={{ width: '400px' }} placeholder="选择国家" allowClear  >
                                    {this.makeCountrySelect(this.props.enums.enums.country)}
                                </Select>
                            )}
                        </FormItem>
                        
                        <FormItem {...formItemLayout} label="描述">
                            {getFieldDecorator('description', {
                                initialValue: selectRecord?selectRecord.description:undefined,
                            })(<TextArea rows={3} placeholder="请填描述"/>)}
                        </FormItem>
                    </Form>
                </Modal>
                <Modal
                    destroyOnClose
                    visible={showSelectImageModal}
                    onOk={this.commitSelectImageModal.bind(this)}
                    onCancel={this.closeSelectImageModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    height={1000}
                    width={1200}
                    footer={null}
                >
                    <div style={{textAlign:'right', paddingRight:'30px'}}><Button loading={loading} onClick={this.commitSelectImageModal.bind(this)}>确认</Button></div>
                    <SelectImage images={selectRecord?selectRecord.images:[]} onRef={this.onSelectImageRef.bind(this)} />
                </Modal>
                <Modal
                    visible={showImageModal}
                    onOk={this.closeImageModal.bind(this)}
                    onCancel={this.closeImageModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    footer={null}
                    confirmLoading={loading}
                    height={400}
                    width={800}
                    
                >
                    <center>
                        <img style={{height:'400px', width:'auto'}} src={showImage&&showImage.path} title={showImage&&showImage.name}></img>
                    </center>
                </Modal>
                <Modal
                     visible={showProductUploadModel}
                     onOk={this.closeProductUploadModel.bind(this)}
                     onCancel={this.closeProductUploadModel.bind(this)}
                     okText="确认"
                     cancelText="取消"
                     confirmLoading={loading}
                     height={600}
                     width={400}
                >
                        <Button onClick={this.onLoadProductTemplate.bind(this)}><Icon type="download" />下载模板</Button>
                        <Divider type='horizontal' />
                        <Upload {...{
                            action: baseUrl+'/v1/product',
                            method:'post',
                            onChange: this.handleProductFileChange,
                            multiple: true,
                            accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            name:'productExcel'
                        }} fileList={productFileList}>
                            <Button>
                                <Icon type="upload" /> 上传
                            </Button>
                        </Upload>
                </Modal>
            </div>
        );
    }

}