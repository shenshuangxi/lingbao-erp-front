import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal, Form, Divider} from 'antd';
import tool from '../../a_util/tool';
import {listSuppliers, addSupplier, actionSupplier, deleteSupplier} from '../../a_redux/actions/supplier-action';
import './index.less';
const TextArea = Input.TextArea;
const FormItem = Form.Item;

@connect(
	(state) => {
        return {
        enums: state.enums,
        supplier: state.supplier, 
	}},
	(dispatch) => ({
		actions: bindActionCreators({ listSuppliers, addSupplier, actionSupplier, deleteSupplier}, dispatch),
	})
)
@Form.create()
export default class SupplierPage extends React.Component {

    state = {
        searchName:undefined,
        selectRecord: undefined,
    }

    componentDidMount() {
        this.onRefreshSupplier();
    }

    onRefreshSupplier = (pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            name: self.state.searchName,
        }
        this.props.actions.listSuppliers(tool.clearNull(params));
    }

    searchNameChange = (e) => {
        this.setState({
            searchName: e.target.value,
        });
    } 

    onSearchSupplier = () => {
        this.onRefreshSupplier(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshSupplier(pageNum, pageSize);
    }

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.supplier.pageNum - 1) * this.props.supplier.pageSize,
                key: item.id,
                id: item.id,
                name: item.name,
                email: item.email,
                address: item.address,
                phone: item.phone,
                url: item.url,
                createTime: item.createTime,
            };
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className:'table',
        },
        {
            title: '名称',
            dataIndex: 'name',
            key: 'name',
            className:'table',
        },
        {
            title: '电话',
            dataIndex: 'phone',
            key: 'phone',
            className:'table',
        },
        {
            title: '邮件地址',
            dataIndex: 'email',
            key: 'email',
            className:'table',
        },
        {
            title: '地址',
            dataIndex: 'address',
            key: 'address',
            className:'table',
        },
        {
            title: '网址',
            dataIndex: 'url',
            key: 'url',
            className:'table',
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className:'table',
        },
        {
            title: '操作',
            key: 'operation',
            className:'table',
            render: (text, record) => {
                return <div>
                        <span className="control-btn red" onClick={this.openSupplierModal.bind(this, record)}>
                            <a>编辑</a>
                        </span>
                        <Divider type='vertical' />
                        <span className="control-btn red" onClick={this.onDelete.bind(this, record)}>
                            <a>删除</a>
                        </span>
                    </div>
            }
        }
    ];

    onDelete = (record) => {
        let params = {
            'id': record.id, 
        }
        self.props.actions.deleteSupplier(tool.clearNull(params)).then(()=>{
            self.onRefreshSupplier();
        });
    }

    openSupplierModal = (record) => {
        this.setState({
            selectRecord: record,
            showSupplierModal: true,
        })
    }

    commitSupplierModal = () => {
        let self = this;
        self.props.form.validateFields([
            'name',
            'email',
            'address',
            'phone',
            'url',
        ], (err, values) => {
            if (err) {
                return false;
            }
            let params = {
                name: values.name,
                email: values.email,
                address: values.address,
                phone: values.phone,
                url: values.url,
            }
            if (!self.state.selectRecord) {
                self.props.actions.addSupplier(tool.clearNull(params)).then(()=>{
                    self.closeSupplierModal();
                    self.onRefreshSupplier();
                })
            } else {
                params = {...params, 'id':self.state.selectRecord.id, 'action':'info'}
                self.props.actions.actionSupplier(tool.clearNull(params)).then(()=>{
                    self.closeSupplierModal();
                    self.onRefreshSupplier();
                });
            }
        });
    }

    closeSupplierModal = () => {
        this.setState({
            selectRecord: undefined,
            showSupplierModal: false,
        });
        this.props.form.resetFields();
    }

    render() {
        const {searchName, showSupplierModal, selectRecord} = this.state;
        const {loading, pageNum, pageSize, pageTotal, supplierData} = this.props.supplier;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            },
        };
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="产品名称" onChange={(e) => this.searchNameChange(e)} value={searchName}/></li> 
                        <li><Button icon="search" onClick={this.onSearchSupplier.bind(this)}>查询</Button></li>
                        <li><Button icon="plus" onClick={()=>this.openSupplierModal()}>添加</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    rowClassName='table'
                    dataSource={this.makeColumnsData(supplierData)} 
                    columns={this.columns} 
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal
                    visible={showSupplierModal}
                    onOk={this.commitSupplierModal.bind(this)}
                    onCancel={this.closeSupplierModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    height={600}
                    width={600}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="名称">
                            {getFieldDecorator('name', {
                                initialValue: selectRecord?selectRecord.name:undefined,
                                rules: [{required: true, message: '请填写供应商名称'}]
                            })(<Input placeholder="请填写供应商名称"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="电话">
                            {getFieldDecorator('phone', {
                                initialValue: selectRecord?selectRecord.phone:undefined,
                            })(<Input placeholder="请填写供应商电话"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="电子邮件">
                            {getFieldDecorator('email', {
                                initialValue: selectRecord?selectRecord.email:undefined,
                            })(<Input placeholder="请填写电子邮件地址"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="地址">
                            {getFieldDecorator('address', {
                                initialValue: selectRecord?selectRecord.address:undefined,
                            })(<Input placeholder="请填写地址"/>)}
                        </FormItem>
                        <FormItem {...formItemLayout} label="网址">
                            {getFieldDecorator('url', {
                                initialValue: selectRecord?selectRecord.url:undefined,
                            })(<Input placeholder="请填写网址"/>)}
                        </FormItem>
                    </Form>
                </Modal>
            </div>
        );
    }

}