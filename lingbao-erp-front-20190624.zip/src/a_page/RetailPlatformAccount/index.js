import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Icon, Button, Input, Modal, Form, Divider} from 'antd';
import tool from '../../a_util/tool';
import {getRetailPlatformAccountList, refreshToken, addAccount, actionAccount } from '../../a_redux/actions/retailPlatformAccount-action';

const FormItem = Form.Item;

@connect(
	(state) => ({
		retailPlatformAccount: state.retailPlatformAccount, 
	}),
	(dispatch) => ({
		actions: bindActionCreators({ getRetailPlatformAccountList, refreshToken, addAccount, actionAccount }, dispatch),
	})
)

@Form.create()
export default class RetailPlatformAccount extends React.Component {


    state = {
        accountModalShow: false,
        searchAccount: undefined,
        selectRecord: undefined,
        pageSize: 10,
        pageNum:0,
    }

    componentDidMount() {
        this.onRefreshRetailPlatformAccount();
    }

    onRefreshRetailPlatformAccount = (pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        let self = this;
        self.props.actions.getRetailPlatformAccountList(tool.clearNull({
            pageSize,
            pageNum,
            account: self.state.searchAccount,
        })).then((isSuccess)=>{
            if (isSuccess) {
                self.setState({
                    pageSize,
                    pageNum
                });
            }
        })
    }


    onChangePage = (pageNum, pageSize) => {
        this.onRefreshRetailPlatformAccount(pageNum, pageSize);
    }

    searchAccountChange = (e) => {
        this.setState({
            searchAccount: e.target.value,
        })
    }

    onSearchAccount = () => {
        this.onRefreshRetailPlatformAccount();
    }

    


    makeColumnsData = (data) => {
        const {pageNum, pageSize} = this.state;
        return data.map((item,index)=>{
            return {
                key: item.id,
                id: item.id,
                serial: (index + 1) + (pageNum) * pageSize,
                account: item.account,
                accessToken: item.accessToken,
                accessTokenEndTime: item.accessTokenEndTime,
                refreshToken: item.refreshToken,
                refreshTokenEndTime: item.refreshTokenEndTime,
                createTime: item.createTime,
            };
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '账号',
            dataIndex: 'account',
            key: 'account',      
        },
        {
            title: '刷新token截至日期',
            dataIndex: 'refreshTokenEndTime',
            key: 'refreshTokenEndTime',      
        },
        {
            title: '访问token截止日期',
            dataIndex: 'accessTokenEndTime',
            key: 'accessTokenEndTime',      
        },
        {
            title: '状态',
            dataIndex: 'statusName',
            key: 'statusName',
            render: (text, record) => {
                if (new Date(record.refreshTokenEndTime) > new Date()) {
                    return "有效";
                } else {
                    return "无效"
                }
            }
        },
        {
            title: '创建日期',
            dataIndex: 'createTime',
            key: 'createTime',      
        },
        {
            title: '操作', 
            key: 'operation',  
            render: (text, record) => {
                return  <span>
                            <span className="control-btn red" onClick={this.refreshToken.bind(this, record)}>
                                <a>刷新token</a><Icon type="edit"/>
                            </span>
                            <Divider type="vertical"></Divider>
                            <span className="control-btn red" onClick={this.openEditAccountModal.bind(this, record)}>
                                <a>编辑</a><Icon type="edit"/>
                            </span>
                            <Divider type="vertical"></Divider>
                            <span className="control-btn red" onClick={this.deleteAccount.bind(this, record)}>
                                <a>删除</a><Icon type="edit"/>
                            </span>
                        </span>
                
            }
        }
    ];

    deleteAccount = (record) => {
        let self = this;
        let params = {'id':record.id, 'action':'delete'}
        self.props.actions.actionAccount(tool.clearNull(params)).then(()=>{
            self.accountModalClose();
            self.onRefreshRetailPlatformAccount();
        });
    }

    refreshToken = (record) => {
        let redirectUrl = document.location.toString();
        this.props.actions.refreshToken({
            id: record.id,
            redirectUrl: redirectUrl,
        }).then(refreshTokenUrl=>{
            window.location.href= refreshTokenUrl;
        });
    }

    
    openEditAccountModal = (record) => {
        this.setState({
            accountModalShow: true,
            selectRecord: record,
        });
    }

    openAddAccountModal = () => {
        this.setState({
            accountModalShow: true
        });
    }

    accountModalCommit = () => {
        let self = this;
        self.props.form.validateFields([
            'account',
        ], (err, values) => {
            if (err) {
                return false;
            }
            let params = {
                account: values.account,
            }
            if (!self.state.selectRecord) {
                self.props.actions.addAccount(tool.clearNull(params)).then(()=>{
                    self.accountModalClose();
                    self.onRefreshRetailPlatformAccount();
                })
            } else {
                params = {...params, 'id':self.state.selectRecord.id, 'action':'info'}
                self.props.actions.actionAccount(tool.clearNull(params)).then(()=>{
                    self.accountModalClose();
                    self.onRefreshRetailPlatformAccount();
                });
            }
        });
    }

    accountModalClose = () => {
        this.setState({
            accountModalShow: false,
            selectRecord: undefined,
        });
        this.props.form.resetFields();
    }
    

    render() {
        const {pageSize, pageNum, pageTotal, pageData, loading} = this.props.retailPlatformAccount;
        const {accountModalShow, searchAccount, selectRecord } = this.state;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            },
        };
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="账号" onChange={(e) => this.searchAccountChange(e)} value={searchAccount}/></li> 
                        <li><Button icon="search" onClick={this.onSearchAccount.bind(this)}>查询</Button></li>
                        <li><Button icon="edit" onClick={this.openAddAccountModal.bind(this)}>添加</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(pageData)} 
                    columns={this.columns} 
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal
                    visible={accountModalShow}
                    onOk={this.accountModalCommit.bind(this)}
                    onCancel={this.accountModalClose.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                >
                    <Form>
                        <FormItem {...formItemLayout} label="账号">
                            {getFieldDecorator('account', {
                                initialValue: selectRecord?selectRecord.account:undefined,
                                rules: [{required: true, message: '请填写账号'}]
                            })(<Input placeholder="电商平台账号"/>)}
                        </FormItem>
                    </Form>
                </Modal>
            </div>
            
        )
    }

}