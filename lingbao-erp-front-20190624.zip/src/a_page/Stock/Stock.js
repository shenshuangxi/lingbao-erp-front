import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {Route,Switch} from 'react-router-dom';
import { Table, Button, Input, Select, Modal, Form, Divider, Row, Col, InputNumber } from 'antd';
import SelectModal from '../../a_component/SelectModal';
import tool from '../../a_util/tool';
import './index.less';
import { listStocks,  deleteStock } from '../../a_redux/actions/stock-action';
import { listProducts } from '../../a_redux/actions/product-action';
import { listSuppliers } from '../../a_redux/actions/supplier-action';
const Option = Select.Option;
const TextArea = Input.TextArea;
const FormItem = Form.Item;

@connect(
    (state) => {
        return {
            enums: state.enums,
            stock: state.stock,
            product: state.product,
            supplier: state.supplier,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ listProducts, listSuppliers, listStocks,  deleteStock }, dispatch),
    })
)
@Form.create()
export default class StockPage extends React.Component {

    constructor(props) {
        super(props);
        this.originData = props.history.location.state?props.history.location.state:{};
        console.log(this.originData)
        this.state = {
            searchSku: this.originData.sku,
            searchNumber: this.originData.number,
            searchStockInOrderNumber: this.originData.stockInOrderNumber,
        }
    }

    componentDidMount() {
        this.onRefreshStock();
    }

    onRefreshStock = (pageNum = this.props.stock.pageNum, pageSize = this.props.stock.pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            sku: self.state.searchSku,
            number: self.state.searchNumber,
            stockInOrderNumber: self.state.searchStockInOrderNumber,
        }
        this.props.actions.listStocks(tool.clearNull(params));
    }

    searchSkuChange = (e) => {
        this.setState({
            searchSku: e.target.value,
        });
    }


    searchNumberChange = (e) => {
        this.setState({
            searchNumber: e.target.value,
        });
    }

    searchStockInOrderNumberChange = (e) => {
        this.setState({
            searchStockInOrderNumber: e.target.value,
        });
    }


    onSearch = () => {
        this.onRefreshStock(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshStock(pageNum, pageSize);
    }

    stockColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className: 'table',
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
        },
        {
            title: '编号',
            dataIndex: 'number',
            key: 'number',
            className: 'table',
        },
        {
            title: '入库编号',
            dataIndex: 'stockInOrderNumber',
            key: 'stockInOrderNumber',
            className: 'table',
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className: 'table',
        },
        {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            className: 'table',
            render: (text, record) => {
                return record.status && record.status.name
            }
        },
        {
            title: '操作',
            key: 'operation',
            className: 'table',
            render: (text, record) => {
                return <div>
                    <span className="control-btn red" onClick={()=>this.onHandleRoute('stockaction', record)}>
                        <a>详情</a>
                    </span>
                    <Divider type='vertical' />
                    <span className="control-btn red" onClick={this.onDelete.bind(this, record)}>
                        <a>删除</a>
                    </span>
                </div>
            }
        }
    ];

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.stock.pageNum - 1) * this.props.stock.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                number: item.number,
                stockInOrderNumber: item.stockInOrderNumber,
                status: item.status,
                createTime: item.createTime,
            };
        })
    }

    onDelete = (record) => {
        let self = this;
        let params = {
            'id': record.id,
        }
        self.props.actions.deleteStock(tool.clearNull(params)).then(() => {
            self.onRefreshStock();
        });
    }


    onHandleRoute = (route, params) => {
        this.props.history.push('/stock-manager/'+route, {...params, stockNumber:params.number});
    }

    render() {
        const { searchSku, searchNumber, searchStockInOrderNumber } = this.state;
        const { pageNum, pageSize, pageTotal, stockData } = this.props.stock;
        console.log(this.props.stock)
        const loading = this.props.stock.loading || this.props.product.loading || this.props.supplier.loading;
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="sku" onChange={(e) => this.searchSkuChange(e)} value={searchSku} /></li>
                        <li><Input placeholder="入库编号" onChange={(e) => this.searchStockInOrderNumberChange(e)} value={searchStockInOrderNumber} /></li>
                        <li><Input placeholder="编号" onChange={(e) => this.searchNumberChange(e)} value={searchNumber} /></li>
                        <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                    </ul>
                </div>
                <Table
                    bordered
                    rowClassName="table"
                    loading={loading}
                    dataSource={this.makeColumnsData(stockData)}
                    columns={this.stockColumns}
                    expandedRowRender={(rowData) => {
                        return (
                            <Table
                                columns={this.stockNestColumns}
                                dataSource={[rowData]}
                                pagination={false}
                            />
                        );
                    }}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        );
    }
}