import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {Route,Switch} from 'react-router-dom';
import { Table, Button, Input, Form, Divider, message } from 'antd';
import tool from '../../a_util/tool';
import './index.less';
import { listStockActions } from '../../a_redux/actions/stockaction-action';

@connect(
    (state) => {
        return {
            enums: state.enums,
            stockAction: state.stockAction,
            product: state.product,
            supplier: state.supplier,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ listStockActions }, dispatch),
    })
)
@Form.create()
export default class StockAction extends React.Component {

    constructor(props) {
        super(props);
        this.originData = props.history.location.state?props.history.location.state:{};
        console.log(this.originData)
        this.state = {
            searchStockNumber: this.originData.stockNumber,
        }
    }

    componentDidMount() {
        if (this.state.searchStockNumber) {
            this.onRefreshStockAction();
        }
    }

    onRefreshStockAction = (pageNum = this.props.stockAction.pageNum, pageSize = this.props.stockAction.pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            stockNumber: self.state.searchStockNumber,
        }
        this.props.actions.listStockActions(tool.clearNull(params));
    }


    searchStockNumberChange = (e) => {
        this.setState({
            searchStockNumber: e.target.value,
        });
    }


    onSearch = () => {
        this.onRefreshStockAction(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshStockAction(pageNum, pageSize);
    }

    stockColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className: 'table',
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
        },
        {
            title: '编号',
            dataIndex: 'stockNumber',
            key: 'stockNumber',
            className: 'table',
        },
        {
            title: '金额',
            dataIndex: 'amount',
            key: 'amount',
            className: 'table',
            render: (text, record) => {
                if (record.status.value === -1) {
                    return 0.0;
                } else if (record.status.value === 0) {
                    return record.inPrice + " "+ record.inPriceCurrency
                } else if (record.status.value === 1) {
                    return record.salePrice + " "+ record.salePriceCurrency
                }  else if (record.status.value === 2) {
                    return record.refund + " "+ record.refundCurrency
                }
            }
        },
        {
            title: '物流费用',
            dataIndex: 'logistic',
            key: 'logistic',
            className: 'table',
            render: (text, record) => {
                if (record.status.value === -1) {
                    return record.returnLogisticFee + " "+ record.returnLogisticFeeCurrency
                } else if (record.status.value === 0) {
                    return 0.0;
                } else if (record.status.value === 1) {
                    return record.saleLogisticFee + " "+ record.saleLogisticFeeCurrency
                }  else if (record.status.value === 2) {
                    return 0.0;
                }
            }
        },
        {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            className: 'table',
            render: (text, record) => {
                return record.status && record.status.name
            }
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className: 'table',
        },
        {
            title: '操作',
            key: 'operation',
            className: 'table',
            render: (text, record) => {
                return <div>
                    <span className="control-btn red" onClick={()=>message.info("功能待完善")}>
                        <a>详情</a>
                    </span>
                </div>
            }
        }
    ];

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.stockAction.pageNum - 1) * this.props.stockAction.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                stockInOrderNumber: item.stockInOrderNumber,
                stockNumber: item.stockNumber,
                logisticOrderNo: item.logisticOrderNo,
                saleOrderNo: item.saleOrderNo,

                inPrice: item.inPrice,
                inPriceCurrency: item.inPriceCurrency,
                refund: item.refund,
                refundCurrency: item.refundCurrency,
                returnLogisticFee: item.returnLogisticFee,
                returnLogisticFeeCurrency: item.returnLogisticFeeCurrency,
                saleLogisticFee: item.saleLogisticFee,
                saleLogisticFeeCurrency: item.saleLogisticFeeCurrency,
                salePrice: item.salePrice,
                salePriceCurrency: item.salePriceCurrency,
                status: item.status,
                createTime: item.createTime,
            };
        })
    }

    stockActionNestColumns = [
        {
            title: '入库编号',
            dataIndex: 'stockInOrderNumber',
            key: 'stockInOrderNumber',
            className: 'table',
        },
        {
            title: '物流单号',
            dataIndex: 'logisticOrderNo',
            key: 'logisticOrderNo',
            className: 'table',
        },
        {
            title: '销售单号',
            dataIndex: 'saleOrderNo',
            key: 'saleOrderNo',
            className: 'table',
        },
    ];


    render() {
        const { searchStockNumber } = this.state;
        const { pageNum, pageSize, pageTotal, stockActionData } = this.props.stockAction;
        const loading = this.props.stockAction.loading || this.props.product.loading || this.props.supplier.loading;
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="编号" onChange={(e) => this.searchStockNumberChange(e)} value={searchStockNumber} /></li>
                        <li><Button icon="search" onClick={this.onSearch.bind(this)}>查询</Button></li>
                    </ul>
                </div>
                <Table
                    bordered
                    rowClassName="table"
                    loading={loading}
                    dataSource={this.makeColumnsData(stockActionData)}
                    columns={this.stockColumns}
                    expandedRowRender={(rowData) => {
                        return (
                            <Table
                                columns={this.stockActionNestColumns}
                                dataSource={[rowData]}
                                pagination={false}
                            />
                        );
                    }}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        );
    }
}