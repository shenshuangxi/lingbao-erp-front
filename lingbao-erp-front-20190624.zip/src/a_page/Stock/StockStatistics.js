import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Table, Button, Input, Select, Modal, Form, Divider } from 'antd';
import tool from '../../a_util/tool';
import './index.less';
import { listStockStatistics } from '../../a_redux/actions/stockstatistics-action';

@connect(
    (state) => {
        return {
            enums: state.enums,
            stockStatistics: state.stockStatistics,
            product: state.product,
            supplier: state.supplier,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ listStockStatistics }, dispatch),
    })
)
@Form.create()
export default class StockStatistics extends React.Component {
    state = {
        searchSku: undefined,
    }

    componentDidMount() {
        console.log(this.props.stockStatistics)
        this.onRefreshStockStatistics();
        
    }

    onRefreshStockStatistics = (pageNum = this.props.stockStatistics.pageNum, pageSize = this.props.stockStatistics.pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            sku: self.state.searchSku,
        }
        this.props.actions.listStockStatistics(tool.clearNull(params));
    }



    stockColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className: 'table',
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
        },
        {
            title: '入库数量',
            dataIndex: 'inStockQuality',
            key: 'inStockQuality',
            className: 'table',
        },
        {
            title: '出库数量',
            dataIndex: 'outStockQuality',
            key: 'outStockQuality',
            className: 'table',
        },
        {
            title: '退货数量',
            dataIndex: 'returnStockQuality',
            key: 'returnStockQuality',
            className: 'table',
        },
        {
            title: '退款数量',
            dataIndex: 'refundStockQuality',
            key: 'refundStockQuality',
            className: 'table',
        },
        {
            title: '操作',
            key: 'operation',
            className: 'table',
            render: (text, record) => {
                return <div>
                    <span className="control-btn red" onClick={()=>this.onHandleRoute('stock', record)}>
                        <a>详情</a>
                    </span>
                </div>
            }
        }
    ];

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.stockStatistics.pageNum - 1) * this.props.stockStatistics.pageSize,
                key: (index + 1) + (this.props.stockStatistics.pageNum - 1) * this.props.stockStatistics.pageSize,
                sku: item.sku,
                inStockQuality: item.inStockQuality,
                outStockQuality: item.outStockQuality,
                returnStockQuality: item.returnStockQuality,
                refundStockQuality: item.refundStockQuality,
            };
        })
    }

    onHandleRoute = (route, params) => {
        this.props.history.push('/stock-manager/'+route, params);
    }
    

    onSearchStock = () => {
        this.onRefreshStockStatistics(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshStockStatistics(pageNum, pageSize);
    }

    searchSkuChange = (e) => {
        this.setState({
            searchSku: e.target.value,
        });
    }

    handRoute = (route, record) => {
        this.props.history.push('/stock-manager/'+route, record);
    }

    render() {
        const { searchSku } = this.state;
        console.log(this.props)
        console.log(this.state)
        const { pageNum, pageSize, pageTotal, stockStatisticsData } = this.props.stockStatistics;
        const loading = this.props.stockStatistics.loading || this.props.product.loading || this.props.supplier.loading;
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="sku" onChange={(e) => this.searchSkuChange(e)} value={searchSku} /></li>
                        <li><Button icon="search" onClick={this.onSearchStock.bind(this)}>查询</Button></li>
                    </ul>
                </div>
                <Table
                    bordered
                    rowClassName="table"
                    loading={loading}
                    dataSource={this.makeColumnsData(stockStatisticsData)}
                    columns={this.stockColumns}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
            </div>
        );
    }
}