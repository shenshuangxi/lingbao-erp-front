import React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Table, Button, Input, Select, Modal, Form, Divider, Row, Col, InputNumber, Upload, Icon } from 'antd';
import SelectModal from '../../a_component/SelectModal';
import tool from '../../a_util/tool';
import './index.less';
import { listStockInOrders, addStockInOrder, actionStockInOrder, deleteStockInOrder } from '../../a_redux/actions/stockInOrder-action';
import { listProducts } from '../../a_redux/actions/product-action';
import { listSuppliers } from '../../a_redux/actions/supplier-action';
import {baseUrl, fileUrl} from '../../config/config-url';
const FormItem = Form.Item;

@connect(
    (state) => {
        return {
            enums: state.enums,
            stockInOrder: state.stockInOrder,
            product: state.product,
            supplier: state.supplier,
        }
    },
    (dispatch) => ({
        actions: bindActionCreators({ listProducts, listSuppliers, listStockInOrders, addStockInOrder, actionStockInOrder, deleteStockInOrder }, dispatch),
    })
)
@Form.create()
export default class StockPage extends React.Component {
    
    state = {
        searchSku: undefined,
        searchNumber: undefined,
        stockInOrderFileList: [],
    }

    componentDidMount() {
        this.onRefreshStockInOrder();
    }

    onRefreshStockInOrder = (pageNum = this.props.stockInOrder.pageNum, pageSize = this.props.stockInOrder.pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            sku: self.state.searchSku,
            number: self.state.searchNumber,
        }
        this.props.actions.listStockInOrders(tool.clearNull(params));
    }

    searchSkuChange = (e) => {
        this.setState({
            searchSku: e.target.value,
        });
    }


    searchNumberChange = (e) => {
        this.setState({
            searchNumber: e.target.value,
        });
    }


    onSearchStockInOrder = () => {
        this.onRefreshStockInOrder(1);
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshStockInOrder(pageNum, pageSize);
    }

    makeColumnsData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.stockInOrder.pageNum - 1) * this.props.stockInOrder.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                productName: item.productName,
                supplierId: item.supplierId,
                supplierName: item.supplierName,
                productUrl: item.productUrl,
                price: item.price,
                weight: item.weight,
                length: item.length?item.length:0,
                width: item.width?item.width:0,
                height: item.height?item.height:0,
                number: item.number,
                quality: item.quality,
                createTime: item.createTime,
            };
        })
    }

    stockNestColumns = [
        {
            title: '产品名称',
            dataIndex: 'productName',
            key: 'productName',
            className: 'table',
        },
        {
            title: '供应商名称',
            dataIndex: 'supplierName',
            key: 'supplierName',
            className: 'table',
        },
        {
            title: '供应商产品链接',
            dataIndex: 'productUrl',
            key: 'productUrl',
            className: 'table',
        },
    ];

    stockColumns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',
            className: 'table',
        },
        {
            title: 'sku',
            dataIndex: 'sku',
            key: 'sku',
            className: 'table',
        },
        {
            title: '入库编号',
            dataIndex: 'number',
            key: 'number',
            className: 'table',
        },
        {
            title: '价格',
            dataIndex: 'price',
            key: 'price',
            className: 'table',
        },
        {
            title: '重量(g)',
            dataIndex: 'weight',
            key: 'weight',
            className: 'table',
        },
        {
            title: '长*宽*高(cm)',
            dataIndex: 'v',
            key: 'v',
            className: 'table',
            render: (text, record) => {
                return record.length + '*' + record.width + '*' + record.height
            }
        },
        {
            title: '数量',
            dataIndex: 'quality',
            key: 'quality',
            className: 'table',
        },
        {
            title: '日期',
            dataIndex: 'createTime',
            key: 'createTime',
            className: 'table',
        },
        {
            title: '操作',
            key: 'operation',
            className: 'table',
            render: (text, record) => {
                return <div>
                    <span className="control-btn red" onClick={this.openStockModal.bind(this, record)}>
                        <a>编辑</a>
                    </span>
                    <Divider type='vertical' />
                    <span className="control-btn red" onClick={()=>this.onHandleRoute('stock', record)}>
                        <a>详情</a>
                    </span>
                    <Divider type='vertical' />
                    <span className="control-btn red" onClick={this.onDelete.bind(this, record)}>
                        <a>删除</a>
                    </span>
                </div>
            }
        }
    ];

    


    openStockModal = (record) => {
        this.setState({
            selectRecord: record,
            showStockModal: true,
        })
    }

    commitStockInOrderModal = () => {
        let self = this;
        self.props.form.validateFields([
            'sku',
            'quality',
            'productName',
            'supplierName',
            'productUrl',
            'price',
            'weight',
            'length',
            'width',
            'height',
        ], (err, values) => {
            if (err) {
                return false;
            }

            let params = {
                sku: self.state.selectProduct ? self.state.selectProduct.sku : self.state.selectRecord.sku,
                supplierId: self.state.selectSupplier ? self.state.selectSupplier.id : self.state.selectRecord?self.state.selectRecord.supplierId:undefined,
                productUrl: values.productUrl,
                price: values.price,
                weight: values.weight,
                length: values.length,
                width: values.width,
                height: values.height,
                quality: values.quality,
            }
            if (!self.state.selectRecord) {
                self.props.actions.addStockInOrder(tool.clearNull(params)).then(() => {
                    self.closeStockModal();
                    self.onRefreshStockInOrder();
                })
            } else {
                params = { ...params, 'id': self.state.selectRecord.id, 'action': 'info' }
                self.props.actions.actionStockInOrder(tool.clearNull(params)).then(() => {
                    self.closeStockModal();
                    self.onRefreshStockInOrder();
                });
            }
        });
    }

    closeStockModal = () => {
        this.setState({
            selectRecord: undefined,
            selectProduct: undefined,
            selectSupplier: undefined,
            showStockModal: false,
            showProductModal: false,
            showSupplierModal: false,
        });
        this.props.form.resetFields();
    }

    onDelete = (record) => {
        let self = this;
        let params = {
            'id': record.id,
        }
        self.props.actions.deleteStockInOrder(tool.clearNull(params)).then(() => {
            self.onRefreshStockInOrder();
        });
    }

    makeProductData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.product.pageNum - 1) * this.props.product.pageSize,
                key: item.id,
                id: item.id,
                sku: item.sku,
                name: item.name,
                cnName: item.cnName,
                enName: item.enName,
                description: item.description,
                createTime: item.createTime,
            };
        })
    }

    makeProductColumns = () => {
        return [
            {
                title: '序号',
                dataIndex: 'serial',
                key: 'serial',
            },
            {
                title: 'sku',
                dataIndex: 'sku',
                key: 'sku',
            },
            {
                title: '名称',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: '中文名',
                dataIndex: 'cnName',
                key: 'cnName',
            },
            {
                title: '英文名',
                dataIndex: 'enName',
                key: 'enName',
            },
            {
                title: '描述',
                dataIndex: 'description',
                key: 'description',
            },
            {
                title: '日期',
                dataIndex: 'createTime',
                key: 'createTime',
            }
        ];
    }

    onSelectProductOk = (products) => {
        if (products.length < 1) {
            message.error("请选择一条数据");
            return;
        }
        this.setState({
            selectProduct: products[0],
        });
        this.props.form.setFieldsValue({ "sku": products[0].sku });
        this.onSelectModalCancel();
    }


    onSearchProduct = () => {
        this.onSelectProductPageChange(1, this.props.product.pageSize);
    }

    onSelectProductPageChange = (pageNum, pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            name: self.state.searchSelectModalProductName,
            sku: self.state.searchSelectModalProductSku,
        }
        this.props.actions.listProducts(tool.clearNull(params));
    }

    searchSelectModalProductNameChange = (e) => {
        this.setState({
            searchSelectModalProductName: e.target.value,
        })
    }

    searchSelectModalProductSkuChange = (e) => {
        this.setState({
            searchSelectModalProductSku: e.target.value,
        })
    }



    searchProductComponents = () => {
        let self = this;
        let components = [
            <Input key={1} placeholder="产品名称" onChange={(e) => this.searchSelectModalProductNameChange(e)} value={self.state.searchSelectModalProductName} />,
            <Input key={2} placeholder="产品SKU" onChange={(e) => this.searchSelectModalProductSkuChange(e)} value={self.state.searchSelectModalProductSku} />,
        ];
        return components;
    }


    makeSupplierData = (data) => {
        return data.map((item, index) => {
            return {
                serial: (index + 1) + (this.props.supplier.pageNum - 1) * this.props.supplier.pageSize,
                key: item.id,
                id: item.id,
                name: item.name,
                email: item.email,
                address: item.address,
                phone: item.phone,
                createTime: item.createTime,
            };
        })
    }

    makeSupplierColumns = () => {
        return [
            {
                title: '序号',
                dataIndex: 'serial',
                key: 'serial',
            },
            {
                title: '名称',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: '电话',
                dataIndex: 'phone',
                key: 'phone',
            },
            {
                title: '邮件地址',
                dataIndex: 'email',
                key: 'email',
            },
            {
                title: '地址',
                dataIndex: 'address',
                key: 'address',
            },
            {
                title: '日期',
                dataIndex: 'createTime',
                key: 'createTime',
            }
        ];
    }

    onSelectSupplierOk = (suppliers) => {
        if (suppliers.length < 1) {
            message.error("请选择一条数据");
            return;
        }
        this.setState({
            selectSupplier: suppliers[0],
        })
        this.props.form.setFieldsValue({ "supplier": suppliers[0].name });
        this.onSelectModalCancel();
    }

    onSearchSupplier = () => {
        this.onSelectSupplierPageChange(1, this.props.supplier.pageSize);
    }

    onSelectSupplierPageChange = (pageNum, pageSize) => {
        let self = this;
        let params = {
            pageNum,
            pageSize,
            name: self.state.searchSelectModalSupplierName,
        }
        this.props.actions.listSuppliers(tool.clearNull(params));
    }

    searchSelectModalSupplierNameChange = (e) => {
        this.setState({
            searchSelectModalSupplierName: e.target.value,
        })
    }

    searchSupplierComponents = () => {
        let self = this;
        let components = [
            <Input key={1} placeholder="供应商名称" onChange={(e) => this.searchSelectModalSupplierNameChange(e)} value={self.state.searchSelectModalSupplierName} />,
        ];
        return components;
    }



    onSelectModalCancel = () => {
        this.setState({
            showProductModal: false,
            showSupplierModal: false,
            searchSelectModalProductName: undefined,
            searchSelectModalProductSku: undefined,
            searchSelectModalSupplierName: undefined,
        })
    }

    openSelectProductModal = () => {
        this.onSearchProduct();
        this.setState({
            showProductModal: true,
        })
    }

    openSelectSupplierModal = () => {
        this.onSearchSupplier();
        this.setState({
            showSupplierModal: true,
        })
    }

    onHandleRoute = (route, params) => {
        this.props.history.push('/stock-manager/'+route, {...params,'stockInOrderNumber': params.number, 'number':undefined});
    }

    openStockInOrderUploadModel = () => {
        this.setState({
            showStockInOrderUploadModel: true
        })
    }

    closeStockInOrderUploadModel = () => {
        this.setState({
            showStockInOrderUploadModel: false
        })
    }

    handleStockInOrderFileChange = (info) => {
        let stockInOrderFileList = info.fileList;
        this.setState({ stockInOrderFileList });
    }

    onLoadStockInOrderTemplate = () => {
        let aTag = document.createElement('a');
        aTag.href= fileUrl+'/template/stockIn.xlsx',
        document.body.appendChild(aTag);
        aTag.click();
        document.body.removeChild(aTag)
    }
    

    render() {
        const { searchSku, showSupplierModal, showProductModal, searchNumber, showStockModal, selectRecord, stockInOrderFileList, showStockInOrderUploadModel } = this.state;
        const { pageNum, pageSize, pageTotal, stockInOrderData } = this.props.stockInOrder;
        console.log(this.props.stockInOrder)
        const loading = this.props.stockInOrder.loading || this.props.product.loading || this.props.supplier.loading;
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {  // 表单布局
            labelCol: {
                xs: { span: 6 },
                sm: { span: 6 },
            },
            wrapperCol: {
                xs: { span: 18 },
                sm: { span: 18 },
            },
        };
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li><Input placeholder="sku" onChange={(e) => this.searchSkuChange(e)} value={searchSku} /></li>
                        <li><Input placeholder="库存编号" onChange={(e) => this.searchNumberChange(e)} value={searchNumber} /></li>
                        <li><Button icon="search" onClick={this.onSearchStockInOrder.bind(this)}>查询</Button></li>
                        <li><Button icon="plus" onClick={() => this.openStockModal()}>添加</Button></li>
                        <li><Button icon="upload" onClick={this.openStockInOrderUploadModel.bind(this)}>excel</Button></li>
                    </ul>
                </div>
                <Table
                    bordered
                    rowClassName="table"
                    loading={loading}
                    dataSource={this.makeColumnsData(stockInOrderData)}
                    columns={this.stockColumns}
                    expandedRowRender={(rowData) => {
                        return (
                            <Table
                                columns={this.stockNestColumns}
                                dataSource={[rowData]}
                                pagination={false}
                            />
                        );
                    }}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onShowSizeChange: (pageNum, pageSize) => this.onChangePage(1, pageSize),
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />

                <Modal
                    visible={showStockModal}
                    onOk={this.commitStockInOrderModal.bind(this)}
                    onCancel={this.closeStockModal.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    height={600}
                    width={1000}
                >
                    <Form>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="产品">
                                    {getFieldDecorator('sku', {
                                        initialValue: selectRecord ? selectRecord.sku : undefined,
                                        rules: [{ required: true, message: '请选择产品' }]
                                    })(<Input disabled={!!selectRecord}  onClick={this.openSelectProductModal.bind(this)} placeholder="请选择产品" />)}
                                </FormItem>
                            </Col>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="供应商">
                                    {getFieldDecorator('supplier', {
                                        initialValue: selectRecord ? selectRecord.supplierName : undefined,
                                        rules: [{ required: false, message: '请选择供应商' }]
                                    })(<Input  onClick={this.openSelectSupplierModal.bind(this)} placeholder="请选择供应商" />)}
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="产品链接">
                                    {getFieldDecorator('productUrl', {
                                        initialValue: selectRecord ? selectRecord.productUrl : undefined,
                                    })(<Input style={{width:400}} placeholder="请填写产品链接" />)}
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="入库数量">
                                    {getFieldDecorator('quality', {
                                        initialValue: selectRecord ? selectRecord.quality : undefined,
                                        rules: [{ required: true, message: '请填写产品入库数量' }]
                                    })(<InputNumber disabled={!!selectRecord} style={{width:180}} placeholder="请填写产品入库数量" />)}
                                </FormItem>
                            </Col>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="价格">
                                    {getFieldDecorator('price', {
                                        initialValue: selectRecord ? selectRecord.price : undefined,
                                        rules: [{ required: true, message: '请填写产品价格' }]
                                    })(<InputNumber style={{width:180}} step={0.1} placeholder="请填写产品价格" />)}
                                </FormItem>
                            </Col>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="重量(g)">
                                    {getFieldDecorator('weight', {
                                        initialValue: selectRecord ? selectRecord.weight : undefined,
                                        rules: [{ required: true, message: '请填写产品重量' }]
                                    })(<InputNumber style={{width:180}} placeholder="请填写产品重量" />)}
                                </FormItem>
                            </Col>
                        </Row>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="长度(cm)">
                                    {getFieldDecorator('length', {
                                        initialValue: selectRecord ? selectRecord.length : undefined,
                                    })(<InputNumber style={{width:180}} placeholder="请填写产品长度" />)}
                                </FormItem>
                            </Col>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="宽度(cm)">
                                    {getFieldDecorator('width', {
                                        initialValue: selectRecord ? selectRecord.width : undefined,
                                    })(<InputNumber style={{width:180}} placeholder="请填写产品宽度" />)}
                                </FormItem>
                            </Col>
                            <Col span={8}>
                                <FormItem {...formItemLayout} label="高度(cm)">
                                    {getFieldDecorator('height', {
                                        initialValue: selectRecord ? selectRecord.height : undefined,
                                    })(<InputNumber style={{width:180}} placeholder="请填写产品高度" />)}
                                </FormItem>
                            </Col>
                        </Row>
                    </Form>
                </Modal>
                <SelectModal
                    visible={showProductModal}
                    title="选择产品"
                    loading={loading}
                    columns={this.makeProductColumns()}
                    dataSource={this.makeProductData(this.props.product.productData)}
                    onSelectOk={this.onSelectProductOk.bind(this)}
                    onSelectCancel={this.onSelectModalCancel.bind(this)}
                    onPageChange={this.onSelectProductPageChange.bind(this)}
                    searchComponents={this.searchProductComponents()}
                    onSearch={this.onSearchProduct.bind(this)}
                    pageTotal={this.props.product.pageTotal}
                    pageSize={this.props.product.pageSize}
                    pageNum={this.props.product.pageNum}
                    type={'radio'}
                />
                <SelectModal
                    visible={showSupplierModal}
                    title="选择供应商"
                    loading={loading}
                    columns={this.makeSupplierColumns()}
                    dataSource={this.makeSupplierData(this.props.supplier.supplierData)}
                    onSelectOk={this.onSelectSupplierOk.bind(this)}
                    onSelectCancel={this.onSelectModalCancel.bind(this)}
                    onPageChange={this.onSelectSupplierPageChange.bind(this)}
                    searchComponents={this.searchSupplierComponents()}
                    onSearch={this.onSearchSupplier.bind(this)}
                    pageTotal={this.props.supplier.pageTotal}
                    pageSize={this.props.supplier.pageSize}
                    pageNum={this.props.supplier.pageNum}
                    type={'radio'}
                />
                <Modal
                     visible={showStockInOrderUploadModel}
                     onOk={this.closeStockInOrderUploadModel.bind(this)}
                     onCancel={this.closeStockInOrderUploadModel.bind(this)}
                     okText="确认"
                     cancelText="取消"
                     confirmLoading={loading}
                     height={600}
                     width={400}
                >
                        <Button onClick={this.onLoadStockInOrderTemplate.bind(this)}><Icon type="download" />下载模板</Button>
                        <Divider type='horizontal' />
                        <Upload {...{
                            action: baseUrl+'/v1/stockinorder',
                            method:'post',
                            onChange: this.handleStockInOrderFileChange,
                            multiple: true,
                            accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            name:'stockExcel'
                        }} fileList={stockInOrderFileList}>
                            <Button>
                                <Icon type="upload" /> 上传
                            </Button>
                        </Upload>
                </Modal>
            </div>
        );
    }
}