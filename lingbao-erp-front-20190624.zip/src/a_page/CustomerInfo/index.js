import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {Table, Button, Input, Select, Modal} from 'antd';
import tool from '../../a_util/tool';
import {enumsCountry, enumsPlatform, enumsLogistic, enumsDispatchType} from '../../a_redux/actions/enums-action';
import {getConsumerInfoList, getConsumerInfoDetail} from '../../a_redux/actions/consumerInfo-action';
import {getRetailPlatformAccountList} from '../../a_redux/actions/retailPlatformAccount-action';

const Option = Select.Option;

import './index.less';

@connect(
	(state) => {
        return {
        enums: state.enums,
        retailPlatformAccount: state.retailPlatformAccount,
        consumerInfo: state.consumerInfo, 
	}},
	(dispatch) => ({
		actions: bindActionCreators({ getRetailPlatformAccountList, getConsumerInfoList, getConsumerInfoDetail, enumsCountry, enumsPlatform, enumsLogistic, enumsDispatchType}, dispatch),
	})
)
export default class CustomerInfo extends React.Component {

    state = {
        platform: undefined,
        country: undefined,
        selectRecord: undefined,
        selectRecordDetail:[],
        name: undefined,
        pageData: [],
        pageTotal:0,
        pageSize: 10,
        pageNum:1,
    }

    componentDidMount() {
        this.onRefreshBasicData();
        this.onRefreshConsumerInfo();
    }

    onRefreshBasicData = () => {
        if (this.props.retailPlatformAccount.pageData.length<1) {
            this.props.actions.getRetailPlatformAccountList();
        }
        if (!this.props.enums.enums.logistic) {
            this.props.actions.enumsLogistic();
        }
        if (!this.props.enums.enums.platfrom) {
            this.props.actions.enumsPlatform();
        }
        if (!this.props.enums.enums.country) {
            this.props.actions.enumsCountry();
		}
    }

    onRefreshConsumerInfo = (pageNum=this.state.pageNum, pageSize=this.state.pageSize) => {
        let self = this;
        let params = {
            pageSize,
            pageNum: pageNum-1,
            platform: self.state.platform,
            country: self.state.country,
            name: self.state.name,
        }
        self.props.actions.getConsumerInfoList(tool.clearNull(params)).then(res=>{
            if (res.status === 200) {
                self.setState({
                    pageSize,
                    pageNum,
                    pageData: res.data.body.rows,
                    pageTotal: res.data.body.total,
                })
            }
        })
    }

    makeColumnsData = (data) => {
        const {pageNum, pageSize} = this.state;
        return data.map((item,index)=>{
            return {
                serial: (index + 1) + (pageNum-1) * pageSize,
                key: item.id,
                id: item.id,
                platform: item.platform,
                identifier: item.identifier,
                email: item.email,
                name: item.name,
                phone: item.phone,
            };
        })
    }

    columns = [
        {
            title: '序号',
            dataIndex: 'serial',
            key: 'serial',      
        },
        {
            title: '平台',
            dataIndex: 'platform',
            key: 'platform',      
        },
        {
            title: '账号',
            dataIndex: 'identifier',
            key: 'identifier',      
        },
        {
            title: '姓名',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: '电话',
            dataIndex: 'phone',
            key: 'phone',      
        },
        {
            title: '邮箱',
            dataIndex: 'email',
            key: 'email',      
        }
    ];

    makePlatformSelect = (platforms) => {
        return platforms.map(platform=>{
            return <Option key={platform.name} value={platform.name}>{platform.name}</Option>
        })
    }

    onPlatormSelect = (platform) => {
        this.setState({
            platform: platform,
        })
    }

    makeCountrySelect = (countries) => {
        return countries.map(country=>{
            return <Option key={country.name} value={country.name}>{country.country+" ["+country.name+"]"}</Option>
        })
    }

    onCountrySelect = (country) => {
        this.setState({
            country: country,
        })
    }

    searchNameChange = (e) => {
        this.setState({
            name: e.target.value
        })
    }

    onSearchConsutmerInfo = () => {
        this.onRefreshConsumerInfo();
    }

    onChangePage = (pageNum, pageSize) => {
        this.onRefreshConsumerInfo(pageNum, pageSize);
    }

    openConsumerDetailModal = (record) => {
        this.setState({
            consumerDetailModalShow: true,
            selectRecord: record,
        })
        let self = this;
        let params = {
            id: record.id
        }
        self.props.actions.getConsumerInfoDetail(tool.clearNull(params)).then(res=>{
            if (res.status === 200) {
                self.setState({
                    selectRecordDetail: res.data.body,
                })
            }
        })
    }

    consumerDetailModalCommit = () => {
        this.consumerDetailModalClose();
    }

    consumerDetailModalClose = () => {
        this.setState({
            consumerDetailModalShow: false,
            selectRecord: undefined,
            selectRecordDetail:[]
        })
    }

    render() {
        const {country, platform} = this.props.enums.enums;
        const loading = this.props.consumerInfo.loading || this.props.enums.loading;
        const {name, pageTotal, pageNum, pageSize, pageData, consumerDetailModalShow, selectRecord, selectRecordDetail} = this.state;
        return (
            <div>
                <div className="g-search">
                    <ul className="search-ul">
                        <li>
                            <Select placeholder="选择平台" allowClear style={{width: '100px'}} onChange={this.onPlatormSelect.bind(this)}>
                                {this.makePlatformSelect(platform)}
                            </Select>
                        </li>
                        <li>
                            <Select showSearch optionFilterProp="children" placeholder="选择国家" allowClear style={{width: '300px'}} onChange={this.onCountrySelect.bind(this)}>
                                {this.makeCountrySelect(country)}
                            </Select>
                        </li>
                        <li><Input placeholder="姓名" onChange={(e) => this.searchNameChange(e)} value={name}/></li> 
                        <li><Button icon="search" onClick={this.onSearchConsutmerInfo.bind(this)}>查询</Button></li>
                    </ul>
                </div>
                <Table 
                    bordered
                    loading={loading}
                    dataSource={this.makeColumnsData(pageData)} 
                    columns={this.columns} 
                    rowClassName="pointer"
                    onRow={(record) => {
                        return {
                          onClick: () => this.openConsumerDetailModal(record),       // 点击行
                        };
                      }}
                    pagination={{
                        total: pageTotal,
                        current: pageNum,
                        pageSize: pageSize,
                        showQuickJumper: true,
                        showTotal: (total, range) => `共 ${total} 条数据`,
                        onChange: (pageNum, pageSize) => this.onChangePage(pageNum, pageSize)
                    }}
                />
                <Modal
                    visible={consumerDetailModalShow}
                    onOk={this.consumerDetailModalCommit.bind(this)}
                    onCancel={this.consumerDetailModalClose.bind(this)}
                    okText="确认"
                    cancelText="取消"
                    confirmLoading={loading}
                    height={600}
                    width={600}
                >
                    <div style={{margin:'32px 32px'}}> 
                        <div style={{border:'1px solid #D2E9FF', height:'80px'}}>
                            <span className="title">客户信息</span>
                            <table style={{marginLeft:'15px'}}>
                                <tbody style={{paddingLeft:'10px'}}>
                                    <tr>
                                        <td style={{width:'200px'}}>平台: {selectRecord?selectRecord.platform:undefined}</td>
                                        <td style={{width:'300px'}}>账号: {selectRecord?selectRecord.identifier:undefined}</td>
                                    </tr>
                                    <tr>
                                        <td style={{width:'250px'}}>姓名: {selectRecord?selectRecord.name:undefined}</td>
                                        <td style={{width:'250px'}}>电话: {selectRecord?selectRecord.phone:undefined}</td>
                                    </tr>
                                    <tr>
                                        <td style={{width:'500px'}}>邮箱: {selectRecord?selectRecord.email:undefined}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div style={{border:'1px solid #D2E9FF', height: selectRecordDetail.length>0?selectRecordDetail.length*110+'px':'110px', marginTop:'20px'}}>
                            <span className="title">地址信息</span>
                            {
                                selectRecordDetail.length>0 && selectRecordDetail.map(item=>{
                                   return <table key={item.id} style={{marginLeft:'15px',}}>
                                        <tbody style={{paddingLeft:'10px'}}>
                                            <tr>
                                                <td style={{width:'200px'}}>国家: {item?item.country:undefined} </td>
                                                <td style={{width:'200px'}}>省/州: {item?item.province:undefined}</td>
                                                <td style={{width:'200px'}}>城市: {item?item.city:undefined}</td>
                                            </tr>
                                            <tr>
                                                <td style={{width:'500px'}}>街道1: {item?item.street1:undefined}</td>
                                            </tr>
                                            <tr>
                                                <td style={{width:'500px'}}>街道2: {item?item.street2:undefined}</td>
                                            </tr>
                                            <tr>
                                                <td style={{width:'250px'}}>邮编: {item?item.post:undefined}</td>
                                                <td style={{width:'250px'}}>门牌号: {item?item.houseNumber:undefined}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                })
                            }
                        </div>
                    </div>
                </Modal>
            </div>
        )        
    }

}