((_w) => {
    let config = {
        // "API_URL": "https://192.168.0.105:8443/api",
        // "UPLOAD_URL" : "https://192.168.0.105:8443",
        // 'FILE_URL' : "https://192.168.0.105:8443",

        "API_URL": "https://localhost:8443/api",
        "UPLOAD_URL" : "https://localhost:8443",
        'FILE_URL' : "https://localhost:8443",
    };

    Object.defineProperty(_w, '_CONFIG__', {
        get: () => ({get: name => config[name]}),
        enumerable: true,
        configurable: true
    });
})(window);