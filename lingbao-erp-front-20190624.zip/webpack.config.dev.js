const path = require("path");
const CleanWebpackPlugin = require('clean-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const webpack = require('webpack');
const CopyWebpackplugin = require('copy-webpack-plugin');

module.exports = {

    devtool: 'cheap-module-source-map',

    entry: {
        app:[
            'babel-polyfill',
            path.join(__dirname, './src/index.js'),
        ],
        vendor: [
            'react',
            'react-dom',
            'react-router-dom',
            'react-redux',
            'redux',
            'history',
            'redux-thunk',
        ]
    },

    output: {
        path: path.join(__dirname, './dist'),
        filename: '[name][hash].js',
        chunkFilename: '[name][chunkhash].js',
        publicPath : '/'
    },

    module:{
        rules:[
            {
                test:/\.(js|jsx)$/,
                use:['babel-loader?cacheDirectory=true'],
                exclude: /node_modules/,
                include: path.join(__dirname, 'src'),
                
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader', 'postcss-loader']
            },
            {
				test : /\.less$/,
				use : ['style-loader', 'css-loader', 'less-loader', 'postcss-loader']
			},
            {
                test:/\.(jpg|png|gif)$/,
                use:[{
                    loader: 'url-loader',
                    options:{
                        limit:8192
                    }
                }]
            },
        ],
    },

    plugins: [
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: path.join(__dirname, 'public/index.html')
        }),
        new webpack.HashedModuleIdsPlugin(),
        new CleanWebpackPlugin(['dist']),
        new CopyWebpackplugin([{
            from: path.join(__dirname, '/public'), 
            to: path.join(__dirname, '/dist')
        }]),
    ],

    optimization: {
        splitChunks: {
            name: 'vendor'
        },
        splitChunks: {
            name: 'runtime'
        }
    },

    devServer: {
        port: 10086,
        host: '0.0.0.0',
        contentBase: path.join(__dirname, './dist'),
        historyApiFallback: true,
    }



}